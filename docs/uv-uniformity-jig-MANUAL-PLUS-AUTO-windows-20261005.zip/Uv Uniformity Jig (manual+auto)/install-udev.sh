#!/usr/bin/env bash
# Install the udev rule that gives the EiBotBoard a stable name and permissions.
#
#   sudo bash install-udev.sh
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/udev/99-uvjig.rules"
DST=/etc/udev/rules.d/99-uvjig.rules

if [ "$(id -u)" -ne 0 ]; then
    echo "Needs root. Run: sudo bash install-udev.sh"
    exit 1
fi
[ -f "$SRC" ] || { echo "missing $SRC"; exit 1; }

install -m 0644 "$SRC" "$DST"
echo "installed $DST"

udevadm control --reload
udevadm trigger --subsystem-match=tty --subsystem-match=usb
echo "udev reloaded and retriggered"

echo
if [ -e /dev/uvjig-ebb ]; then
    ls -l /dev/uvjig-ebb
else
    echo "/dev/uvjig-ebb not present yet -- unplug and replug the board."
fi

if ! id -nG "${SUDO_USER:-$USER}" | tr ' ' '\n' | grep -qx plugdev; then
    echo
    echo "NOTE: ${SUDO_USER:-$USER} is not in the 'plugdev' group, which this rule"
    echo "      grants access to. Fix with:"
    echo "        sudo usermod -aG plugdev ${SUDO_USER:-$USER}"
    echo "      then log out and back in."
fi
