#!/usr/bin/env bash
# UV Uniformity Jig -- Linux setup.
#
#   bash setup.sh            install and verify
#   bash setup.sh --check    verify only, change nothing
#
# Installs openpyxl, installs the udev rule, and verifies that every tool
# compiles and the board is reachable.
#
# MANUAL + AUTOMATIC build. Auto mode (StarBright meter + auto scan) works on
# Linux with the meter on RS-232 (needs pyserial: pip install pyserial); the
# USB route needs Ophir's Windows-only driver. Manual mode is unchanged.
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
CHECK=0
[ "${1:-}" = "--check" ] && CHECK=1

ok=0; note=0; fail=0
say()  { printf '%s\n' "$*"; }
good() { printf '  [ ok ] %s\n' "$*"; ok=$((ok+1)); }
note_() { printf '  [note] %s\n' "$*"; note=$((note+1)); }
bad()  { printf '  [FAIL] %s\n' "$*"; fail=$((fail+1)); }

say "======================================================================"
say "  UV Uniformity Jig -- setup"
say "======================================================================"

# ------------------------------------------------------------- platform ---
say
say "Platform"
if [ "$(uname -s)" != "Linux" ]; then
    bad "this script is for Linux. On Windows run setup-windows.bat."
    exit 1
fi
good "$(uname -s) $(uname -m)"

PY=""
for c in python3 python; do
    command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }
done
if [ -z "$PY" ]; then
    bad "no Python found. Install Python 3.8+."
    exit 1
fi
PYV="$("$PY" -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
case "$PYV" in
    3.[89]|3.1[0-9]) good "Python $PYV ($PY)" ;;
    *) bad "Python $PYV is too old -- need 3.8+" ;;
esac

# ------------------------------------------------------------- packages ---
say
say "Python packages"
if "$PY" -c 'import openpyxl' 2>/dev/null; then
    good "openpyxl (the scan workbook)"
else
    if [ "$CHECK" -eq 1 ]; then
        note_ "would install openpyxl"
    else
        say "  installing openpyxl..."
        if command -v apt-get >/dev/null 2>&1; then
            sudo apt-get install -y python3-openpyxl >/dev/null 2>&1 \
              || "$PY" -m pip install --quiet openpyxl
        else
            "$PY" -m pip install --quiet openpyxl
        fi
        "$PY" -c 'import openpyxl' 2>/dev/null && good "openpyxl installed" \
          || note_ "openpyxl not installed -- only needed to export the workbook"
    fi
fi
# No pyserial on Linux: tools/serial_min.py speaks termios directly, which is
# what lets this run on a bare Python install.
good "no pyserial needed on Linux (termios backend)"

# ----------------------------------------------------------------- udev ---
say
say "Device rule"
if [ -f /etc/udev/rules.d/99-uvjig.rules ]; then
    good "/etc/udev/rules.d/99-uvjig.rules present"
elif [ "$CHECK" -eq 1 ]; then
    note_ "would install the udev rule (needs sudo)"
else
    sudo bash "$HERE/install-udev.sh" >/dev/null 2>&1 \
      && good "udev rule installed" \
      || bad "could not install the udev rule -- run: sudo bash install-udev.sh"
fi

# -------------------------------------------------------------- devices ---
say
say "Devices"
if command -v lsusb >/dev/null 2>&1; then
    lsusb | grep -qi '04d8:fd92' && good "EiBotBoard detected" \
      || note_ "EiBotBoard not detected (unplugged?)"
else
    note_ "lsusb not available; skipping USB enumeration"
fi
if [ -e /dev/uvjig-ebb ]; then
    if [ -r /dev/uvjig-ebb ] && [ -w /dev/uvjig-ebb ]; then
        good "/dev/uvjig-ebb readable/writable"
    else
        bad "/dev/uvjig-ebb exists but is not accessible -- are you in 'plugdev'?"
    fi
else
    note_ "/dev/uvjig-ebb absent (board unplugged, or replug needed after the rule)"
fi
say "  The servo is on the SAME board (RB1). There is no second device to find."

# -------------------------------------------------------------- project ---
say
say "Project files"
for f in tools/serial_min.py tools/ebb.py tools/move_ebb.py tools/servo_ctl.py \
         scan/scan_plan.py web/server.py web/index.html limits.json \
         udev/99-uvjig.rules; do
    [ -f "$HERE/$f" ] && good "$f" || bad "missing $f"
done
if "$PY" -c "
import sys, py_compile, glob, os
os.chdir('$HERE')
bad=0
for f in glob.glob('tools/*.py')+glob.glob('scan/*.py')+glob.glob('web/*.py'):
    try: py_compile.compile(f, doraise=True)
    except Exception as e: print('   ', f, e); bad=1
sys.exit(bad)" 2>/dev/null; then
    good "all python tools compile"
else
    bad "some python tools fail to compile"
fi
find "$HERE" -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null

# -------------------------------------------------------------- summary ---
say
say "======================================================================"
say "  $ok ok, $note notes, $fail failures"
say "======================================================================"
if [ "$fail" -gt 0 ]; then
    say "Fix the failures above before running the jig."
    exit 1
fi

cat <<'NEXT'

Next steps:
  1. EASIEST: ./start-console.sh
     Opens the web console in your browser -- connection indicators, origin
     recalibration, a coverage tracker, and Enter-to-advance data entry. It also
     prints a URL that works from any other computer or phone on the network,
     which needs no Python and no drivers. See web/README.md.

  2. Read STARTUP.md -- what to plug in. The board needs an EXTERNAL motor
     supply or nothing will turn, however healthy the USB link looks.

  3. Verify:   python3 tools/move_ebb.py --status
               python3 tools/servo_ctl.py --sweep

  4. Re-home:  DO_MOVE=1 python3 tools/home_x.py
     Step counters reset to 0 whenever the board is unplugged, so the origin
     must be re-established on a new machine or after any replug.

Motion is not interlocked. The steppers move only with DO_MOVE=1 (or Arm in the
console), and tools/estop.py stops an axis immediately.
NEXT
