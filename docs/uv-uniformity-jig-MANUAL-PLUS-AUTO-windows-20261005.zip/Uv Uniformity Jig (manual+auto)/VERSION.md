# UV Uniformity Jig — MANUAL + AUTOMATIC build

This package is the **manual + automatic** version of the jig software.

| Build | Package name | What it does |
|---|---|---|
| **Manual only** | `uv-uniformity-jig-windows-YYYYMMDD.zip` | The original console: the jig moves, you read the UV meter and type each value. No meter software, no meter driver, nothing extra to install. |
| **Manual + automatic** (this one) | `uv-uniformity-jig-MANUAL-PLUS-AUTO-windows-YYYYMMDD.zip` | Everything above, plus an **Auto** mode: the Ophir StarBright meter is read over USB and an *auto scan* drives a whole section by itself — move, aim, wait for a settled reading, log it, next point. |

The two modes are a toggle in the console header. The console starts in
**Manual** and remembers your last choice. In Manual mode nothing to do with the
meter is ever touched, so this build runs on a computer without the meter or its
driver exactly like the manual-only build — no error messages, no missing
dependencies.

Auto mode needs, on the computer the jig is plugged into, the Ophir
**StarBright** connected one of two ways:

* **RS‑232** — the meter's serial lead into a COM port or a USB‑serial adapter.
  **No Ophir driver, no admin rights, no download.** This is the way to go on a
  locked-down computer, and it works on Linux too.
* **USB** — needs Ophir's WinUSB driver, installed once as Administrator. The
  two driver files are bundled in `docs/starbright/driver/` (no download), or
  come with Ophir's free StarLab. Windows only.

`setup-windows.bat` reports what it finds and never fails setup over the meter.

See **README.md** → *Auto scan*, **web/README.md** → *Auto mode*, and
**WINDOWS.md** → *Auto mode* for the two connections.

## Changes

**2026-10-05 — 270° servo; DOWN is servo-aimed.** The 180° MG90S was replaced
with a 270° servo on the same 500–2500 µs range. The scan plan is now
`AUTO` (BACK / UP / FRONT / DOWN, 360 rows), `MANUAL-RIGHT` (90) and
`MANUAL-LEFT` (90): two hand repositions per scan instead of three. Within
`AUTO` the four faces alternate order point to point so the horn never jumps
more than 90°. The wait before a reading now includes the servo's travel time.
Servo range, travel and timing are read from `limits.json` → `servo`.
*Readings logged before this date carry old row numbers*: the console lists
them as not matching the current grid and leaves them in the CSV, and the
workbook is rebuilt (the old one archived) on the next *Save to Excel*.
