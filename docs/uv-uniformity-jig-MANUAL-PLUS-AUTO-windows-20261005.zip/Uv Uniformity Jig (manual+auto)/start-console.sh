#!/bin/sh
# Start the UV jig web console. Run this on the computer the jig is plugged into.
#
#   ./start-console.sh                    # port 8765, reachable from the network
#   PORT=9000 ./start-console.sh          # different port
#   ./start-console.sh --host 127.0.0.1   # this computer only
#   ./start-console.sh --token secret     # require ?k=secret
#   ./start-console.sh --mode manual      # (default) type each reading
#   ./start-console.sh --sim              # no hardware: simulated board and meter
#
# Everything after the script name is passed straight to web/server.py.
# MANUAL + AUTOMATIC build (VERSION.md). Auto mode reads the StarBright over
# RS-232 (any platform, pyserial) or USB (Windows, Ophir driver).
set -e
cd "$(dirname "$0")"

PORT="${PORT:-8765}"

PY=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
    echo "No Python found. Install Python 3.8 or newer, then run this again."
    exit 1
fi

# A console already on this port means the new one cannot bind, and the browser
# would keep talking to the stale server -- which makes updated files look like
# they did nothing.
if command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | grep -q ":$PORT "; then
    echo
    echo "A jig console is already running on port $PORT."
    echo "Close it first, or start this one with a different PORT="
    echo
    exit 1
fi

# Open a browser once the server is actually listening, rather than racing it.
# The wait is done in Python because /dev/tcp is a bash extension and /bin/sh is
# dash on most Linux systems.
if command -v xdg-open >/dev/null 2>&1; then
    (
        "$PY" - "$PORT" <<'WAIT'
import socket, sys, time
port = int(sys.argv[1])
for _ in range(60):
    s = socket.socket()
    s.settimeout(0.25)
    try:
        s.connect(("127.0.0.1", port))
        sys.exit(0)
    except OSError:
        time.sleep(0.25)
    finally:
        s.close()
sys.exit(1)
WAIT
        [ $? -eq 0 ] && xdg-open "http://localhost:$PORT/" >/dev/null 2>&1
    ) &
fi

exec "$PY" web/server.py --port "$PORT" "$@"
