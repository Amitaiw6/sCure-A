#!/usr/bin/env python3
"""Abort axis motion immediately.

    python3 tools/estop.py            # stop the axes, leave them energised
    python3 tools/estop.py --release  # stop, then de-energise
    python3 tools/estop.py --servo    # also stop driving the servo

ES is sent with no preamble -- no sync, no version check, nothing that could
delay it. The reply is read afterwards only to report; it is not waited on
before the stop takes effect.

Holding torque is kept by default. A de-energised Z axis can drop under gravity,
which is usually worse than whatever prompted the stop.
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serial_min import Serial, SerialError, show, resolve_port     # noqa: E402
import ebb                                                          # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Emergency-stop the jig axes.")
    ap.add_argument("--release", action="store_true",
                    help="de-energise afterwards (Z may drop under gravity)")
    ap.add_argument("--servo", action="store_true",
                    help="also stop driving the servo")
    ap.add_argument("--port", default=None)
    args = ap.parse_args()

    try:
        with Serial(resolve_port(args.port)) as p:
            p.write("ES\r")                      # first, before anything else
            print("ES  -> %s" % show(p.read_quiet(quiet=0.4, overall=2.0)).strip())
            if args.servo:
                print("S2  -> %s" % show(ebb.servo_off(p)).strip())
            if args.release:
                # EM,0,0 de-energises. It also zeroes the counters -- that is
                # what EM does -- so the frame is gone and you must re-home.
                print("EM  -> %s" % show(p.ask("EM,0,0")).strip())
                print("\nMotors released. EM ZEROED BOTH COUNTERS: re-home before")
                print("trusting any coordinate.")
            else:
                print("\nStopped, still energised. Position counters are intact,")
                print("but steps lost to an abrupt stop are not counted -- re-home")
                print("if the move mattered.")
    except SerialError as e:
        print("FAIL: %s" % e)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
