#!/usr/bin/env python3
"""Jog the jig steppers. EBB axis 1 = chamber Y, axis 2 = chamber Z.

The chamber's X is the layer axis, moved by hand -- it has no motor.

    python3 tools/move_ebb.py --status                 # read only, never moves
    DO_MOVE=1 python3 tools/move_ebb.py --y -8000
    DO_MOVE=1 python3 tools/move_ebb.py --y-rev -5     # 5 turns away from origin
    DO_MOVE=1 python3 tools/move_ebb.py --z-mm 25

Nothing moves without DO_MOVE=1. Without it this prints the plan and exits,
which is the right default for a machine with no hardware interlock.

Sign conventions, which are counter-intuitive on this rig:

    --y positive   drives INTO the Y origin stop
    --y negative   is the usable Y travel (0 -> -120000)
    --z positive   is up (0 -> +39000, 300 mm)

The web console hides this and labels its buttons "toward origin" / "away",
which is what you actually think in when standing at the machine. This tool
speaks raw machine convention on purpose: it is the low-level one.
"""

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serial_min import (Serial, SerialError, lines, show,          # noqa: E402
                        resolve_port, describe_ports)
import ebb                                                          # noqa: E402


def preflight(path):
    if not path.startswith("/dev"):
        return True                                  # Windows COM port
    if not os.path.exists(path):
        print("FAIL: %s does not exist -- EBB unplugged?" % path)
        for p in describe_ports():
            print("      seen: %s" % p)
        return False
    if not os.access(path, os.R_OK | os.W_OK):
        print("FAIL: no access to %s" % path)
        print("      Fix: sudo bash install-udev.sh")
        return False
    return True


def show_state(p, label):
    st = ebb.read_state(p)
    counts = ebb.read_vplus(p)
    print("  %-8s %s" % (label, st.get("V", "?")))
    print("           QS  %s" % st.get("QS", ""))
    print("           V+  %s counts -- motor supply %s"
          % (counts, "PRESENT" if ebb.supply_present(counts) else "MISSING or OFF"))
    return st


def main():
    ap = argparse.ArgumentParser(description="Jog the UV jig steppers.")
    ap.add_argument("--status", action="store_true", help="report and exit")
    ap.add_argument("--y", type=int, default=0, help="driven Y steps")
    ap.add_argument("--z", type=int, default=0, help="Z steps")
    ap.add_argument("--y-rev", type=float, default=0.0, help="driven Y rotations")
    ap.add_argument("--z-rev", type=float, default=0.0, help="Z rotations")
    ap.add_argument("--y-mm", type=float, default=0.0, help="driven Y millimetres")
    ap.add_argument("--z-mm", type=float, default=0.0, help="Z millimetres")
    ap.add_argument("--rate", type=float, default=None, help="steps/s")
    ap.add_argument("--force", action="store_true",
                    help="ignore the soft limits (needed only when re-homing)")
    ap.add_argument("--set-origin", action="store_true",
                    help="declare the current position the origin (sends CS). "
                         "Zeroes BOTH axes -- the board has no per-axis clear -- "
                         "so Z must already be on its own origin.")
    ap.add_argument("--set-microstep", type=int, choices=sorted(ebb.MICROSTEP),
                    help="send EM. WARNING: EM also ZEROES both counters.")
    ap.add_argument("--port", default=None)
    args = ap.parse_args()

    port = resolve_port(args.port)
    if not preflight(port):
        return 2

    limits = ebb.load_limits()
    per_rev = (limits or {}).get("steps_per_rev", 3200)
    yspm = ((limits or {}).get("y") or {}).get("steps_per_mm", 800)
    zspm = ((limits or {}).get("z") or {}).get("steps_per_mm", 130)

    steps_y = args.y + int(round(args.y_rev * per_rev)) + int(round(args.y_mm * yspm))
    steps_z = args.z + int(round(args.z_rev * per_rev)) + int(round(args.z_mm * zspm))

    try:
        with Serial(port) as p:
            if p.sync() is None:
                print("FAIL: could not synchronise with the EBB; not moving.")
                return 2
            show_state(p, "before")

            if args.set_origin:
                pos = ebb.read_position(p)
                if pos is None:
                    print("FAIL: could not read the position; not zeroing.")
                    return 2
                if pos[1] != 0 and not args.force:
                    print("\nREFUSED: Z is at %d, not 0. CS zeroes BOTH axes -- the"
                          % pos[1])
                    print("         board has no per-axis clear -- so Z's frame would")
                    print("         be destroyed too. Put Z on its origin, or --force.")
                    return 1
                if os.environ.get("DO_MOVE") != "1":
                    print("\nDRY RUN -- would send CS and zero both counters here.")
                    print("Re-run with DO_MOVE=1.")
                    return 0
                print("\n  -> CS   (zeroes BOTH counters at this position)")
                print("  <- %s" % show(ebb.zero_counters(p)).strip())
                time.sleep(0.2)
                print("  QS after = %s" % (ebb.read_position(p),))
                print("\nThis position is now the origin. Usable travel is -Y from here.")
                return 0

            if args.status or (steps_y == 0 and steps_z == 0
                               and args.set_microstep is None):
                return 0

            pos = ebb.read_position(p)
            if not args.force:
                bad = ebb.check_limits(limits, pos, steps_y, steps_z)
                if bad:
                    print("\nREFUSED -- soft limit:")
                    for b in bad:
                        print("  %s" % b)
                    print("\nThese bound the step counter, not the machine. If you")
                    print("are re-homing, the counter is what you are re-establishing,")
                    print("so pass --force.")
                    return 1

            rate = args.rate or (ebb.Y_RATE_HZ if abs(steps_y) >= abs(steps_z)
                                 else ebb.Z_RATE_HZ)
            chunks = ebb.split_move(steps_y, steps_z, rate)
            total_ms = sum(c[2] for c in chunks)
            print("\nplan: Y %+d, Z %+d at %.0f steps/s -- %d command(s), %.1f s"
                  % (steps_y, steps_z, rate, len(chunks), total_ms / 1000.0))

            if os.environ.get("DO_MOVE") != "1":
                print("\nDRY RUN -- nothing transmitted. Re-run with DO_MOVE=1.")
                return 0

            if args.set_microstep is not None:
                print("\nEM,%d,%d -- this ZEROES both counters"
                      % (args.set_microstep, args.set_microstep))
                print("  <- %s" % show(p.ask("EM,%d,%d" % (args.set_microstep,
                                                           args.set_microstep))))
            print()
            for cx, cz, cd in chunks:
                print("  SM,%d,%d,%d" % (cd, cx, cz))
                ebb.send_move(p, cx, cz, cd)
                # Silence during motion is deliberate: USB traffic competes
                # with the EBB's step generator and causes stutter.
                time.sleep(ebb.move_duration_s(cd))
            time.sleep(0.3)
            show_state(p, "after")
    except SerialError as e:
        print("FAIL: %s" % e)
        return 2
    except ValueError as e:
        print("FAIL: %s" % e)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
