"""Minimal cross-platform serial support for the UV jig.

The jig is ONE device: a SchmalzHaus EiBotBoard carrying both steppers and the
RC servo. There is no second board to find, so port resolution has one answer.

Two backends, chosen automatically:

  * **termios** on Linux/macOS -- stdlib only, no dependencies. This is the
    proven path and stays the default on POSIX.
  * **pyserial** on Windows, where termios does not exist.

The public API is identical either way, so nothing above this file cares which
one is in use. Port naming differs too, so resolve_port() hides that:

  * Linux  : /dev/uvjig-ebb, created by the udev rule
  * Windows: COMx, discovered by USB vendor/product ID -- COM numbers are no
             more stable than ttyACM numbers, so matching on identity is the
             same trick the udev rule plays

Scope: 8N1, no flow control, raw mode. That is all the EBB needs.
"""

import os
import platform
import select
import time

IS_WINDOWS = platform.system() == "Windows"

try:
    import termios
    HAVE_TERMIOS = True
except ImportError:
    HAVE_TERMIOS = False

try:
    import serial as _pyserial
    from serial.tools import list_ports as _list_ports
    HAVE_PYSERIAL = True
except ImportError:
    HAVE_PYSERIAL = False

EBB_VID, EBB_PID = 0x04D8, 0xFD92          # SchmalzHaus EiBotBoard
EBB_LINK = "/dev/uvjig-ebb"
SIM_PORT = "sim"          # UVJIG_EBB_PORT=sim -> in-process fake board (tools/ebb_sim.py)
EBB_BYID = "/dev/serial/by-id/usb-SchmalzHaus_EiBotBoard_-if00"
BAUD = 9600


class SerialError(Exception):
    pass


# ------------------------------------------------------------ port lookup ---
def find_by_usb_id(vid, pid):
    """Return a port name for a device with this VID/PID, or None."""
    if not HAVE_PYSERIAL:
        return None
    for p in _list_ports.comports():
        if p.vid == vid and p.pid == pid:
            return p.device
    return None


def resolve_port(explicit=None):
    """Resolve the EBB's port for this platform.

    Order: explicit argument -> UVJIG_EBB_PORT -> stable udev name ->
    USB vendor/product lookup -> /dev/serial/by-id.
    """
    if explicit:
        return explicit
    override = os.environ.get("UVJIG_EBB_PORT")
    if override:
        return override          # a port name, or "sim" for the in-process fake
    if not IS_WINDOWS and os.path.exists(EBB_LINK):
        return EBB_LINK
    found = find_by_usb_id(EBB_VID, EBB_PID)
    if found:
        return found
    if not IS_WINDOWS and os.path.exists(EBB_BYID):
        return EBB_BYID
    # Nothing found: return the conventional name so the caller's own error
    # message names something recognisable.
    return "COM3" if IS_WINDOWS else EBB_LINK


def describe_ports():
    """Human-readable list of candidate serial ports, for diagnostics."""
    out = []
    if HAVE_PYSERIAL:
        for p in _list_ports.comports():
            ident = "  %04x:%04x" % (p.vid, p.pid or 0) if p.vid is not None else ""
            out.append("%-12s %s%s" % (p.device, p.description or "", ident))
    elif not IS_WINDOWS:
        import glob
        for p in sorted(glob.glob("/dev/ttyACM*") + glob.glob("/dev/ttyUSB*")):
            out.append(p)
    return out


# ----------------------------------------------------------------- Serial ---
class Serial(object):
    """A raw 8N1 serial port.

        with Serial(resolve_port()) as p:
            p.write(b'V\\r')
            print(p.read_quiet())
    """

    def __init__(self, path, baud=BAUD, exclusive=True):
        self.path = path
        self.baud = baud
        self._exclusive = exclusive
        self.fd = None          # termios backend
        self._ser = None        # pyserial backend
        self._sim = None        # in-process FakeEBB (UVJIG_EBB_PORT=sim)
        self._sim_buf = b""
        if str(path).lower() == SIM_PORT:
            self.backend = "sim"
        else:
            self.backend = "pyserial" if (IS_WINDOWS or not HAVE_TERMIOS) else "termios"
        if self.backend == "pyserial" and not HAVE_PYSERIAL:
            raise SerialError(
                "pyserial is required on this platform. Install it with:\n"
                "    python -m pip install pyserial")
        self.open()

    # -- lifecycle ---------------------------------------------------------
    def open(self):
        if self.backend == "sim":
            import ebb_sim
            self._sim = ebb_sim.shared_board()
            self._sim_buf = b""
            return
        if self.backend == "pyserial":
            try:
                self._ser = _pyserial.Serial(
                    port=self.path, baudrate=self.baud,
                    bytesize=8, parity="N", stopbits=1,
                    timeout=0, write_timeout=2.0, rtscts=False, dsrdtr=False)
            except Exception as e:                          # noqa: BLE001
                raise SerialError("open %s: %s" % (self.path, e)) from e
            self.reset_input()
            return

        try:
            self.fd = os.open(self.path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        except OSError as e:
            raise SerialError("open %s: %s" % (self.path, e.strerror)) from e

        if self._exclusive:
            # TIOCEXCL: refuse further opens. Catches a second probe, or
            # ModemManager, racing us for the port.
            try:
                import fcntl
                fcntl.ioctl(self.fd, 0x540C)
            except OSError:
                pass                                        # advisory only

        try:
            self._configure_termios()
        except Exception:
            os.close(self.fd)
            self.fd = None
            raise

    def _configure_termios(self):
        speed = getattr(termios, "B%d" % self.baud, None)
        if speed is None:
            raise SerialError("unsupported baud %r" % self.baud)

        a = termios.tcgetattr(self.fd)
        # iflag: no translation, no parity check, no software flow control.
        a[0] = termios.IGNPAR
        # oflag: raw out -- critically no ONLCR, which would turn \r into \r\n.
        a[1] = 0
        # cflag: 8N1, receiver on, ignore modem lines. CLOCAL matters: without
        # it a port with no carrier blocks forever. HUPCL left off so closing
        # does not drop DTR.
        a[2] = termios.CS8 | termios.CREAD | termios.CLOCAL
        # lflag: non-canonical, no echo -- otherwise the tty layer buffers by
        # line and eats control characters.
        a[3] = 0
        a[4] = speed
        a[5] = speed
        cc = list(a[6])
        cc[termios.VMIN] = 0        # never block for a minimum byte count
        cc[termios.VTIME] = 0       # no inter-byte timer; select() does timing
        a[6] = cc
        termios.tcsetattr(self.fd, termios.TCSANOW, a)
        self.reset_input()

    def close(self):
        self._sim = None
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:                               # noqa: BLE001
                pass
            self._ser = None
        if self.fd is not None:
            try:
                termios.tcflush(self.fd, termios.TCIOFLUSH)
            except OSError:
                pass
            os.close(self.fd)
            self.fd = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    # -- io ----------------------------------------------------------------
    def reset_input(self):
        """Discard anything already sitting in the input buffer."""
        if self.backend == "sim":
            self._sim_buf = b""
            return
        if self._ser is not None:
            try:
                self._ser.reset_input_buffer()
            except Exception:                               # noqa: BLE001
                pass
            return
        try:
            termios.tcflush(self.fd, termios.TCIFLUSH)
        except OSError:
            pass

    def write(self, data):
        if isinstance(data, str):
            data = data.encode("ascii")

        if self.backend == "sim":
            if self._sim is None:
                raise SerialError("sim port is closed")
            for line in data.replace(b"\n", b"\r").split(b"\r"):
                if line.strip():
                    reply = self._sim.handle(line.decode("ascii", "replace"))
                    if reply is not None:
                        self._sim_buf += (reply + "\r\n").encode()
            return len(data)

        if self._ser is not None:
            try:
                n = self._ser.write(data)
                self._ser.flush()
            except Exception as e:                          # noqa: BLE001
                raise SerialError("write %s: %s" % (self.path, e)) from e
            return n if n is not None else len(data)

        n = 0
        deadline = time.monotonic() + 2.0
        while n < len(data):
            if time.monotonic() > deadline:
                raise SerialError("write timed out after %d/%d bytes" % (n, len(data)))
            try:
                n += os.write(self.fd, data[n:])
            except BlockingIOError:
                select.select([], [self.fd], [], 0.1)
        try:
            termios.tcdrain(self.fd)
        except OSError:
            pass
        return n

    def _read_some(self, timeout):
        """Read whatever is available, waiting at most `timeout` seconds."""
        if self.backend == "sim":
            out, self._sim_buf = self._sim_buf, b""
            if not out:
                time.sleep(min(timeout, 0.01))
            return out
        if self._ser is not None:
            end = time.monotonic() + timeout
            while True:
                n = self._ser.in_waiting
                if n:
                    return self._ser.read(n)
                if time.monotonic() >= end:
                    return b""
                time.sleep(0.01)
        r, _, _ = select.select([self.fd], [], [], timeout)
        if not r:
            return b""
        try:
            return os.read(self.fd, 4096)
        except BlockingIOError:
            return b""
        except OSError as e:
            raise SerialError("read %s: %s" % (self.path, e.strerror)) from e

    def read_quiet(self, quiet=0.30, overall=3.0, want=None):
        """Read until the line goes quiet for `quiet` seconds.

        Assumes no terminator and no length, and does not require a reply at
        all. want: optional bytes; return as soon as this appears.
        """
        buf = bytearray()
        start = time.monotonic()
        last = start
        while True:
            now = time.monotonic()
            if now - start > overall:
                break
            if buf and (now - last) > quiet:
                break
            if want and want in buf:
                break
            chunk = self._read_some(0.05)
            if chunk:
                buf.extend(chunk)
                last = time.monotonic()
        return bytes(buf)

    def ask(self, cmd, quiet=0.50, overall=4.0, eol="\r", want=None):
        """Send one command and return the raw reply bytes.

        The quiet window is generous on purpose. The EBB often splits a reply
        into two bursts -- payload, a gap, then a separate 'OK\\r\\n'. A short
        window returns after the first burst, leaving the 'OK' to be misread as
        the NEXT command's reply, which desynchronises the stream and makes
        every later reading wrong.

        `want` is the fast path for that same problem: the trailing OK IS the
        terminator, so a caller that waits for it returns the instant the reply
        is complete instead of sitting out a silence window. Waiting 0.5 s after
        every query cost about a second per measured point -- nine minutes over
        a 540-point scan.
        """
        self.reset_input()
        self.write(cmd + eol)
        return self.read_quiet(quiet=quiet, overall=overall, want=want)

    def drain(self, budget=2.0):
        """Read and discard until the device is genuinely quiet."""
        total = b""
        start = time.monotonic()
        while time.monotonic() - start < budget:
            chunk = self.read_quiet(quiet=0.3, overall=0.6)
            if not chunk:
                break
            total += chunk
        return total

    def sync(self, probe="V", expect=b"EBB", attempts=5):
        """Confirm replies line up with commands before trusting any reading.

        Returns the banner, or None if the stream could not be realigned -- in
        which case the caller must NOT act on any query result.
        """
        self.drain()
        for _ in range(attempts):
            self.reset_input()
            self.write(probe + "\r")
            raw = self.read_quiet(quiet=0.4, overall=2.0, want=expect)
            if expect in raw:
                # want= returns the instant the marker appears, so the rest of
                # the banner is still buffered. Leaving it would prepend banner
                # debris to the next reply -- the very desync this prevents.
                raw += self.drain(budget=1.0)
                return raw
            self.drain(budget=1.0)
        return None


# ------------------------------------------------------------- formatting ---
def show(raw):
    """Render device bytes for a human: escapes visible, one line."""
    if raw == b"":
        return "<no reply>"
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError:
        return "<non-ascii> " + raw.hex(" ")
    return text.replace("\r", "\\r").replace("\n", "\\n")


def lines(raw):
    """Split a reply into stripped, non-empty logical lines."""
    try:
        text = raw.decode("ascii", "replace")
    except Exception:                                       # noqa: BLE001
        return []
    return [ln.strip() for ln in
            text.replace("\r\n", "\n").replace("\r", "\n").split("\n") if ln.strip()]


if __name__ == "__main__":
    print("platform : %s" % platform.system())
    print("backend  : %s" % ("pyserial" if (IS_WINDOWS or not HAVE_TERMIOS) else "termios"))
    print("pyserial : %s" % ("available" if HAVE_PYSERIAL else "NOT installed"))
    print("EBB port : %s" % resolve_port())
    print("\ncandidate ports:")
    for p in describe_ports() or ["  (none found)"]:
        print("  %s" % p)
