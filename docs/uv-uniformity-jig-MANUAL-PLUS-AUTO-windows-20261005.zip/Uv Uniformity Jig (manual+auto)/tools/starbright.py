"""
Ophir StarBright (and other Ophir meters) -- the console's UV meter driver.

Three ways to reach the meter, one Python interface:

  USB      OphirMeter      WinUSB vendor control transfers, exactly what Ophir's
                           own DLL does. Windows only; needs Ophir's WinUSB
                           driver (from StarLab, or docs/starbright/driver/).
  RS-232   SerialMeter     the meter's serial port through any COM port or
                           USB-serial adapter. NO Ophir driver, any platform.
  sim      SimulatedMeter  no hardware, for --sim dry runs.

All three speak the same ASCII protocol from "Ophir User Commands.pdf":
commands are "$XX", replies start with "*" (ok) or "?" (error). Over USB the
framing is "$XX\\r\\n" inside a control transfer; over RS-232 it is
"$XX" + LF CR, and the reply ends with LF CR as well.

    from starbright import open_meter
    with open_meter("auto") as m:          # "usb" | "serial" | "serial:COM5" | "sim"
        print(m.identify(), m.power(), m.query("SI"))

CLI:
    python starbright.py                    # USB: identify + one reading
    python starbright.py --serial           # RS-232: find the adapter, identify
    python starbright.py --serial COM5 --stream 5
    python starbright.py --sim
"""
import argparse
import os
import platform
import sys
import time

IS_WINDOWS = platform.system() == "Windows"

# The EiBotBoard's USB ID: its COM port is never the meter.
EBB_VID, EBB_PID = 0x04D8, 0xFD92
VID_OPHIR = 0x0BD3

UNIT_NAMES = {"w": "W/cm^2", "W": "W", "j": "J/cm^2", "J": "J", "d": "dBm",
              "X": "(passive)", "l": "lux", "c": "fc", "u": "lm"}


class OphirError(Exception):
    pass


# ============================================================ common base ===
class _MeterBase:
    """What the console relies on. Subclasses implement query() and close()."""
    path = ""
    transport = ""

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def query(self, cmd):
        raise NotImplementedError

    def close(self):
        pass

    # -- convenience, identical for every transport -------------------------
    def identify(self):
        """Firmware, instrument, sensor and current configuration."""
        info = {}
        info["firmware"] = self.query("VE")          # "SB1.30"
        info["instrument"] = self.query("II")        # "STBR 821302 StarBright"
        info["head"] = self.query("HI")              # "SI 862870 PD300RM-8W 00400001"
        info["head_type"] = self.query("HT")         # "RM w"
        info["units"] = self.query("SI")             # w = W/cm^2, W = watts, ...
        info["ranges"] = self.query("AR")            # "<active> AUTO 30.0W/cm^2 ..."
        info["range_in_use"] = self.query("GU")
        info["range_max"] = self.query("SX")
        info["wavelengths"] = self.query("AW")       # "CONTINUOUS <lo> <hi> <idx> <fav1..6>"
        info["measurement_mode"] = self.query("MM")
        return info

    def wavelength_nm(self):
        """Currently selected wavelength from the AW favourites list."""
        f = self.query("AW").split()
        if f and f[0] == "CONTINUOUS":
            try:
                return int(f[3 + int(f[3])])   # 1-based index into the favourites after lo/hi/idx
            except (IndexError, ValueError):
                return None
        return f[1:]

    def set_wavelength(self, nm):
        self.query("WL %d" % int(nm))

    def set_range(self, index):
        """-1 = AUTO, 0 = highest numeric range, 1 = next lower, ..."""
        self.query("WN %d" % int(index))

    def power(self):
        """One reading in the units reported by SI (e.g. W/cm^2 for a PD300RM)."""
        return float(self.query("SP"))


# ============================================================== USB/WinUSB ===
OPHIR_IFACE_GUID = "3E0EE3A4-5F0E-40E9-94A1-5F0711CE2517"

if IS_WINDOWS:
    import ctypes
    import ctypes.wintypes as _w
    import uuid as _uuid

    _sa = ctypes.windll.setupapi
    _k32 = ctypes.windll.kernel32
    _wu = ctypes.windll.winusb

    class _GUID(ctypes.Structure):
        _fields_ = [("d1", ctypes.c_uint32), ("d2", ctypes.c_uint16), ("d3", ctypes.c_uint16),
                    ("d4", ctypes.c_ubyte * 8)]

        @classmethod
        def from_str(cls, s):
            u = _uuid.UUID(s)
            return cls(u.time_low, u.time_mid, u.time_hi_version, (ctypes.c_ubyte * 8)(*u.bytes[8:]))

    class _DIDATA(ctypes.Structure):
        _fields_ = [("cbSize", _w.DWORD), ("guid", _GUID), ("flags", _w.DWORD), ("res", ctypes.c_void_p)]

    class _SETUP(ctypes.Structure):
        _fields_ = [("RequestType", ctypes.c_ubyte), ("Request", ctypes.c_ubyte), ("Value", ctypes.c_ushort),
                    ("Index", ctypes.c_ushort), ("Length", ctypes.c_ushort)]

    _sa.SetupDiGetClassDevsW.restype = ctypes.c_void_p
    _sa.SetupDiGetClassDevsW.argtypes = [ctypes.POINTER(_GUID), _w.LPCWSTR, _w.HWND, _w.DWORD]
    _sa.SetupDiEnumDeviceInterfaces.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(_GUID),
                                                _w.DWORD, ctypes.POINTER(_DIDATA)]
    _sa.SetupDiGetDeviceInterfaceDetailW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_DIDATA), ctypes.c_void_p,
                                                     _w.DWORD, ctypes.POINTER(_w.DWORD), ctypes.c_void_p]
    _sa.SetupDiDestroyDeviceInfoList.argtypes = [ctypes.c_void_p]
    _k32.CreateFileW.restype = ctypes.c_void_p
    _k32.CreateFileW.argtypes = [_w.LPCWSTR, _w.DWORD, _w.DWORD, ctypes.c_void_p, _w.DWORD, _w.DWORD, ctypes.c_void_p]
    _k32.CloseHandle.argtypes = [ctypes.c_void_p]
    _wu.WinUsb_Initialize.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    _wu.WinUsb_Free.argtypes = [ctypes.c_void_p]
    _wu.WinUsb_ControlTransfer.argtypes = [ctypes.c_void_p, _SETUP, ctypes.c_void_p, _w.DWORD,
                                           ctypes.POINTER(_w.DWORD), ctypes.c_void_p]
    _wu.WinUsb_SetPipePolicy.argtypes = [ctypes.c_void_p, ctypes.c_ubyte, _w.DWORD, _w.DWORD, ctypes.c_void_p]


# Interface GUIDs seen on Ophir's WinUSB driver (StarLab 3.92). A different
# StarLab release may register others, so the registry is read as well.
KNOWN_IFACE_GUIDS = (OPHIR_IFACE_GUID,
                     "761ED34A-CCFA-416B-94BB-33486DB1F5D5",
                     "DEE824EF-729B-4A0E-9C14-B7117D33A817")


def _registry_ophir_devices():
    """[{instance, service, guids}] for every Ophir USB device Windows has seen.

    Read from HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USB, which any user may read.
    Includes unplugged devices; presence is decided by SetupAPI afterwards.
    """
    out = []
    try:
        import winreg
    except ImportError:
        return out
    base = r"SYSTEM\CurrentControlSet\Enum\USB"
    try:
        root = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base)
    except OSError:
        return out
    with root:
        i = 0
        while True:
            try:
                hw = winreg.EnumKey(root, i)
            except OSError:
                break
            i += 1
            if not hw.upper().startswith("VID_0BD3&PID_") or "&MI_" in hw.upper():
                continue
            try:
                hwkey = winreg.OpenKey(root, hw)
            except OSError:
                continue
            with hwkey:
                j = 0
                while True:
                    try:
                        inst = winreg.EnumKey(hwkey, j)
                    except OSError:
                        break
                    j += 1
                    rec = {"instance": "USB\\%s\\%s" % (hw, inst), "service": "", "guids": []}
                    try:
                        with winreg.OpenKey(hwkey, inst) as k:
                            rec["service"] = str(winreg.QueryValueEx(k, "Service")[0])
                    except OSError:
                        pass
                    try:
                        with winreg.OpenKey(hwkey, inst + r"\Device Parameters") as k:
                            for name in ("DeviceInterfaceGUIDs", "DeviceInterfaceGUID"):
                                try:
                                    v = winreg.QueryValueEx(k, name)[0]
                                except OSError:
                                    continue
                                for g in (v if isinstance(v, (list, tuple)) else [v]):
                                    g = str(g).strip().strip("{}").upper()
                                    if g and g not in rec["guids"]:
                                        rec["guids"].append(g)
                    except OSError:
                        pass
                    out.append(rec)
    return out


def _present_interface_paths(guid):
    g = _GUID.from_str(guid)
    h = _sa.SetupDiGetClassDevsW(ctypes.byref(g), None, None, 0x12)  # PRESENT | DEVICEINTERFACE
    paths, i = [], 0
    try:
        while True:
            did = _DIDATA(cbSize=ctypes.sizeof(_DIDATA))
            if not _sa.SetupDiEnumDeviceInterfaces(h, None, ctypes.byref(g), i, ctypes.byref(did)):
                break
            need = _w.DWORD()
            _sa.SetupDiGetDeviceInterfaceDetailW(h, ctypes.byref(did), None, 0, ctypes.byref(need), None)
            buf = ctypes.create_string_buffer(need.value)
            ctypes.cast(buf, ctypes.POINTER(_w.DWORD))[0] = 8
            _sa.SetupDiGetDeviceInterfaceDetailW(h, ctypes.byref(did), buf, need, None, None)
            paths.append(ctypes.wstring_at(ctypes.addressof(buf) + 4))
            i += 1
    finally:
        _sa.SetupDiDestroyDeviceInfoList(h)
    return paths


def list_usb_devices():
    """Device-interface paths of present Ophir meters, best candidate first.

    One path per physical meter. GUIDs come from the device's own registry
    entry first (whatever the installed StarLab registered), then the known
    ones. Windows only.
    """
    if not IS_WINDOWS:
        return []
    guids = []
    for rec in _registry_ophir_devices():
        for g in rec["guids"]:
            if g not in guids:
                guids.append(g)
    for g in KNOWN_IFACE_GUIDS:
        if g.upper() not in guids:
            guids.append(g.upper())
    by_device = {}
    for g in guids:
        try:
            found = _present_interface_paths(g)
        except (OSError, ValueError):
            continue
        for p in found:
            if "vid_0bd3" not in p.lower():
                continue
            dev = p.lower().rsplit("#", 1)[0]
            by_device.setdefault(dev, []).append(p)
    return [p for paths in by_device.values() for p in paths]


list_devices = list_usb_devices        # older name


def starlab_running():
    """Names of running Ophir processes that may hold the meter open."""
    if not IS_WINDOWS:
        return []
    try:
        import subprocess
        out = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True,
                             text=True, timeout=10, creationflags=0x08000000).stdout
    except Exception:                                       # noqa: BLE001
        return []
    names = set()
    for line in out.splitlines():
        name = line.split(",", 1)[0].strip('"')
        if "starlab" in name.lower() or "ophir" in name.lower():
            names.add(name)
    return sorted(names)


def usb_diagnose():
    """Plain-text report of what Windows knows about Ophir meters on USB."""
    lines = []
    A = lines.append
    if not IS_WINDOWS:
        return "USB diagnosis is Windows-only; use the RS-232 connection here."
    recs = _registry_ophir_devices()
    paths = list_usb_devices()
    present = {p.lower().rsplit("#", 1)[0] for p in paths}
    A("Ophir USB devices Windows has seen: %d" % len(recs))
    for r in recs:
        key = r["instance"].replace("\\", "#").lower()
        live = any(d.endswith(key) for d in present)
        A("  %s" % r["instance"])
        A("     driver service : %s%s" % (r["service"] or "(none -- no driver installed)",
                                          "" if r["service"].upper() in ("WINUSB", "") else
                                          "   <-- not WinUSB; this console needs WinUSB"))
        A("     interface GUIDs: %s" % (", ".join(r["guids"]) or "(none)"))
        A("     present now    : %s" % ("yes" if live else "no / not openable"))
    A("Openable interface paths: %d" % len(paths))
    for p in paths:
        A("  %s" % p)
    running = starlab_running()
    A("Ophir software running: %s" % (", ".join(running) if running else "none"))
    if running:
        A("  -> close it: StarLab holds the meter while it is open.")
    for p in paths[:3]:
        try:
            m = OphirMeter(p)
            try:
                A("Open %s ... OK: %s, firmware %s" % (p.split("#")[-1], m.query("II"), m.query("VE")))
            finally:
                m.close()
            break
        except OphirError as e:
            A("Open %s ... FAILED: %s" % (p.split("#")[-1], e))
    if not recs:
        A("No Ophir meter has ever been plugged into this computer by USB, or no driver saw it.")
    return "\n".join(lines)


class OphirMeter(_MeterBase):
    """The meter over USB through Ophir's WinUSB driver."""
    transport = "usb"

    def __init__(self, path=None, timeout_ms=6000):
        if not IS_WINDOWS:
            raise OphirError("USB access to the meter needs Windows and Ophir's WinUSB "
                             "driver; use the RS-232 connection instead")
        self._fh = None
        self._ih = None
        if path is None:
            candidates = list_usb_devices()
            if not candidates:
                raise OphirError("no Ophir USB meter present -- is it plugged in and switched on, "
                                 "with Ophir's driver (StarLab) installed? Device Manager must show "
                                 "StarBright without a yellow !. Run: python tools\\starbright.py --doctor")
        else:
            candidates = [path]
        errors = []
        for p in candidates:
            try:
                self._open(p, timeout_ms)
                return
            except OphirError as e:
                errors.append(str(e))
                self.close()
        running = starlab_running()
        hint = (" Ophir software is running (%s) and holds the meter -- close it and try again."
                % ", ".join(running)) if running else ""
        raise OphirError("could not open the meter on USB: %s.%s" % ("; ".join(errors[-2:]), hint))

    def _open(self, path, timeout_ms):
        self.path = path
        fh = _k32.CreateFileW(path, 0xC0000000, 3, None, 3, 0x40000000, None)
        if fh == ctypes.c_void_p(-1).value:
            err = _k32.GetLastError()
            why = {5: "access denied", 32: "in use by another program"}.get(err, "error %d" % err)
            raise OphirError("CreateFile: %s" % why)
        self._fh = fh
        ih = ctypes.c_void_p()
        if not _wu.WinUsb_Initialize(self._fh, ctypes.byref(ih)):
            raise OphirError("WinUsb_Initialize: error %d (driver is not WinUSB?)" % _k32.GetLastError())
        self._ih = ih
        t = _w.DWORD(timeout_ms)
        _wu.WinUsb_SetPipePolicy(self._ih, 0, 3, 4, ctypes.byref(t))  # PIPE_TRANSFER_TIMEOUT on EP0

    def close(self):
        if getattr(self, "_ih", None):
            _wu.WinUsb_Free(self._ih)
            self._ih = None
        if getattr(self, "_fh", None):
            _k32.CloseHandle(self._fh)
            self._fh = None

    def query(self, cmd):
        """Send an Ophir command (without '$') and return the reply text without the leading '*'.
        Raises OphirError on a '?' reply."""
        data = ("$%s\r\n" % cmd).encode("ascii")
        sent = _w.DWORD()
        if not _wu.WinUsb_ControlTransfer(self._ih, _SETUP(0x40, 2, 0, 0, len(data)), data, len(data),
                                          ctypes.byref(sent), None):
            raise OphirError("write '%s' failed (err %d)" % (cmd, _k32.GetLastError()))
        buf = ctypes.create_string_buffer(4096)
        got = _w.DWORD()
        if not _wu.WinUsb_ControlTransfer(self._ih, _SETUP(0xC0, 4, 0, 0, 4096), buf, 4096,
                                          ctypes.byref(got), None):
            raise OphirError("read after '%s' failed (err %d)" % (cmd, _k32.GetLastError()))
        return _parse_reply(cmd, buf.raw[: got.value].decode("ascii", "replace"))


def _parse_reply(cmd, reply):
    reply = reply.strip("\r\n \x00")
    if reply.startswith("*"):
        return reply[1:].strip()
    raise OphirError("'%s' -> %r" % (cmd, reply))


# ================================================================== RS-232 ===
# The StarBright's serial port. 8N1, no flow control. The rate is whatever the
# meter is set to (BD on meters that support it; the StarBright's is fixed in
# its setup menu), so the port is probed at the common rates until "$VE" is
# answered with "*".
SERIAL_BAUDS = (9600, 19200, 38400, 115200, 57600, 14400, 4800)
SERIAL_EOL = b"\n\r"                 # LF CR, per "Ophir User Commands"
SERIAL_TIMEOUT_S = 1.0


def _pyserial():
    try:
        import serial
        return serial
    except ImportError:
        raise OphirError("pyserial is needed for the RS-232 connection: "
                         "python -m pip install pyserial")


def list_serial_ports(exclude_ebb=True):
    """[(device, description, vid, pid)] for every serial port, EiBotBoard skipped."""
    serial = _pyserial()
    from serial.tools import list_ports
    out = []
    for p in list_ports.comports():
        if exclude_ebb and p.vid == EBB_VID and p.pid == EBB_PID:
            continue
        out.append((p.device, p.description or "", p.vid, p.pid))
    return out


class SerialMeter(_MeterBase):
    """The meter over its RS-232 port -- any COM port or USB-serial adapter.

    No Ophir driver: a USB-serial adapter uses the operating system's own
    driver. Works on Windows and Linux alike.
    """
    transport = "serial"

    def __init__(self, port=None, baud=None, exclude=()):
        serial = _pyserial()
        self.path = None
        self.baud = None
        self._ser = None
        candidates = [port] if port else [d for d, _, _, _ in list_serial_ports() if d not in exclude]
        if not candidates:
            raise OphirError("no serial port to try -- plug in the USB-serial adapter connected "
                             "to the meter's RS-232 socket, or give the port explicitly")
        errors = []
        for dev in candidates:
            for rate in ([baud] if baud else SERIAL_BAUDS):
                try:
                    s = serial.Serial(port=dev, baudrate=rate, bytesize=8, parity="N", stopbits=1,
                                      timeout=SERIAL_TIMEOUT_S, write_timeout=1.0,
                                      rtscts=False, dsrdtr=False, xonxoff=False)
                except Exception as e:                      # noqa: BLE001
                    errors.append("%s: %s" % (dev, e))
                    break                                   # port itself unusable; next port
                try:
                    s.reset_input_buffer()
                    reply = self._exchange(s, "VE")
                    if reply.startswith("*"):
                        self._ser, self.path, self.baud = s, dev, rate
                        return
                    errors.append("%s @%d: unexpected reply %r" % (dev, rate, reply[:20]))
                except Exception as e:                      # noqa: BLE001
                    errors.append("%s @%d: %s" % (dev, rate, e))
                s.close()
        raise OphirError("no Ophir meter answered on %s (tried %s). Check the RS-232 cable, "
                         "that the meter is on, and its serial settings. Details: %s"
                         % (", ".join(candidates), "/".join(str(b) for b in (SERIAL_BAUDS if not baud else [baud])),
                            "; ".join(errors[-3:])))

    @staticmethod
    def _exchange(ser, cmd):
        """Write "$cmd" LF CR, read up to LF CR (or timeout). Returns the raw text."""
        ser.write(("$%s" % cmd).encode("ascii") + SERIAL_EOL)
        ser.flush()
        buf = bytearray()
        deadline = time.monotonic() + SERIAL_TIMEOUT_S * 3
        while time.monotonic() < deadline:
            chunk = ser.read(1)
            if not chunk:
                if buf:
                    break                       # quiet after some data: done
                continue
            buf += chunk
            if buf.endswith(SERIAL_EOL) or buf.endswith(b"\r\n"):
                break
        return buf.decode("ascii", "replace").strip("\r\n \x00")

    def query(self, cmd):
        if self._ser is None:
            raise OphirError("serial meter is closed")
        try:
            self._ser.reset_input_buffer()
            reply = self._exchange(self._ser, cmd)
        except Exception as e:                              # noqa: BLE001
            raise OphirError("serial '%s': %s" % (cmd, e))
        if not reply:
            raise OphirError("'%s' -> no reply on %s (cable? meter off?)" % (cmd, self.path))
        return _parse_reply(cmd, reply)

    def close(self):
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:                               # noqa: BLE001
                pass
            self._ser = None


# =============================================================== simulator ===
class SimulatedMeter(_MeterBase):
    """Stand-in with the same surface, for --sim dry runs.

    Produces an irradiance field that varies smoothly with the (simulated)
    jig position, plus noise, plus a decaying transient after every move so
    the console's settle detection has something real to wait for.
    """
    path = "sim"
    transport = "sim"

    def __init__(self, base=2.5e-3, noise=0.004, transient_s=1.2):
        import random
        self._rand = random.Random(7)
        self.base = base
        self.noise = noise
        self.transient_s = transient_s
        self._disturbed = 0.0
        self.pos = (0, 0)
        self.wavelength = 405
        self.range_idx = -1
        try:
            import ebb_sim
            ebb_sim.shared_board().on_move = self._moved
        except Exception:                                   # noqa: BLE001
            pass

    def _moved(self, dx, dz):
        self.pos = (self.pos[0] + dx, self.pos[1] + dz)
        self._disturbed = time.monotonic()

    def query(self, cmd):
        c = cmd.split()
        k = c[0].upper()
        if k == "VE":
            return "SIM1.00"
        if k == "II":
            return "SIM 000000 SimulatedMeter"
        if k == "HI":
            return "SI 000000 PD300RM-SIM   00400001"
        if k == "HT":
            return "RM w"
        if k == "SI":
            return "w"
        if k == "AR":
            return ("%d AUTO 30.0W/cm^2 3.00W/cm^2 300mW/cm^2 30.0mW/cm^2 3.00mW/cm^2 300uW/cm^2 30.0uW/cm^2"
                    % max(self.range_idx, 0))
        if k == "GU":
            return "2"
        if k == "SX":
            return "3.000E-1"
        if k == "AW":
            favs = [375, 395, 385, 450, 405]
            idx = favs.index(self.wavelength) + 1 if self.wavelength in favs else 1
            return "CONTINUOUS 350 850 %d %s NONE" % (idx, " ".join(str(f) for f in favs))
        if k == "MM":
            return "9"
        if k == "WL":
            self.wavelength = int(c[1])
            return ""
        if k == "WN":
            self.range_idx = int(c[1])
            return ""
        if k == "SP":
            return "%.3E" % self.power()
        raise OphirError("'%s' -> '?UC'" % cmd)

    def wavelength_nm(self):
        return self.wavelength

    def set_wavelength(self, nm):
        self.wavelength = int(nm)

    def set_range(self, index):
        self.range_idx = int(index)

    def power(self):
        import math
        y_mm = -self.pos[0] / 800.0
        z_mm = self.pos[1] / 128.0
        field = self.base * (1.0 + 0.25 * math.cos(y_mm / 60.0) * math.exp(-((z_mm - 150.0) / 220.0) ** 2))
        dt = time.monotonic() - self._disturbed
        transient = 0.35 * math.exp(-dt / max(1e-3, self.transient_s / 3.0)) if dt < self.transient_s else 0.0
        return field * (1.0 + transient + self._rand.gauss(0.0, self.noise))


# ================================================================= factory ===
def open_meter(kind=None, port=None, exclude_ports=()):
    """Open the meter by connection kind.

    kind:  "auto"          USB if the driver is there, otherwise RS-232 (default)
           "usb"           WinUSB through Ophir's driver (Windows)
           "serial"        RS-232, port auto-detected (EiBotBoard's port skipped)
           "serial:COM5"   RS-232 on that port ("serial:/dev/ttyUSB0" on Linux)
           "sim"           simulated meter
    Falls back to UVJIG_METER when kind is None/empty.
    """
    kind = (kind or os.environ.get("UVJIG_METER") or "auto").strip()
    low = kind.lower()
    if low == "sim":
        return SimulatedMeter()
    if low.startswith("serial"):
        p = port or (kind.split(":", 1)[1] if ":" in kind else None) or None
        return SerialMeter(p, exclude=exclude_ports)
    if low == "usb":
        return OphirMeter()
    # auto: USB first (instant when the driver is present), then RS-232.
    usb_err = None
    if IS_WINDOWS:
        try:
            if list_usb_devices():
                return OphirMeter()
            usb_err = "no meter on USB with Ophir's driver"
        except Exception as e:                              # noqa: BLE001
            usb_err = str(e)
    else:
        usb_err = "USB needs Windows"
    try:
        return SerialMeter(port, exclude=exclude_ports)
    except OphirError as e:
        raise OphirError("%s; RS-232: %s" % (usb_err, e))


def main():
    ap = argparse.ArgumentParser(description="Talk to an Ophir StarBright over USB or RS-232")
    ap.add_argument("--cmd", action="append", help="raw command without '$' (repeatable)")
    ap.add_argument("--stream", type=float, metavar="SECONDS", help="stream power readings")
    ap.add_argument("--sim", action="store_true", help="use the simulated meter, no hardware")
    ap.add_argument("--serial", nargs="?", const="", metavar="PORT",
                    help="use RS-232; PORT optional (auto-detects, skipping the EiBotBoard)")
    ap.add_argument("--baud", type=int, default=None, help="RS-232 rate (default: probe)")
    ap.add_argument("--ports", action="store_true", help="list serial ports and exit")
    ap.add_argument("--doctor", action="store_true",
                    help="report what Windows knows about the meter on USB (driver, StarLab, open test)")
    a = ap.parse_args()

    if a.doctor:
        print(usb_diagnose())
        return

    if a.ports:
        for dev, desc, vid, pid in list_serial_ports(exclude_ebb=False):
            tag = "  (EiBotBoard, not the meter)" if (vid, pid) == (EBB_VID, EBB_PID) else ""
            print("%-12s %s%s%s" % (dev, desc, ("  %04x:%04x" % (vid, pid)) if vid else "", tag))
        return
    if a.sim:
        m = SimulatedMeter()
    elif a.serial is not None:
        m = SerialMeter(a.serial or None, baud=a.baud)
        print("RS-232 meter on %s at %d baud" % (m.path, m.baud))
    else:
        paths = list_usb_devices()
        print("%d Ophir USB meter(s):" % len(paths), *paths, sep="\n  ")
        if not paths:
            print("(no driver-bound USB meter; try --serial for RS-232)")
            sys.exit(1)
        m = OphirMeter(paths[0])
    with m:
        if a.cmd:
            for c in a.cmd:
                try:
                    print("$%-8s -> %s" % (c, m.query(c)))
                except OphirError as e:
                    print("$%-8s -> ERROR %s" % (c, e))
            return
        for k, v in m.identify().items():
            print("%-17s: %s" % (k, v))
        units = m.query("SI")
        unit_name = UNIT_NAMES.get(units, units)
        print("%-17s: %s nm" % ("wavelength", m.wavelength_nm()))
        print("%-17s: %.4g %s" % ("reading", m.power(), unit_name))
        if a.stream:
            print("--- streaming %.0f s (%s) ---" % (a.stream, unit_name))
            t_end = time.time() + a.stream
            while time.time() < t_end:
                print("%s  %.4g" % (time.strftime("%H:%M:%S"), m.power()))
                time.sleep(0.25)


if __name__ == "__main__":
    main()
