#!/usr/bin/env python3
"""Home the driven Y axis against its mechanical stop and zero there.

Board axis 1 = the chamber's Y. (The file keeps its old name so existing
notes and scripts still find it.)

    python3 tools/home_x.py                    # dry run, prints the plan
    DO_MOVE=1 python3 tools/home_x.py          # counter-based
    DO_MOVE=1 python3 tools/home_x.py --blind  # ignore the counter, full travel

Sensorless homing: the stop IS the datum, and unlike a step counter it cannot
drift. It skids audibly for a couple of seconds at the end -- that contact is
the reference, not a fault.

Counter-based homing trusts the counter for the DISTANCE to the stop. If the
counter was zeroed somewhere other than the stop it will report "already there"
and barely move, so use --blind after any manual re-zero.

NOTE: this ends in CS, which zeroes BOTH counters -- the board has no per-axis
clear. Put Z on its own origin first, or Z's frame is destroyed too.
"""

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serial_min import Serial, SerialError, show, resolve_port     # noqa: E402
import ebb                                                          # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Home the driven Y axis against its stop.")
    ap.add_argument("--blind", action="store_true",
                    help="ignore the counter; drive the whole axis into the stop")
    ap.add_argument("--rev", type=float, default=None,
                    help="blind distance in rotations (implies --blind)")
    ap.add_argument("--allow-z", action="store_true",
                    help="home even though Z is off its origin (destroys Z's frame)")
    ap.add_argument("--port", default=None)
    args = ap.parse_args()

    limits = ebb.load_limits()
    blind = args.rev if args.rev is not None else (0 if args.blind else None)

    print("=" * 70)
    print("Y HOMING -- ends by driving into the mechanical stop on purpose")
    print("=" * 70)

    try:
        with Serial(resolve_port(args.port)) as p:
            if p.sync() is None:
                print("FAIL: could not synchronise with the EBB; not homing.")
                return 2

            pos = ebb.read_position(p)
            counts = ebb.read_vplus(p)
            print("  position  : %s" % (pos,))
            print("  V+        : %s counts -- supply %s"
                  % (counts, "PRESENT" if ebb.supply_present(counts) else "MISSING"))
            if not ebb.supply_present(counts):
                print("\nFAIL: no motor supply. The board will count steps and")
                print("      nothing will turn. Switch the DC supply on.")
                return 2

            if pos is not None and pos[1] != 0 and not args.allow_z:
                print("\nREFUSED: Z is at %d, not 0. Homing ends in CS, which zeroes"
                      % pos[1])
                print("         BOTH counters, so Z's origin would go too. Put Z on")
                print("         its bottom stop first, or pass --allow-z.")
                return 1

            plan, revs = ebb.home_plan(limits, pos, blind_rev=blind)
            if revs is not None:
                print("  mode      : BLIND -- %.1f rev, counter ignored" % revs)
                print("              It will skid from whenever it arrives.")
            else:
                print("  mode      : counter-based, %d steps to the stop"
                      % ((limits or {}).get("y", {}).get("max", 0) - pos[0]))
            total = sum(abs(s) / r for s, r, _ in plan)
            print("  total     : ~%.0f s" % total)
            for steps, rate, label in plan:
                print("     %-16s %+8d steps at %.0f steps/s" % (label, steps, rate))

            if os.environ.get("DO_MOVE") != "1":
                print("\nDRY RUN -- nothing transmitted. Re-run with DO_MOVE=1.")
                return 0

            print()
            for steps, rate, label in plan:
                for cx, cz, cd in ebb.split_move(steps, 0, rate):
                    print("  %-16s SM,%d,%d,0" % (label, cd, cx))
                    sys.stdout.flush()
                    ebb.send_move(p, cx, cz, cd)
                    time.sleep(ebb.move_duration_s(cd))

            time.sleep(0.5)
            print("\n  -> CS   (zeroes BOTH counters)")
            print("  <- %s" % show(ebb.zero_counters(p)).strip())
            time.sleep(0.2)
            print("  QS after = %s   <- X = 0 at the physical stop"
                  % (ebb.read_position(p),))
    except SerialError as e:
        print("\nFAIL: %s" % e)
        return 2

    print("\nRESULT: Y homed. The counter now agrees with a physical datum.")
    print("Usable travel from here is in the -Y direction.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
