#!/usr/bin/env python3
"""Aim the sensor servo, driven by the EiBotBoard's own RC servo output.

    python3 tools/servo_ctl.py              # report, do not move
    python3 tools/servo_ctl.py 90           # go to 90 degrees (UP)
    python3 tools/servo_ctl.py 270          # DOWN -- the 270-degree servo's far end
    python3 tools/servo_ctl.py --us 1500    # raw pulse width
    python3 tools/servo_ctl.py --sweep      # 90, 0, 90, 180, 270, 180, 90
    python3 tools/servo_ctl.py --faces      # BACK, UP, FRONT, DOWN with a pause at each

Orientation: 0 = BACK, 90 = UP, 180 = FRONT, 270 = DOWN. Check all four on
the bench after any remount -- a swapped label survives into the final map.
    python3 tools/servo_ctl.py --off        # stop driving it

No DO_MOVE gate: this is a small positioner with nothing to crash into, and
every command is acknowledged, so a wrong one is obvious immediately. The
steppers are gated -- see move_ebb.py.

--off matters. A servo held against a mechanical limit buzzes and draws stall
current continuously; if it hums after arriving, turn it off.
"""

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serial_min import (Serial, SerialError, lines, show,          # noqa: E402
                        resolve_port, describe_ports)
import ebb                                                          # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Aim the jig servo via the EBB.")
    ap.add_argument("angle", nargs="?", type=float,
                    help="target angle, 0-%g" % ebb.SERVO_MAX_DEG)
    ap.add_argument("--us", type=int, help="raw pulse width (%d-%d)"
                    % (ebb.SERVO_US_AT_0DEG, ebb.SERVO_US_AT_MAX))
    ap.add_argument("--sweep", action="store_true", help="sweep and return to 90")
    ap.add_argument("--faces", action="store_true",
                    help="visit the four scan faces BACK/UP/FRONT/DOWN, then UP")
    ap.add_argument("--off", action="store_true", help="stop driving the servo")
    ap.add_argument("--dwell", type=float, default=0.8,
                    help="extra pause at each sweep stop, on top of the travel time")
    ap.add_argument("--port", default=None)
    args = ap.parse_args()

    port = resolve_port(args.port)
    if port.startswith("/dev") and not os.path.exists(port):
        print("FAIL: %s does not exist -- EBB unplugged?" % port)
        for p in describe_ports():
            print("      seen: %s" % p)
        return 2

    try:
        with Serial(port) as p:
            if p.sync() is None:
                print("FAIL: no EBB banner on %s -- wrong device?" % port)
                return 2
            print("board   : %s" % (lines(p.ask("V")) or ["?"])[0])
            print("servo   : RP%d (%s), %d-%d us = 0-%g deg"
                  % (ebb.SERVO_PIN, "RB1", ebb.SERVO_US_AT_0DEG,
                     ebb.SERVO_US_AT_MAX, ebb.SERVO_MAX_DEG))
            print("faces   : 0 BACK  90 UP  180 FRONT  270 DOWN")

            if args.off:
                print("off     : %s" % show(ebb.servo_off(p)).strip())
                return 0

            if args.sweep or args.faces:
                stops = ((0, 90, 180, 270, 90) if args.faces
                         else (90, 0, 90, 180, 270, 180, 90))
                names = {0: "BACK", 90: "UP", 180: "FRONT", 270: "DOWN"}
                last = None
                for a in stops:
                    us = ebb.servo_set_angle(p, a, settle=0)
                    print("  %-5.0f deg -> %4d us  %s" % (a, us, names.get(a, "")))
                    sys.stdout.flush()
                    # Let the horn actually get there before the next stop.
                    time.sleep(ebb.servo_travel_s(last, a) + args.dwell)
                    last = a
                return 0

            if args.us is not None:
                us = ebb.servo_set_us(p, args.us)
                print("  %d us -> about %.0f deg" % (us, ebb.us_to_angle(us)))
                return 0

            if args.angle is not None:
                us = ebb.servo_set_angle(p, args.angle)
                print("  %.0f deg -> %d us" % (args.angle, us))
                return 0

            # No argument: report only. The EBB cannot read a servo's actual
            # position back -- an RC servo has no feedback path -- so there is
            # deliberately nothing to print here but the mapping above.
            print("state   : no target given, nothing moved.")
            print("          RC servos report no position; the board only sends")
            print("          pulses. Pass an angle to command one.")
    except SerialError as e:
        print("FAIL: %s" % e)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
