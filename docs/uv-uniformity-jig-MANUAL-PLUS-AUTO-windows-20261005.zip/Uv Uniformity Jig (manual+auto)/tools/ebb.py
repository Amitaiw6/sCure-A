"""EiBotBoard protocol layer: both steppers AND the RC servo.

Everything the jig can do lives here, so the CLI tools and the web console
share one implementation and cannot drift apart.

--------------------------------------------------------------- the board ---

One SchmalzHaus EiBotBoard (04d8:fd92) drives all three motors:

    axis 1  -> chamber Y stepper  (the driven horizontal lead screw)
    axis 2  -> chamber Z stepper
    (the chamber's X is the layer axis, moved by hand -- no motor)
    RB1     -> RC servo that aims the sensor   (RP4 in the S2 command)

The servo used to hang off a separate Arduino running custom firmware. It does
not any more: the EBB has a general RC servo output and generates the pulse
train in hardware, which removes a board, a USB port, a firmware build
toolchain, and the DTR-reset dance that came with talking to an Uno.

------------------------------------------------------------ two gotchas ----

**Never send EM.** It looks like a harmless "enable motors" command and it
silently zeroes both step counters. Proved by experiment: CS -> 0,0; SM -> 50,0;
SM -> 100,0; EM -> 0,0. Absolute position is destroyed with no error and no
outward sign. Set the step mode explicitly only when you actually mean to.

**Say nothing while an axis is moving.** The EBB generates step pulses from a
timer interrupt on a PIC. Servicing USB CDC traffic mid-move competes with that
generator: polling QM every 50 ms produced audible stutter and lost steps on
this jig, while a script that sends the move and then shuts up runs smoothly.
Send, wait out the duration, then verify.
"""

import json
import os
import time

from serial_min import lines, SerialError

# ------------------------------------------------------------- steppers ----
AXIS_NAMES = {1: "Y", 2: "Z"}   # board axis 1 drives the chamber's Y

SM_MIN_DURATION_MS = 1
SM_MAX_DURATION_MS = 16777215
SM_MAX_STEPS = 25000000
RATE_MIN_HZ = 1.31          # below this the EBB rejects the move
RATE_MAX_HZ = 25000.0       # above this it drops steps

# A single SM longer than this runs slower than commanded: the duration field
# overflows the rate calculation. 153,600 steps asked for 1600 steps/s and
# delivered about 1010. Split anything larger.
SM_MAX_STEPS_PER_CMD = 100000

# Working rates come from limits.json so there is ONE place to change them.
# The constants below are only the fallback if the file is missing.
_LIMITS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            os.pardir, "limits.json")


def _rate(axis, default):
    try:
        with open(_LIMITS_FILE) as fh:
            return float((json.load(fh).get(axis) or {}).get("rate_hz", default))
    except (OSError, ValueError, TypeError):
        return default


Y_RATE_HZ = _rate("y", 1600.0)
Z_RATE_HZ = _rate("z", 800.0)
HOMING_FAST_HZ = 1600.0
HOMING_SLOW_HZ = 400.0

MICROSTEP = {1: "1/16", 2: "1/8", 3: "1/4", 4: "1/2", 5: "full"}

# --------------------------------------------------------------- servo -----
# S2,<position>,<output_pin>,<rate>,<delay>
#   position   : pulse width in units of 1/12 us  (1500 us -> 18000)
#   output_pin : RPn number. RP4 = RB1 = the EBB's own servo header.
#   rate       : 0 = step straight there; otherwise the slew, in 1/12-us
#                units per 24 ms channel period, so the board ramps the pulse
#   delay      : ms to hold the command channel afterwards
#
# 2026-10-05: the servo is a 270-degree unit (it was a 180-degree MG90S). The
# same 500-2500 us pulse range now spans 0-270 deg, and that extra quarter
# turn is what lets the DOWN face join the servo-aimed phase of the scan:
#     0 = BACK, 90 = UP, 180 = FRONT, 270 = DOWN.
# The numbers live in limits.json under "servo"; the literals below are only
# the fallback if the file is missing.
SERVO_PIN = 4
SERVO_UNITS_PER_US = 12


def _servo_cfg():
    try:
        with open(_LIMITS_FILE) as fh:
            return json.load(fh).get("servo") or {}
    except (OSError, ValueError, TypeError, AttributeError):
        return {}


_SV = _servo_cfg()
SERVO_US_AT_0DEG = int(_SV.get("us_at_0deg", 500))
# An older limits.json carries "us_at_180deg" and no "max_deg": honour it as
# the 180-degree servo it describes rather than stretching it to 270.
SERVO_US_AT_MAX = int(_SV.get("us_at_max_deg", _SV.get("us_at_180deg", 2500)))
SERVO_MAX_DEG = float(_SV.get(
    "max_deg",
    180 if ("us_at_180deg" in _SV and "us_at_max_deg" not in _SV) else 270))
# The wait before a reading is trusted: a floor after any command (the horn
# stopping, the mount ringing) plus travel time per degree actually moved. A
# 90-deg face change costs ~0.6 s and the full 270 ~1.2 s, instead of one
# fixed figure that was too short for the long swings.
SERVO_SETTLE_S = float(_SV.get("settle_s", 0.35))
SERVO_S_PER_DEG = float(_SV.get("s_per_deg", 0.003))
# S2 slew rate. 0 lets the servo run at its own full speed; a value makes the
# board ramp the pulse instead -- useful if the horn arrives harshly or the
# supply sags on the step -- and servo_travel_s() allows for the slower move.
SERVO_SLEW_RATE = int(_SV.get("slew_rate", 0))
del _SV

LIMITS_FILE = _LIMITS_FILE


# ------------------------------------------------------------- limits ------
def load_limits():
    """Read soft travel limits. Returns None if unavailable -- absence disables
    the check rather than blocking work."""
    try:
        with open(LIMITS_FILE) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def check_limits(limits, pos, dy, dz):
    """Return a list of human-readable violations for the proposed move.

    Advisory by nature: these bound the step COUNTER, and on an axis that can
    slip the counter drifts from physical reality. Still catches sign errors and
    arithmetic mistakes, which are the usual way to drive into a stop.

    Homing deliberately violates them -- see home_plan().
    """
    if not limits or pos is None:
        return []
    problems = []
    for axis, cur, d in (("y", pos[0], dy), ("z", pos[1], dz)):
        if d == 0:
            continue
        spec = limits.get(axis) or {}
        lo, hi = spec.get("min"), spec.get("max")
        target = cur + d
        if lo is not None and target < lo:
            problems.append("%s would reach %d, below the limit %d (by %d steps, %.2f rev)"
                            % (axis.upper(), target, lo, lo - target,
                               (lo - target) / 3200.0))
        if hi is not None and target > hi:
            problems.append("%s would reach %d, above the limit %d (by %d steps, %.2f rev)"
                            % (axis.upper(), target, hi, target - hi,
                               (target - hi) / 3200.0))
    return problems


# -------------------------------------------------------------- queries ----
def parse_qs(qs):
    """'1600,0' -> (1600, 0). Returns None if it does not parse cleanly."""
    parts = [p.strip() for p in (qs or "").split(",")]
    if len(parts) != 2:
        return None
    try:
        return int(parts[0]), int(parts[1])
    except ValueError:
        return None


# Queries the board terminates with OK can return the moment it arrives. The
# long quiet window stays the default everywhere else.
FAST_QUIET, FAST_OVERALL = 0.06, 1.5


def read_position(port):
    """Current (Y, Z) step counters, or None."""
    got = lines(port.ask("QS", quiet=FAST_QUIET, overall=FAST_OVERALL, want=b"OK"))
    return parse_qs(got[0]) if got else None


def read_vplus(port):
    """Motor supply rail in ADC counts, or None.

    ~819 counts with the supply on, near zero without. This is the only warning
    you get: the board enumerates, accepts commands and counts steps perfectly
    happily with the external supply switched off, while nothing turns.
    """
    got = lines(port.ask("QC", quiet=FAST_QUIET, overall=FAST_OVERALL, want=b"OK"))
    if not got:
        return None
    parts = [x.strip() for x in got[0].split(",")]
    if len(parts) == 2 and all(x.isdigit() for x in parts):
        return int(parts[1])
    return None


def supply_present(counts):
    return counts is not None and counts > 300


def read_state(port):
    """Version, position and rail. Pure reads -- nothing moves."""
    state = {}
    state["V"] = (lines(port.ask("V")) or ["<no reply>"])[0]
    for cmd in ("QS", "QM", "QC"):
        got = lines(port.ask(cmd))
        state[cmd] = got[0] if got else ""
    return state


# ---------------------------------------------------------------- moves ----
def plan_move(steps_y, steps_z, rate_hz):
    """Work out the SM duration and validate it. Returns (duration_ms, notes)."""
    notes = []
    biggest = max(abs(steps_y), abs(steps_z))
    if biggest == 0:
        raise ValueError("no motion requested")
    if abs(steps_y) > SM_MAX_STEPS or abs(steps_z) > SM_MAX_STEPS:
        raise ValueError("step count exceeds EBB limit of %d" % SM_MAX_STEPS)

    duration_ms = int(round(biggest / float(rate_hz) * 1000.0))
    duration_ms = max(SM_MIN_DURATION_MS, min(SM_MAX_DURATION_MS, duration_ms))

    # A single SM shares one duration across both axes, so the shorter axis
    # moves slower. Both resulting rates must sit inside the EBB's window.
    for steps, axis in ((steps_y, 1), (steps_z, 2)):
        if steps == 0:
            continue
        rate = abs(steps) / (duration_ms / 1000.0)
        if rate > RATE_MAX_HZ:
            raise ValueError("axis %s rate %.1f Hz exceeds max %.0f Hz -- lower the rate"
                             % (AXIS_NAMES[axis], rate, RATE_MAX_HZ))
        if rate < RATE_MIN_HZ:
            raise ValueError("axis %s rate %.2f Hz is below the EBB minimum %.2f Hz "
                             "-- raise the rate or move the axes separately"
                             % (AXIS_NAMES[axis], rate, RATE_MIN_HZ))
        notes.append("axis %s: %+d steps at %.1f steps/s" % (AXIS_NAMES[axis], steps, rate))
    return duration_ms, notes


def split_move(steps_y, steps_z, rate_hz, limit=SM_MAX_STEPS_PER_CMD):
    """Split a move into SM chunks small enough to hit the commanded rate.

    Returns [(steps_y, steps_z, duration_ms), ...]. Chunk boundaries come from
    cumulative targets so rounding cannot lose or gain a step: the chunks always
    sum exactly to the requested totals.
    """
    biggest = max(abs(steps_y), abs(steps_z))
    n = max(1, (biggest + limit - 1) // limit)
    chunks = []
    done_y = done_z = 0
    for i in range(1, n + 1):
        cx = int(round(steps_y * i / float(n))) - done_y
        cz = int(round(steps_z * i / float(n))) - done_z
        done_y += cx
        done_z += cz
        if cx == 0 and cz == 0:
            continue
        dur = int(round(max(abs(cx), abs(cz)) / float(rate_hz) * 1000.0))
        dur = max(SM_MIN_DURATION_MS, min(SM_MAX_DURATION_MS, dur))
        chunks.append((cx, cz, dur))
    assert done_y == steps_y and done_z == steps_z, "chunking lost steps"
    return chunks


def send_move(port, steps_y, steps_z, duration_ms):
    """Issue one SM. Does NOT wait -- the caller decides how to pass the time."""
    reply = port.ask("SM,%d,%d,%d" % (duration_ms, steps_y, steps_z),
                     quiet=0.2, overall=2.0)
    if reply and reply.lstrip().startswith(b"!"):
        raise SerialError("EBB rejected SM,%d,%d,%d"
                          % (duration_ms, steps_y, steps_z))
    return reply


MOVE_PAD_S = 0.15


def move_duration_s(duration_ms):
    """How long to stay off the wire for a move of this length.

    The duration is what we told the board, so it is known precisely; the pad is
    only insurance against clock skew and USB latency. It was 0.4 s, which at 540
    points cost 3.6 minutes of doing nothing.
    """
    return duration_ms / 1000.0 + MOVE_PAD_S


def zero_counters(port):
    """CS. Zeroes BOTH axes -- the board has no per-axis clear, so only do this
    with X and Z each sitting on a known reference."""
    return port.ask("CS")


def emergency_stop(port):
    """ES, sent with no preamble. Abandons the move in progress."""
    return port.write("ES\r")


# --------------------------------------------------------------- homing ----
def home_plan(limits, pos, blind_rev=None):
    """Plan the move sequence that seats the driven Y axis against its stop.

    Returns [(steps, rate_hz, label), ...]. +Y drives into the origin stop.

    Sensorless: the stop IS the datum. A fast approach to within half a turn,
    then a slow seat with a deliberate quarter-turn of overshoot -- that
    overshoot is the skid you hear, and that contact is the reference.

    These moves must BYPASS check_limits. Homing ends past y.max by design, and
    checking a move against the very counter it exists to re-anchor makes it
    impossible.

    blind_rev ignores the counter and drives a fixed distance. Default is the
    whole axis plus margin, so it reaches the stop from anywhere -- use it
    whenever the counter has been zeroed somewhere other than the stop.
    """
    lim = (limits or {}).get("y") or {}
    per_rev = (limits or {}).get("steps_per_rev", 3200)
    stop = lim.get("max", 0)
    seat = int(round(0.5 * per_rev))
    margin = int(round(0.25 * per_rev))
    direction = +1

    if blind_rev is not None or pos is None:
        default_rev = (lim.get("travel_rev") or 38.0) + 2.0
        revs = blind_rev if blind_rev else default_rev
        total = int(round(revs * per_rev))
        seat_part = seat + margin
        plan = []
        if total - seat_part > 0:
            plan.append((direction * (total - seat_part), HOMING_FAST_HZ,
                         "blind approach"))
        plan.append((direction * seat_part, HOMING_SLOW_HZ, "blind seat"))
        return plan, revs

    to_stop = stop - pos[0]
    plan = []
    approach = to_stop - direction * seat
    if direction * approach > 0:
        plan.append((approach, HOMING_FAST_HZ, "approach"))
    plan.append((direction * (seat + margin), HOMING_SLOW_HZ, "seat"))
    return plan, None


# ---------------------------------------------------------------- servo ----
def angle_to_us(deg):
    """Map 0..SERVO_MAX_DEG degrees onto this servo's pulse-width range."""
    deg = max(0.0, min(SERVO_MAX_DEG, float(deg)))
    span = SERVO_US_AT_MAX - SERVO_US_AT_0DEG
    return int(round(SERVO_US_AT_0DEG + (deg / SERVO_MAX_DEG) * span))


def us_to_angle(us):
    span = SERVO_US_AT_MAX - SERVO_US_AT_0DEG
    return (us - SERVO_US_AT_0DEG) * SERVO_MAX_DEG / span


def servo_travel_s(from_deg, to_deg, rate=None):
    """How long to allow for the horn to arrive at `to_deg`.

    `from_deg` is the last angle commanded, or None when nobody knows where the
    horn is (power-up, output switched off), in which case the whole range is
    assumed. With a non-zero S2 slew rate the board paces the move itself, so
    the allowance is whichever of the two is longer.
    """
    if from_deg is None:
        delta = SERVO_MAX_DEG
    else:
        delta = abs(float(to_deg) - float(from_deg))
    travel = delta * SERVO_S_PER_DEG
    rate = SERVO_SLEW_RATE if rate is None else rate
    if rate > 0:
        units = ((delta / SERVO_MAX_DEG) * (SERVO_US_AT_MAX - SERVO_US_AT_0DEG)
                 * SERVO_UNITS_PER_US)
        travel = max(travel, units / float(rate) * 0.024)
    return SERVO_SETTLE_S + travel


def servo_set_us(port, us, rate=None, delay=0):
    """Command the servo to a raw pulse width."""
    us = max(SERVO_US_AT_0DEG, min(SERVO_US_AT_MAX, int(us)))
    rate = SERVO_SLEW_RATE if rate is None else rate
    cmd = "S2,%d,%d,%d,%d" % (us * SERVO_UNITS_PER_US, SERVO_PIN, rate, delay)
    reply = port.ask(cmd, quiet=0.4, overall=3.0)
    if reply and reply.lstrip().startswith(b"!"):
        raise SerialError("EBB rejected %s" % cmd)
    return us


def servo_set_angle(port, deg, settle=SERVO_SETTLE_S):
    us = servo_set_us(port, angle_to_us(deg))
    if settle:
        time.sleep(settle)
    return us


def servo_off(port):
    """Stop generating pulses, so the horn goes limp.

    Worth doing if it buzzes after arriving: a servo held against a mechanical
    limit draws stall current continuously.
    """
    return port.ask("S2,0,%d,0,0" % SERVO_PIN, quiet=0.4, overall=3.0)
