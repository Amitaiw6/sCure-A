"""A fake EiBotBoard, for testing without hardware. Pure Python, no pty.

Two ways to use it:

  * In-process, on any platform:  set UVJIG_EBB_PORT=sim (or run the console
    with --sim). tools/serial_min.py then hands the console a Serial object
    that answers from a FakeEBB instead of opening a port.
  * On a virtual serial port (Linux only): web/simulate_jig.py wraps FakeEBB in
    a pty so any external client can talk to it.

It speaks enough of the EBB protocol for the console to be fully driveable --
V, QS, QC, QM, SM, CS, ES, EM and the S2 RC-servo command. Moves take real
time, exactly as on the bench, so the timings the console shows are honest.

NOT a model of the machine: no slip, no stalling, no travel limits. It will
happily "move" somewhere the real jig cannot reach.
"""

import re
import threading
import time

FIRMWARE = "EBBv13_and_above EB Firmware Version 2.8.1"
VPLUS_COUNTS = 819          # what a healthy supply reads on the real board


class FakeEBB(object):
    def __init__(self):
        self.x = 0
        self.z = 0
        self.moving_until = 0.0
        self.pending = None
        self.servo_us = None
        self.lock = threading.Lock()
        # Anything interested in "the jig just moved" (the simulated meter)
        # can hook this; called with (dx, dz) when a move is issued.
        self.on_move = None

    def _settle(self):
        """Apply a move once its duration has elapsed, like the real board."""
        with self.lock:
            if self.pending and time.monotonic() >= self.moving_until:
                dx, dz = self.pending
                self.x += dx
                self.z += dz
                self.pending = None

    def handle(self, cmd):
        self._settle()
        c = cmd.strip()
        if not c:
            return None
        up = c.upper()
        if up == "V":
            return FIRMWARE
        if up == "QS":
            with self.lock:
                return "%d,%d\r\nOK" % (self.x, self.z)
        if up == "QC":
            return "0000,%04d\r\nOK" % VPLUS_COUNTS
        if up == "QM":
            busy = 1 if self.pending else 0
            return "QM,%d,%d,%d,0\r\nOK" % (busy, busy, busy)
        if up == "QP":
            return "1\r\nOK"
        if up == "QG":
            return "3E\r\nOK"
        if up == "CS":
            with self.lock:
                self.x = self.z = 0
                self.pending = None
            return "OK"
        if up == "ES" or up.startswith("ES,"):
            with self.lock:
                # A real ES abandons the move partway. Land somewhere plausible
                # rather than pretending it completed.
                if self.pending:
                    dx, dz = self.pending
                    self.x += dx // 2
                    self.z += dz // 2
                    self.pending = None
            return "0,0,0,0\r\nOK"
        if up.startswith("EM,"):
            with self.lock:
                self.x = self.z = 0          # EM really does zero the counters
            return "OK"
        m = re.match(r"^S2,(\d+),(\d+)(?:,(-?\d+))?(?:,(-?\d+))?$", up)
        if m:
            units = int(m.group(1))
            self.servo_us = units / 12.0 if units else None
            return "OK"
        m = re.match(r"^SM,(-?\d+),(-?\d+)(?:,(-?\d+))?$", up)
        if m:
            dur = int(m.group(1))
            dx = int(m.group(2))
            dz = int(m.group(3) or 0)
            with self.lock:
                self.pending = (dx, dz)
                self.moving_until = time.monotonic() + dur / 1000.0
            if self.on_move and (dx or dz):
                try:
                    self.on_move(dx, dz)
                except Exception:                           # noqa: BLE001
                    pass
            return "OK"
        return "!8 Err: Unknown command '%s'" % c


# One board per process, so a simulated meter can find it and react to moves.
_SHARED = None
_SHARED_LOCK = threading.Lock()


def shared_board():
    global _SHARED
    with _SHARED_LOCK:
        if _SHARED is None:
            _SHARED = FakeEBB()
        return _SHARED
