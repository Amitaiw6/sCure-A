#!/usr/bin/env bash
# Build the transfer packages for another computer.
#
#   bash make-package.sh            # both, into the parent directory
#   bash make-package.sh --out DIR  # somewhere else
#
# Produces (this is the MANUAL + AUTOMATIC build -- the names say so, so it can
# never be confused with the manual-only package):
#   uv-uniformity-jig-MANUAL-PLUS-AUTO-linux-YYYYMMDD.tar.gz
#   uv-uniformity-jig-MANUAL-PLUS-AUTO-windows-YYYYMMDD.zip
#
# Both contain the same project. The Windows zip additionally has CRLF line
# endings on .bat and .ps1, because cmd.exe and PowerShell can choke on LF in a
# batch file in ways that look like the script is simply broken.
set -eu

HERE="$(cd "$(dirname "$0")" && pwd)"
NAME="Uv Uniformity Jig (manual+auto)"
LABEL="uv-uniformity-jig-MANUAL-PLUS-AUTO"
OUT="$(dirname "$HERE")"
STAMP="$(date +%Y%m%d)"

while [ $# -gt 0 ]; do
    case "$1" in
        --out) OUT="$2"; shift 2 ;;
        *) echo "unknown option: $1"; exit 2 ;;
    esac
done

# Left out on purpose:
#   scan/archive/  superseded workbooks and logs; history, not payload
#   *.pyc etc      build droppings
EXCLUDES="
--exclude=./scan/archive
--exclude=./__pycache__
--exclude=*/__pycache__
--exclude=*.pyc
--exclude=.~lock.*
--exclude=*.tar.gz
--exclude=*.zip
--exclude=./.git
--exclude=./.gitattributes
--exclude=./web/console_settings.json
"

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/$NAME"

# shellcheck disable=SC2086
tar -C "$HERE" $EXCLUDES -cf - . | tar -C "$STAGE/$NAME" -xf -
echo "staged $(find "$STAGE/$NAME" -type f | wc -l) files"

# ---- Linux -----------------------------------------------------------------
LIN="$OUT/$LABEL-linux-$STAMP.tar.gz"
tar -C "$STAGE" -czf "$LIN" "$NAME"
echo "wrote $LIN  ($(du -h "$LIN" | cut -f1))"

# ---- Windows ---------------------------------------------------------------
find "$STAGE/$NAME" \( -name '*.bat' -o -name '*.ps1' \) -print0 |
while IFS= read -r -d '' f; do
    # LF -> CRLF, without doubling a file that already has CRLF.
    sed -i 's/\r$//; s/$/\r/' "$f"
done

WIN="$OUT/$LABEL-windows-$STAMP.zip"
rm -f "$WIN"
if command -v zip >/dev/null 2>&1; then
    ( cd "$STAGE" && zip -qr "$WIN" "$NAME" )
else
    # Git Bash on Windows has tar but no zip; Python is always there.
    PYZ=""
    for c in python3 python py; do command -v "$c" >/dev/null 2>&1 && { PYZ="$c"; break; }; done
    [ -n "$PYZ" ] || { echo "need either zip or python to build the Windows package"; exit 1; }
    "$PYZ" - "$STAGE" "$NAME" "$WIN" <<'PYZIP'
import os, sys, zipfile
stage, name, out = sys.argv[1:4]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(os.path.join(stage, name)):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, stage))
PYZIP
fi
echo "wrote $WIN  ($(du -h "$WIN" | cut -f1))"

echo
echo "Linux target  : tar xzf $(basename "$LIN") && cd '$NAME' && bash setup.sh"
echo "Windows target: unzip, then double-click setup-windows.bat"
