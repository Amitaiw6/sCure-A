# Install on another computer (Linux)

> **Manual + automatic build.** On Linux, Auto mode works with the StarBright
> connected by **RS‑232** (`/dev/ttyUSB0` etc.; `pip install pyserial`). The
> USB route needs Ophir's Windows-only driver — see [WINDOWS.md](WINDOWS.md).
> Nothing below changes for Manual mode.

## Quick version

```sh
tar xzf uv-uniformity-jig-linux-*.tar.gz
cd "Uv Uniformity Jig"
bash setup.sh
./start-console.sh
```

`start-console.sh` opens the web console and prints a URL that also works from
**any other computer or phone on the network**. Full guide:
**[web/README.md](web/README.md)**.

Then read **[STARTUP.md](STARTUP.md)** for what to plug in, and **re-home X** —
step counters do not survive a move to another machine.

## What `setup.sh` does

| Step | Detail |
|---|---|
| Checks the platform | Linux + Python 3.8+ |
| Installs packages | `openpyxl` (only needed to export the workbook) |
| Installs the udev rule | `/etc/udev/rules.d/99-uvjig.rules`, then reloads udev |
| Verifies | board present, `/dev/uvjig-ebb` accessible, every Python file in `tools/`, `scan/` and `web/` compiles |

`--check` verifies and changes nothing. Needs `sudo` only for the package and
the udev rule.

## Dependencies

| Dependency | Needed for | Required? |
|---|---|---|
| Python 3.8+ | everything | **yes** |
| `openpyxl` | exporting the scan workbook | no — readings always stream to CSV |

**No `pyserial` on Linux.** `tools/serial_min.py` implements the 8N1 raw-mode
support the board needs directly on `termios`/`select`, which is what lets this
run on a bare Python install. **No AVR toolchain** either — the servo is driven
by the EiBotBoard's own firmware, so there is nothing to compile or flash.

## Device permissions

The board enumerates as `root:dialout`, and most desktop users are not in
`dialout`. Rather than a `usermod` that needs a full logout, the rule assigns it
to **`plugdev`**, which desktop users are normally already in.

It also sets `ID_MM_DEVICE_IGNORE`: ModemManager AT-probes every new CDC port
for 10–20 s on plug-in and eats the first bytes of a session.

If you are not in `plugdev`:

```sh
sudo usermod -aG plugdev "$USER"   # then log out and back in
```

## What does NOT transfer

- **Step counters and the origin.** The board resets to `0,0` on power-up.
  Re-home before trusting any coordinate:
  `DO_MOVE=1 python3 tools/home_x.py` (put Z on its bottom stop first — `CS`
  zeroes both axes together).

## What DOES transfer

Everything else: calibration (`limits.json`), tooling, docs, the scan plan and
any readings in `scan/scan_readings.csv`.

`limits.json` describes **this physical jig** — 150 mm of X at 800 steps/mm,
300 mm of Z at 130 steps/mm, and the servo's 500–2500 µs range. Moving to
another computer changes none of that. Rebuilding or rewiring the jig does:
re-measure, and note that **swapping a stepper's coil-pair wiring reverses its
direction** with no software compensation anywhere in these tools.

## The web console needs nothing extra

`web/server.py` is stdlib-only. It serves `web/index.html` over HTTP, so the
machine you *browse* from needs no Python, no driver and no setup — only the
machine with the jig plugged into it does.

```sh
./start-console.sh                    # port 8765, reachable from the network
./start-console.sh --host 127.0.0.1   # this machine only
./start-console.sh --token secret     # require ?k=secret
```

To try the interface with no jig attached:

```sh
python3 web/simulate_jig.py           # prints a virtual port path
UVJIG_EBB_PORT=/dev/pts/9 python3 web/server.py
```
