@echo off
REM UV Uniformity Jig -- Windows setup launcher.
REM Double-click this, or run it from cmd. It calls the PowerShell script with
REM the execution policy relaxed for this one invocation.
echo Running UV Uniformity Jig setup...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-windows.ps1" %*
echo.
pause
