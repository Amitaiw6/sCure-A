@echo off
REM Start the UV jig web console. Run this on the computer the jig is plugged in to.
REM Anything you pass on the command line goes straight through to web\server.py:
REM   start-console.bat --mode auto     start in Auto mode (StarBright meter, auto scan)
REM   start-console.bat --mode manual   start in Manual mode (type each reading)
REM   start-console.bat --sim           no hardware: simulated board and meter
REM The mode can also be switched in the page header; the last choice is remembered.
REM MANUAL + AUTOMATIC build -- see VERSION.md.
setlocal
cd /d "%~dp0"

if "%PORT%"=="" set PORT=8765

REM Find Python. The py launcher is tried first because a default python.org
REM install always provides it, while "python" on PATH is optional and on
REM Windows 10/11 an unconfigured "python" is a Store stub that does nothing.
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY ( python --version >nul 2>&1 && set "PY=python" )
if not defined PY ( python3 --version >nul 2>&1 && set "PY=python3" )

if not defined PY (
  echo Python was not found.
  echo Install Python 3.8 or newer from python.org and tick "Add Python to PATH",
  echo or run setup-windows.bat first.
  pause
  exit /b 1
)

%PY% -c "import serial" >nul 2>&1
if errorlevel 1 (
  echo Installing pyserial ^(needed to talk to the board on Windows^)...
  %PY% -m pip install --quiet pyserial
)

REM Refuse to start on top of a console that is already running. Otherwise the
REM new server fails to bind, this window shows an error nobody reads, and the
REM browser happily opens onto the OLD server -- so replaced files appear to
REM have had no effect. That failure mode is very hard to spot from the UI.
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1
if not errorlevel 1 (
  echo.
  echo ============================================================
  echo   A jig console is ALREADY RUNNING on port %PORT%.
  echo.
  echo   Close that window first. If you leave it running, this new
  echo   one cannot start and your browser will keep talking to the
  echo   old server -- which is why updated files look like they did
  echo   nothing.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

start "" "http://localhost:%PORT%/"
%PY% web\server.py --port %PORT% %*
pause
