# Startup checklist — what to plug in

## 1. What to plug in

### USB — one device (two in Auto mode)

| Device | Identify it by | USB ID | Becomes |
|---|---|---|---|
| **EiBotBoard** | small board labelled *SchmalzHaus EiBotBoard* | `04d8:fd92` | `/dev/uvjig-ebb` (Linux) or a COM port (Windows) |
| **Ophir StarBright** *(Auto mode only)* | the UV meter, switched **on** | RS‑232: the USB‑serial adapter's own ID (a COM port) · USB: `0bd3:0346` | RS‑232: a second COM port, auto-detected · USB: a WinUSB device the console opens directly |

That is the whole USB inventory. X, Z **and** the servo are all on this one
board — there is no Arduino any more.

**The USB port does not matter.** The udev rule matches on vendor/product ID,
and on Windows the tools search by USB ID too. Any free socket works.

### Power and signal wiring

| Connection | Detail |
|---|---|
| **Motor supply (V+)** | External DC into the board. **Required** — without it the board still enumerates and counts steps but nothing turns. Healthy reading is `QC` V+ ≈ **819 counts**. |
| **Stepper on axis 1** | = chamber **Y** (the hand-moved layers are chamber X) |
| **Stepper on axis 2** | = chamber **Z** |
| **Servo** | signal on **RB1** (the board's servo header), plus 5 V and a common ground |

A servo under load can draw more than a small logic regulator will supply. If it
browns out or resets the board, give it its own 5 V with a shared ground.

---

## 2. What survives an unplug, and what does not

### Survives
- **udev rule** — `/etc/udev/rules.d/99-uvjig.rules`. The name comes back.
- **Calibration** — `limits.json`, this repo, the workbook.
- **Nothing to reflash.** The servo is driven by the board's own firmware, so
  there is no sketch to lose.

### Lost
- **Step counters reset to `0,0`.**
- **Step mode resets to 1/16** — the power-up default, which is what we use, but
  never assume it: set it explicitly if unsure.
- **The servo output is idle** until something commands it. An RC servo reports
  no position, so the console shows the last angle *commanded*, not measured.

### If nothing was moved by hand
Leaving the rig with **X = 0 and Z = 0** means the frame is still correct after
replugging, because the counters come back as `0,0`. If anything was nudged,
re-home before trusting a coordinate.

---

## 3. Startup checks

```sh
cd '/path/to/Uv Uniformity Jig'

# a. device present?
lsusb | grep -i 04d8:fd92          # Windows: python tools\serial_min.py

# b. stable name created by udev?
ls -l /dev/uvjig-ebb

# c. board alive, and is motor power connected?
python3 tools/move_ebb.py --status
#    expect: firmware 2.8.1, QS 0,0, V+ ~819 -> "motor supply PRESENT"

# d. servo alive?
python3 tools/servo_ctl.py --sweep
```

If `/dev/uvjig-ebb` is missing but `lsusb` shows the device:

```sh
sudo udevadm control --reload
sudo udevadm trigger --subsystem-match=tty --subsystem-match=usb
```

---

## 4. Re-homing (only if anything moved mechanically)

The driven Y hard stop is the one reference that cannot drift.

```sh
DO_MOVE=1 python3 tools/home_x.py           # counter-based
DO_MOVE=1 python3 tools/home_x.py --blind   # ignore the counter, full travel
```

It skids audibly for ~2 s at the end — that contact **is** the datum.

Use `--blind` after any manual re-zero. Counter-based homing trusts the counter
for the *distance* to the stop, so if the counter was zeroed somewhere else it
reports "already there" and barely moves.

**`CS` zeroes both axes at once** (no per-axis clear), and homing ends with a
`CS`. So put **Z on its bottom origin first**, then home the Y axis, and both frames
come out right together.

---

## 5. Run the scan

```sh
./start-console.sh          # Windows: start-console.bat
```

Connect, press **Arm motion**, then type each reading and press Enter — the jig
drives itself to the next point. Full guide in [web/README.md](web/README.md).

Terminal alternative: `python3 scan/scan_live.py --x 1` (one X layer at a time).

---

## 6. The UV meter: by hand, or over USB

**Manual mode** — readings are typed in. Nothing else to plug in.

**Auto mode** (this build) — the StarBright is read by the console. Connect it
either by **RS‑232** (its serial lead into a COM port or USB‑serial adapter —
no Ophir driver, no admin) or by **USB** (needs Ophir's WinUSB driver, see
WINDOWS.md). Switch the meter **on** (a meter that is off still enumerates but
never answers), switch the console header to **Auto**, choose the *Connection*
and press *Connect meter*. The card shows the instrument, sensor head and
wavelength; check the wavelength matches the source before scanning. Then
either step point by point with *Capture*, or pick a section and start an
**auto scan** — the jig moves, waits for a settled reading, logs it and carries
on, pausing only for the hand-moved X layers and the one-time sensor re-aim of
the RIGHT / LEFT sections (DOWN is aimed by the 270° servo).

If *Connect meter* says the meter is not found: for RS‑232 press *Ports* to see
which serial ports exist besides the board's and check the lead; for USB,
Device Manager must show *StarBright* without a yellow `!` (install the bundled
driver from `docs/starbright/driver/` as Administrator, re-plug). Manual mode
does not need any of this.
