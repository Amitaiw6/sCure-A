# UV Uniformity Jig — MANUAL + AUTOMATIC build

> **Which version is this?** The **manual + automatic** one — see
> [VERSION.md](VERSION.md). The console has a **Manual / Auto** toggle in its
> header. *Manual* is the original workflow (you type each reading) and needs
> nothing extra. *Auto* reads the Ophir StarBright meter over USB and runs an
> **auto scan** of a whole section by itself. A computer without the meter or
> its driver simply stays in Manual mode; nothing errors.

Maps UV irradiance uniformity across a volume. Two stepper axes, one RC servo
that aims the sensor, and a UV meter — read by hand, or over USB in Auto mode.

> **Just want to run a scan?** Start the web console — **[web/README.md](web/README.md)**:
>
> ```
> ./start-console.sh          # Windows: start-console.bat
> ```
>
> It prints a URL that works from any computer, tablet or phone on the same
> network. Connection indicators, origin recalibration, a coverage tracker, and
> data entry that advances the jig the moment you press Enter. Only the computer
> the jig is plugged into needs Python or a driver.
>
> **New machine?** **[INSTALL.md](INSTALL.md)** (Linux) or **[WINDOWS.md](WINDOWS.md)**.
> **Just plugged the rig back in?** **[STARTUP.md](STARTUP.md)**.
> **No hardware to hand?** `start-console.bat --sim` runs the whole console,
> auto scan included, against a simulated board and meter.

## Hardware

**One board drives everything.**

| Role | Where | Notes |
|---|---|---|
| **Y** axis stepper | EiBotBoard **axis 1** | 150 mm travel, 800 steps/mm |
| **Z** axis stepper | EiBotBoard **axis 2** | 300 mm travel, 130 steps/mm |
| **X** layers | *no motor* | moved by hand: 0 / 85 / 170 mm |
| **Sensor servo** | EiBotBoard **RB1** (`RP4`) | **270°** RC servo, 500–2500 µs = 0–270°: 0 BACK · 90 UP · 180 FRONT · 270 DOWN |
| **UV meter** | Ophir **StarBright**, PD300RM-8W head | *Manual mode:* readings typed in. *Auto mode:* read by `tools/starbright.py` over **RS‑232** (any COM port / USB‑serial adapter — no Ophir driver, no admin) or over **USB** (`0bd3:0346`, needs Ophir's WinUSB driver, bundled in `docs/starbright/driver/`) |

The board is a SchmalzHaus **EiBotBoard**, USB ID `04d8:fd92`, CDC-ACM, firmware
2.8.1. On Linux the udev rule names it `/dev/uvjig-ebb`; on Windows it is found
by USB ID, whatever COM number it lands on.

### The servo is on the board, not an Arduino

Earlier revisions of this rig ran the servo from an Arduino Uno with custom AVR
firmware. It does not any more. The EiBotBoard has a general RC servo output and
generates the pulse train in hardware:

```
S2,<position>,<output_pin>,<rate>,<delay>
     position   pulse width in units of 1/12 µs   (1500 µs -> 18000)
     output_pin RPn number. RP4 = RB1 = the board's servo header.
```

That removed a board, a USB port, an AVR build toolchain, and the DTR-reset
dance that came with talking to an Uno. `tools/ebb.py` wraps it.

**Pulse range is 500–2500 µs, not the usual 1000–2000.** The servo is a
**270° unit** (fitted 2026-10-05, replacing the 180° MG90S), and it needs the
full 500–2500 µs span to give all 270°. That extra quarter turn is what puts
the DOWN face within the servo's reach, so DOWN is now scanned automatically
alongside BACK / UP / FRONT. Fit the horn so that 0° aims BACK; then 90° is
UP, 180° FRONT and 270° DOWN. Confirm all four on the bench after any remount
(`tools/servo_ctl.py --faces`). The range, travel and timing live in
`limits.json` under `servo`.

**Servo power.** An RC servo under load draws well past what a small logic
regulator will give. If it browns out, stutters, or resets the board, give it
its own 5 V supply with a common ground.

### Axis mapping and signs

**Corrected 2026-08-31.** The axes were previously mislabelled: what the jig
drives is the chamber's **Y**, and the layers moved by hand are the chamber's
**X**.

| | |
|---|---|
| `+Y` | drives **into** the Y origin hard stop |
| `−Y` | the usable driven travel (0 → −121600 steps, 150 mm) |
| `+Z` | **up** (0 → +39000 steps, 300 mm) |
| `X` | the hand-moved layer axis — 0 / 85 / 170 mm, no motor |
| Scales | Y **800** steps/mm, Z **130** steps/mm — ~6× apart, never mix |

The web console hides the signs and labels its buttons **toward origin / away**.

## Two things that will bite you

**Never send `EM`.** It looks like a harmless "enable motors" command and it
silently zeroes both step counters. Proved by experiment: `CS` → 0,0; `SM` →
50,0; `SM` → 100,0; `EM` → **0,0**. Absolute position is destroyed with no error.

**Say nothing while an axis is moving.** The board generates step pulses from a
timer interrupt on a PIC, and USB traffic mid-move competes with it. Polling
`QM` every 50 ms produced audible stutter and lost steps; a script that sends
the move and then shuts up runs smoothly. Everything here goes silent for the
duration of a move and verifies afterwards.

## The scan

Grid **X=3 · Y=3 · Z=10** → 90 points, six faces at each → **540 readings**.

* X: 0 / 85 / 170 mm — **moved by hand**, one full pass per layer
* Y: 0 / 75 / 150 mm — driven
* Z: 10 levels, 0 → 300 mm (33.33 mm spacing) — driven

**Phase-major order.** The sensor's orientation is the expensive thing to change,
so each is set once and carried through all three X layers:

| Phase | Rows | What you do |
|---|---|---|
| `AUTO` | 360 | nothing — the servo aims BACK / UP / FRONT / DOWN at every point |
| `MANUAL-RIGHT` | 90 | point the sensor right, **once**, then all three X layers |
| `MANUAL-LEFT` | 90 | point it left, once — see below |

Two hand repositions for the whole scan instead of nine. Until 2026-10-05 DOWN
was a third hand-aimed phase; the 270° servo now reaches it. The four servo
faces alternate order from one point to the next (BACK→DOWN, then DOWN→BACK),
so the horn does not move between neighbouring points and never steps more
than 90° at once. Follow the direction the console shows for each row.

### The LEFT pass is taken with the jig turned round

LEFT is reached by rotating the whole jig 180° from the RIGHT setup, so the
driven axis then runs **backwards** relative to the chamber. `scan_plan.py`
compensates: a LEFT row carries the **true chamber Y**, and its step target is
the mirrored carriage position. Nothing needs correcting afterwards.

The 30 Aug scan predates this and had to be fixed by hand — see
`analysis/correct_scan.py`.

The path is **serpentine**: Z alternates direction every Y column and each block
starts where the last ended.

`scan/scan_plan.py` is the single source of truth for the grid.

### Auto scan (Auto mode)

Switch the console header to **Auto**, connect the meter (*Connection*:
**RS‑232** needs no driver at all; **USB** needs Ophir's, see WINDOWS.md), pick
a section and press **Start auto scan**. The three sections are run
**separately**, one per start, so you choose which to do and when:

| Section | Sensor aimed by | What the operator does |
|---|---|---|
| **BACK / UP / FRONT / DOWN** | the servo, at every point | move the X layer by hand when asked (3×) |
| **RIGHT** | hand, once | aim it right when asked, then the X layers |
| **LEFT** | hand, once | turn the jig round 180°, aim it left, then the X layers — carriage positions are mirrored for you |

At every point the jig moves, aims the servo, waits the mechanical settle (the
servo's own travel time is added when the swing is long), then
watches the meter until the last *N* samples agree within a tolerance (5 within
2 % by default, after a 1 s dwell), logs the mean to `scan/scan_readings.csv`
exactly as a typed reading would be, and moves on. Points already measured are
skipped unless you tick *re‑measure*. If a reading refuses to settle the scan
**pauses and asks** — retry, skip or stop — rather than logging a guess.
**Pause** finishes the current point and waits; **Stop** and **Escape** (E‑stop)
end it; a paused scan can be continued after you jog, re-home or fix something.

The meter protocol and driver notes are in `docs/starbright/README.md`.

## Layout

```
tools/    serial_min.py  serial layer, one device, termios or pyserial (or "sim")
          ebb.py         EBB protocol: steppers AND servo
          ebb_sim.py     fake EiBotBoard for --sim dry runs
          starbright.py  Ophir StarBright meter over WinUSB (Auto mode), + a simulated meter
          move_ebb.py    jog the axes            (needs DO_MOVE=1)
          servo_ctl.py   aim the servo           (no gate needed)
          home_x.py      seat X against its stop (needs DO_MOVE=1)
          estop.py       abort motion now
scan/     scan_plan.py   the grid and measurement order -- import, never copy
          make_workbook.py, merge_readings.py, scan_live.py
web/      server.py, index.html, simulate_jig.py, README.md
limits.json              calibration and soft travel limits
```

## Safety

Motion is **not** interlocked in hardware. The steppers move only with
`DO_MOVE=1` (or **Arm** in the console), moves are bounded by the soft limits in
`limits.json`, and `tools/estop.py` — or **Escape** in the console — aborts an
axis immediately. The servo is ungated: it is a small positioner with nothing to
crash into.

The soft limits bound the step **counter**, not the machine. On an axis that can
slip the counter drifts from reality — it records steps *issued*, not steps
*taken*. Re-home to re-anchor it.
