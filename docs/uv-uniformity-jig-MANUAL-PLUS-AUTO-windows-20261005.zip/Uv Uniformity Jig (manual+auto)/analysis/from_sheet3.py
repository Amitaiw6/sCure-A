#!/usr/bin/env python3
"""Turn Sheet3 of 'UV scan Updated.xlsx' into a full-grid CSV for the simulation.

WHAT THE SOURCE ACTUALLY CONTAINS
    Four height blocks, each holding six direction tables on a 3 x 2 grid:
        3 positions across   (+/-140 mm from centre, per the sheet's note)
        2 positions front/back (+/-80 mm from centre)
    = 4 heights x 6 faces x 6 positions = 144 readings.

    The blocks are NOT labelled with their heights. The mapping below was
    inferred from the readings themselves and cross-checked against the sheet's
    own centre-point summaries:

        block 1  UP 83.5 / DOWN 17.6  -> looking up sees the lamps  ->  35 mm
        block 2  UP 74.3 / DOWN 57.4  -> balanced                   -> 178 mm
        block 3  UP 30.8 / DOWN 73.0  -> inverted, near the ceiling -> 355 mm
        block 4  UP 65.4 / DOWN 65.2  -> balanced, "New shelf"      -> 201 mm

    Each block's six-direction signature matched its centre summary by a wide
    margin (see --explain).

WHAT THIS SCRIPT PRODUCES IS MOSTLY INTERPOLATION, NOT MEASUREMENT.
    144 real readings become 540 grid points. Everything between the four
    measured heights is linear interpolation; the middle Y plane is the mean of
    the two measured planes; and Z below 35 mm is extrapolated.
    Treat the output as a visualisation of the measured field, not as data.

    python3 analysis/from_sheet3.py [--explain] [-o OUT.csv]
"""

import argparse
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "scan"))
import scan_plan                                                    # noqa: E402

SRC = os.path.join(ROOT, os.pardir,
                   "uvjig-OLD-arduino-20260826-173335", "Uv Uniformity Jig",
                   "scan", "UV scan Updated.xlsx")

# block -> (first table row, second table row)
BLOCKS = {1: (1, 7), 2: (13, 19), 3: (25, 31), 4: (38, 44)}
# (label column, value columns) for the three tables side by side
TABCOL = [(1, [2, 3, 4]), (6, [7, 8, 9]), (11, [12, 13, 14])]
BLOCK_HEIGHT_MM = {1: 35.0, 2: 178.0, 3: 355.0, 4: 201.0}
HALF_ACROSS = 140.0      # sheet: "140 mm from center to each side"
HALF_DEPTH = 80.0        # sheet: "80mm from center to front/back"

# Source cells discarded before anything else happens, with the reason.
# Keyed (block, direction, grid_row, grid_col). A discarded cell is re-estimated
# from the other five cells of its own table -- see fill_rejected().
REJECT = {
    (1, "BACK", 1, 2): "5.4 among neighbours of 64-91; reads as a typo, and it "
                       "was the minimum of the entire BACK face",
}


def num(v):
    """A cell may hold '116.9/119' -- the same point read twice. Average them."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if "/" in s:
        parts = [p for p in s.split("/") if p.strip()]
        try:
            return sum(float(p) for p in parts) / len(parts)
        except ValueError:
            return None
    try:
        return float(s)
    except ValueError:
        return None


def read_sheet(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True)["Sheet3"]
    out = {}
    for bi, rows in BLOCKS.items():
        for r0 in rows:
            for lab_c, val_cs in TABCOL:
                d = ws.cell(r0, lab_c).value
                if not d:
                    continue
                d = str(d).strip().upper()
                if d not in scan_plan.DIRECTIONS:
                    continue
                for i in range(3):                 # across: 3 positions
                    for j in range(2):             # depth: 2 positions
                        v = num(ws.cell(r0 + 2 + i, val_cs[j]).value)
                        if v is not None:
                            out[(bi, d, i + 1, j + 1)] = v
    return out


def fill_rejected(data, verbose=False):
    """Re-estimate discarded cells from their own 3 x 2 table.

    Uses the standard missing-value estimator for a two-way layout:

        x = (r*R + c*C - T) / ((r-1)(c-1))

    with R the sum of the observed cells in that row, C the same for the column
    and T the observed total. It is the value that leaves the row and column
    effects consistent with the rest of the table, which is what you want for a
    single hole in a small grid.

    Deliberately NOT taken from the same position at other heights: this cell
    sits at the LOWEST measured height, so that would mean extrapolating
    downward -- the direction with no data under it and the one that already
    produced a negative reading once.
    """
    for (bi, d, gr, gc), why in REJECT.items():
        old = data.pop((bi, d, gr, gc), None)
        rows = sorted({k[2] for k in data if k[0] == bi and k[1] == d} | {gr})
        cols = sorted({k[3] for k in data if k[0] == bi and k[1] == d} | {gc})
        r, c = len(rows), len(cols)
        obs = {(k[2], k[3]): v for k, v in data.items() if k[0] == bi and k[1] == d}
        R = sum(v for (i, j), v in obs.items() if i == gr)
        C = sum(v for (i, j), v in obs.items() if j == gc)
        T = sum(obs.values())
        if r > 1 and c > 1:
            est = (r * R + c * C - T) / float((r - 1) * (c - 1))
        else:
            est = T / len(obs) if obs else 0.0
        est = max(0.0, round(est, 2))
        data[(bi, d, gr, gc)] = est
        if verbose:
            print("  discarded block %d %s row %d col %d = %s" % (bi, d, gr, gc, old))
            print("    reason   : %s" % why)
            print("    neighbours: row %s | column %s"
                  % ([v for (i, j), v in sorted(obs.items()) if i == gr],
                     [v for (i, j), v in sorted(obs.items()) if j == gc]))
            print("    estimated : %s" % est)
    return data


def interp_z(pairs, z):
    """Piecewise-linear in height, HELD FLAT outside the measured range.

    An earlier version continued the local gradient below the lowest measured
    height. That produced negative irradiance -- the 5.4 reading in block 1 BACK
    sits under a steep rise, so extending its slope down to z=0 gave -19. There
    is no data below 35 mm, so inventing a trend there is worse than holding the
    nearest measured value, and irradiance cannot go negative in any case.
    """
    pairs = sorted(pairs)
    if len(pairs) == 1:
        return pairs[0][1]
    if z <= pairs[0][0]:
        return pairs[0][1]
    if z >= pairs[-1][0]:
        return pairs[-1][1]
    for (z0, v0), (z1, v1) in zip(pairs, pairs[1:]):
        if z0 <= z <= z1:
            return v0 + (v1 - v0) * (z - z0) / (z1 - z0)
    return pairs[-1][1]


def build(data):
    """Fill the simulation's 3 x 3 x 10 grid from the 3 x 2 x 4 measurements."""
    zs = scan_plan.z_positions()
    rows, stats = [], {"measured_z": 0, "interp_z": 0, "extrap_z": 0, "interp_y": 0}
    lo_h = min(BLOCK_HEIGHT_MM.values())
    heights = {v: k for k, v in BLOCK_HEIGHT_MM.items()}
    for r in scan_plan.plan():
        if r["y"] == 2:
            src_cols = (1, 2)          # middle plane: mean of the two measured
            stats["interp_y"] += 1
        else:
            src_cols = (1,) if r["y"] == 1 else (2,)
        pairs = []
        for h in sorted(heights):
            vals = [data.get((heights[h], r["dir"], r["x"], c)) for c in src_cols]
            vals = [v for v in vals if v is not None]
            if vals:
                pairs.append((h, sum(vals) / len(vals)))
        if not pairs:
            continue
        z = zs[r["z"] - 1]
        if any(abs(z - h) < 1e-6 for h, _ in pairs):
            stats["measured_z"] += 1
        elif z < lo_h:
            stats["extrap_z"] += 1
        else:
            stats["interp_z"] += 1
        rows.append((r, round(max(0.0, interp_z(pairs, z)), 2)))
    return rows, stats


def main():
    ap = argparse.ArgumentParser(description="Sheet3 -> full-grid CSV.")
    ap.add_argument("-o", "--out", default=os.path.join(HERE, "uv_from_sheet3.csv"))
    ap.add_argument("--src", default=SRC)
    ap.add_argument("--explain", action="store_true")
    args = ap.parse_args()

    data = read_sheet(args.src)
    print("read %d readings from Sheet3" % len(data))
    if REJECT:
        print("\ndiscarding %d source cell(s) and re-estimating:" % len(REJECT))
        fill_rejected(data, verbose=True)

    if args.explain:
        print("\nblock signatures (mean per direction):")
        for bi in sorted(BLOCKS):
            m = {d: [v for k, v in data.items() if k[0] == bi and k[1] == d]
                 for d in scan_plan.DIRECTIONS}
            print("  block %d -> %4.0f mm : %s" % (bi, BLOCK_HEIGHT_MM[bi],
                  "  ".join("%s %5.1f" % (d, sum(m[d]) / len(m[d]))
                            for d in ("UP", "DOWN", "FRONT", "BACK", "LEFT", "RIGHT"))))
        vals = sorted(data.values())
        print("\nvalue range %.1f .. %.1f" % (vals[0], vals[-1]))
        odd = [(k, v) for k, v in data.items()
               if v < 20 and k[1] != "DOWN" and k not in REJECT]
        if odd:
            print("suspicious low readings (not DOWN, which is legitimately low "
                  "near the floor):")
            for k, v in odd:
                print("   block %d %-6s row %d col %d = %s" % (k[0], k[1], k[2], k[3], v))

    rows, stats = build(data)
    with open(args.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["utc", "row", "id", "phase", "y", "x_idx", "z_idx", "x_mm",
                    "z_mm", "x_steps", "z_steps", "direction", "servo_deg", "reading"])
        for r, v in rows:
            w.writerow(["INTERPOLATED", r["row"], r["id"], r["phase"], r["y"],
                        r["x"], r["z"], r["xmm"], round(r["zmm"], 2), r["xsteps"],
                        r["zsteps"], r["dir"],
                        "" if r["angle"] is None else r["angle"], v])
    print("\nwrote %s  (%d rows)" % (args.out, len(rows)))
    print("  %d land on a measured height, %d interpolated between heights, "
          "%d held flat below the lowest (35 mm)"
          % (stats["measured_z"], stats["interp_z"], stats["extrap_z"]))
    print("  %d of them also use the interpolated middle Y plane" % stats["interp_y"])
    print("\n144 real readings -> %d grid points. This is a rendering of the "
          "measured field, not measurement." % len(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
