#!/usr/bin/env python3
"""Correct the 30 Aug scan into the chamber's real coordinate frame.

TWO CORRECTIONS, in this order.

1. THE LEFT PHASE WAS MEASURED WITH THE JIG ROTATED 180 DEGREES.
   The operator turned the whole jig around after finishing RIGHT, so the
   driven horizontal axis runs backwards for those rows only. The timestamps
   confirm the sequence -- LEFT ran 17:57-18:24, straight after RIGHT finished
   at 17:52 -- and no other phase was measured after the rotation.

   Only that axis flips. The hand-set layers and the Z heights were placed at
   their correct absolute positions regardless of which way the jig faced.

   The readings corroborate it. Along the driven axis the two side faces have
   OPPOSITE gradients as recorded (LEFT 67.3 -> 62.3 -> 49.5 falling, RIGHT
   70.4 -> 70.2 -> 72.2 rising); after the flip both rise together, and the
   LEFT/RIGHT correlation improves from r=+0.13 to +0.35.

2. THE AXIS LABELS ARE SWAPPED.
   What the scan recorded as the hand-moved "y" layers is really the chamber's
   X direction, and the axis the jig drives is really Y.

       physical X  <-  recorded y        (hand-set layers)
       physical Y  <-  recorded x_idx    (driven axis, after correction 1)
       physical Z  <-  recorded z_idx    (unchanged)

   Operator's anchor: id 251, reading 68.6, recorded y=2 x_idx=3, is in truth
   the middle of X and the rear of Y. That is exactly what this mapping gives,
   and it fixes Y index 3 = rear.

X SPACING: 85 mm, given by the operator 2026-08-31, so the hand-set layers sit
at 0 / 85 / 170 mm. Earlier revisions of this script left x_mm blank because the
spacing had never been measured.

3. A CONSTANT OFFSET IS ADDED TO EVERY READING.
   READING_OFFSET below compensates a known under-read in the meter. It is a
   flat addition, applied to all 540 values alike.

   Be aware of what that does to the headline numbers: adding a constant lifts
   the minimum and the maximum by the same amount, so the absolute spread
   (max - min) is unchanged while min/max uniformity goes UP and the +/- 
   variation goes DOWN. The field is no flatter than it was; the ratio just
   looks better because everything sits further from zero. The raw spread is
   the honest figure to quote alongside it.

    python3 analysis/correct_scan.py [-i IN.csv] [-o OUT.csv]
"""

import argparse
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEFAULT_IN = os.path.join(ROOT, "scan", "Scan Results 30_8.csv")
DEFAULT_OUT = os.path.join(ROOT, "scan", "Scan Results 30_8 CORRECTED.csv")

ROTATED_PHASES = {"MANUAL-LEFT"}     # the only phase measured after the 180 turn
X_LAYER_MM = [0.0, 85.0, 170.0]      # hand-set layers, 85 mm apart
READING_OFFSET = 5.0                 # meter under-read, operator 2026-08-31
FLIP = {1: 3, 2: 2, 3: 1}
MM_FLIP = {0.0: 150.0, 75.0: 75.0, 150.0: 0.0}

OUT_COLS = ["utc", "row", "id", "phase", "x_idx", "y_idx", "z_idx",
            "x_mm", "y_mm", "z_mm", "direction", "servo_deg", "reading",
            "reading_raw", "reading_offset",
            "orig_y", "orig_x_idx", "left_rotation_applied"]


def main():
    ap = argparse.ArgumentParser(description="Correct the 30 Aug scan.")
    ap.add_argument("-i", "--infile", default=DEFAULT_IN)
    ap.add_argument("-o", "--out", default=DEFAULT_OUT)
    ap.add_argument("--offset", type=float, default=READING_OFFSET,
                    help="constant added to every reading (default %(default)s)")
    args = ap.parse_args()

    with open(args.infile, newline="") as fh:
        raw = list(csv.DictReader(fh))
    print("read %d rows from %s" % (len(raw), os.path.basename(args.infile)))

    # One point was measured twice. The later entry supersedes the earlier,
    # which is the same rule merge_readings.py uses.
    byrow, dupes = {}, 0
    for r in raw:
        k = int(r["row"])
        if k in byrow:
            dupes += 1
        byrow[k] = r
    rows = [byrow[k] for k in sorted(byrow)]
    if dupes:
        print("  %d duplicate row(s) collapsed, keeping the later reading" % dupes)

    out, flipped = [], 0
    for r in rows:
        oy, ox = int(r["y"]), int(r["x_idx"])
        rotated = r["phase"] in ROTATED_PHASES
        drive_i = FLIP[ox] if rotated else ox
        drive_mm = MM_FLIP[float(r["x_mm"])] if rotated else float(r["x_mm"])
        if rotated:
            flipped += 1
        out.append({
            "utc": r["utc"], "row": r["row"], "id": r["id"], "phase": r["phase"],
            "x_idx": oy,                 # hand-set layers ARE the X direction
            "y_idx": drive_i,            # the driven axis IS the Y direction
            "z_idx": r["z_idx"],
            "x_mm": ("%g" % X_LAYER_MM[oy - 1]),
            "y_mm": ("%g" % drive_mm),
            "z_mm": r["z_mm"],
            "direction": r["direction"], "servo_deg": r["servo_deg"],
            "reading": ("%g" % (float(r["reading"]) + args.offset)),
            "reading_raw": r["reading"],
            "reading_offset": ("%g" % args.offset),
            "orig_y": oy, "orig_x_idx": ox,
            "left_rotation_applied": "yes" if rotated else "no",
        })
    print("  %d LEFT rows had the driven axis inverted" % flipped)

    with open(args.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=OUT_COLS)
        w.writeheader()
        w.writerows(out)
    if args.offset:
        vals = [float(o["reading_raw"]) for o in out]
        lo, hi = min(vals), max(vals)
        print("  +%g added to every reading (meter under-read)" % args.offset)
        print("     raw   %.1f - %.1f   uniformity %.1f%%   variation +/-%.1f%%"
              % (lo, hi, lo / hi * 100, (hi - lo) / (hi + lo) * 100))
        lo2, hi2 = lo + args.offset, hi + args.offset
        print("     +%-4g %.1f - %.1f   uniformity %.1f%%   variation +/-%.1f%%"
              % (args.offset, lo2, hi2, lo2 / hi2 * 100,
                 (hi2 - lo2) / (hi2 + lo2) * 100))
        print("     the spread is unchanged at %.1f -- only its ratio to zero moved"
              % (hi - lo))

    print("\nwrote %s  (%d rows)" % (args.out, len(out)))

    anchor = [o for o in out if o["id"] == "251"]
    if anchor:
        a = anchor[0]
        print("\nanchor check -- id 251, reading %s:" % a["reading"])
        print("  physical X index %s of 3 at %s mm   (2 = middle)"
              % (a["x_idx"], a["x_mm"]))
        print("  physical Y index %s of 3   (3 = rear)" % a["y_idx"])
        print("  operator said: middle X, rear Y  ->  %s"
              % ("MATCH" if (a["x_idx"], a["y_idx"]) == (2, 3) else "MISMATCH"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
