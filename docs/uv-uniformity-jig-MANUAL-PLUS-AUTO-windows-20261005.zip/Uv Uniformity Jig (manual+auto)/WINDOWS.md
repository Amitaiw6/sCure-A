# Running on Windows

The code is cross-platform. Two things differ from Linux, and both are handled
for you. (A third — the StarBright meter driver — only matters for **Auto
mode**; see the end of this page.)

| | Linux | Windows |
|---|---|---|
| Serial backend | `termios` (stdlib, no install) | **`pyserial`** (`pip install pyserial`) |
| Stable device name | udev rule → `/dev/uvjig-ebb` | **no udev** — found by USB vendor/product ID |
| Port name | `/dev/uvjig-ebb` | `COM3`, `COM7`, … |
| Driver | `cdc_acm`, built in | `usbser.sys`, built into Windows 10/11 |

`tools/serial_min.py` picks the backend automatically and `resolve_port()` finds
the board by its **USB ID**, not by COM number — COM numbers are no more stable
than `ttyACM` numbers were, so matching on identity is the same trick the udev
rule plays.

There is only **one** device to find: X, Z and the servo are all on the
EiBotBoard.

## Setup

Double-click **`setup-windows.bat`**, or from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File setup-windows.ps1
```

It checks for Python 3.8+, installs `pyserial` and `openpyxl`, finds the board
by USB ID, and compiles every tool. **No admin rights needed** — there is no
driver and no rule to install. Add `-Check` to verify without changing anything.

If Device Manager shows a yellow bang on the board, let Windows Update search
for `usbser`; it is a stock in-box driver.

## Running

**Easiest: double-click `start-console.bat`.** It installs `pyserial` if it is
missing, refuses to start if a console is already running on that port, opens
the web console in your browser, and prints a URL that works from any other
computer or phone on the network. Full guide: **[web/README.md](web/README.md)**.

The command-line tools work too:

```powershell
python tools\move_ebb.py --status
python tools\servo_ctl.py --faces
python tools\servo_ctl.py 270

set DO_MOVE=1
python tools\home_x.py
python tools\move_ebb.py --x-rev -5

python web\server.py            # the console
python scan\scan_live.py --y 1  # or the terminal runner
python tools\estop.py
```

Note `set DO_MOVE=1` rather than the `DO_MOVE=1 python ...` prefix — cmd and
PowerShell do not accept a per-command environment prefix. In PowerShell it is
`$env:DO_MOVE = "1"`.

## If the board lands on an unexpected port

Auto-detection uses the USB ID and is normally right. To force it:

```powershell
set UVJIG_EBB_PORT=COM5
```

To see what the machine can find:

```powershell
python tools\serial_min.py
```

That prints the chosen backend, the resolved port, and every candidate serial
port with its USB ID.

## What is Linux-only

`install-udev.sh` and `udev/` — there is no udev on Windows. Everything needed
to **operate** the jig works.

## Everything else is identical

Calibration (`limits.json`), travel limits, sign conventions, the workbook and
the scan procedure are all platform-independent. Read **STARTUP.md** for what to
plug in, and remember the board needs its **external motor supply** — without it
the board enumerates and counts steps perfectly while nothing turns.

## Auto mode: the StarBright meter (optional)

This is the **manual + automatic** build. Auto mode reads the Ophir StarBright
and can scan a whole section on its own. The meter can be reached **two ways**;
pick one in the Auto scan card (*Connection*):

| Connection | Needs | Driver / admin |
|---|---|---|
| **RS‑232** (recommended on a locked-down PC) | the meter's RS‑232 cable into any COM port or a **USB‑serial adapter** | **none from Ophir.** A USB‑serial adapter uses Windows' own in-box driver (FTDI, CP210x, CH340 and Prolific are all stock on Windows 10/11). No downloads, no admin. |
| **USB** | the meter's USB cable | Ophir's **WinUSB** driver (`ophdev.inf`), installed **once, as Administrator**. The two files are bundled in `docs/starbright/driver/` — no download needed: right-click `ophdev.inf` → *Install*, then re-plug. (Or install Ophir's StarLab, which carries the same driver.) |

*Auto* (the default) tries USB if the driver is there, then RS‑232. Leave the
port blank and the console finds the adapter itself — it probes every serial
port **except the EiBotBoard's** with a harmless `$VE` at each common baud rate
until the meter answers. The **Ports** button lists what it can see. Both routes
speak the same protocol and give identical readings.

| | |
|---|---|
| Python packages | `pyserial` (already required on Windows for the board) — nothing else |
| Admin rights | only for the USB driver; **none** for RS‑232 |

`setup-windows.bat` reports whether the meter and its driver are present but
**never fails setup over them**: Manual mode needs neither, and the console
starts in Manual. Switch to Auto in the header when the meter is there.

Nothing in Manual mode imports or probes the meter, so a computer without it
runs this build exactly like the manual-only package — no error messages.

**If StarLab is installed**, USB just works: *Connection* = *Auto* or *USB*,
*Connect meter*. Any StarLab version will do — the console reads the driver's
details from the registry. If it does not connect, run
`python tools\starbright.py --doctor` and send the output.

Ophir's own StarLab application will not see this meter while the console holds
it over USB (and vice-versa); **close StarLab** before connecting in the console. If RS‑232 gets
no answer at any rate, check the meter is **on** and its serial settings in its
own setup menu. Driver and protocol notes: `docs/starbright/README.md`.

Dry run without any hardware: `start-console.bat --sim`.
