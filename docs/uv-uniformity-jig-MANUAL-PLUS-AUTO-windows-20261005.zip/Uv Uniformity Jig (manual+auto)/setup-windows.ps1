# UV Uniformity Jig -- Windows setup.
#
#   powershell -ExecutionPolicy Bypass -File setup-windows.ps1
#   ...or just double-click setup-windows.bat
#
#   -Check   verify only, change nothing
#
# No admin rights needed for the jig itself: there is no driver and no rule to
# install. Both the steppers and the servo are on one EiBotBoard, which Windows
# 10/11 binds to its built-in usbser driver automatically.
#
# MANUAL + AUTOMATIC build. Auto mode reads an Ophir StarBright UV meter over
# USB, which needs Ophir's WinUSB driver (installed once, as Administrator, by
# Ophir's StarLab package). That is OPTIONAL: Manual mode works without it, and
# this script only reports what it finds -- it never fails setup over the meter.

param([switch]$Check)

$ok = 0; $note = 0; $fail = 0
function Good($m) { Write-Host "  [ ok ] $m"; $script:ok++ }
function Note($m) { Write-Host "  [note] $m" -ForegroundColor Yellow; $script:note++ }
function Bad($m)  { Write-Host "  [FAIL] $m" -ForegroundColor Red; $script:fail++ }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "======================================================================"
Write-Host "  UV Uniformity Jig -- Windows setup"
Write-Host "======================================================================"

# ---------------------------------------------------------------- python ---
Write-Host "`nPython"
$py = $null
foreach ($c in @("py -3", "python", "python3")) {
    $exe, $arg = $c.Split(" ", 2)
    if (Get-Command $exe -CommandType Application -ErrorAction SilentlyContinue) {
        try {
            $v = & $exe $arg --version 2>&1
            if ($v -match "Python 3\.(\d+)") {
                if ([int]$Matches[1] -ge 8) { $py = $c; Good "$v  (via '$c')"; break }
                else { Note "$v is too old -- need 3.8+" }
            }
        } catch {}
    }
}
if (-not $py) {
    Bad "No Python 3.8+ found. Install from https://python.org and tick 'Add to PATH'."
    Write-Host "`n  $ok ok, $note notes, $fail failures"
    exit 1
}
$pyExe, $pyArg = $py.Split(" ", 2)

# Resolve to the real executable up front. -CommandType Application matters:
# without it Get-Command would happily hand back a *function* of the same name.
$pyPath = (Get-Command $pyExe -CommandType Application -ErrorAction SilentlyContinue |
           Select-Object -First 1).Source
if (-not $pyPath) { $pyPath = $pyExe }

# Deliberately NOT named "Py". PowerShell command lookup is case-insensitive and
# prefers functions over executables, so when Python is found via the launcher
# ("py -3", the usual case on Windows) a function called Py makes "& py" invoke
# itself -- infinite recursion, reported as:
#     The script failed due to call depth overflow.
function Invoke-Py { param([Parameter(ValueFromRemainingArguments)]$a)
    if ($pyArg) { & $pyPath $pyArg @a } else { & $pyPath @a } }

# -------------------------------------------------------------- packages ---
Write-Host "`nPython packages"
$need = @()
foreach ($m in @(@("serial","pyserial","serial ports - REQUIRED on Windows"),
                 @("openpyxl","openpyxl","the scan workbook - optional"))) {
    # Reset first: never trust a stale exit code across a call that may not run.
    $global:LASTEXITCODE = 1
    Invoke-Py -c "import $($m[0])" 2>$null
    if ($LASTEXITCODE -eq 0) { Good "$($m[1])  ($($m[2]))" } else { $need += $m[1] }
}
if ($need.Count -gt 0) {
    if ($Check) { Note "would install: $($need -join ', ')" }
    else {
        Write-Host "  installing: $($need -join ', ')"
        Invoke-Py -m pip install --upgrade pip 2>&1 | Out-Null
        Invoke-Py -m pip install @need
        if ($LASTEXITCODE -eq 0) { Good "packages installed" } else { Bad "pip install failed" }
    }
}

# --------------------------------------------------------------- devices ---
Write-Host "`nDevices"
Write-Host "  (Windows assigns COM numbers; the tools match on USB ID, not COM number)"
Write-Host "  One EiBotBoard drives everything -- X, Z and the servo on RB1."
Write-Host "  There is no Arduino any more, so there is only one device to find."
$global:LASTEXITCODE = 1
Invoke-Py -c @"
import sys, os
sys.path.insert(0, os.path.join(r'$here', 'tools'))
from serial_min import find_by_usb_id, EBB_VID, EBB_PID, describe_ports
p = find_by_usb_id(EBB_VID, EBB_PID)
print('  EiBotBoard: ' + (p if p else 'NOT FOUND'))
print('  candidate ports:')
for line in describe_ports() or ['    (none)']:
    print('    ' + line)
sys.exit(0 if p else 1)
"@
if ($LASTEXITCODE -eq 0) { Good "EiBotBoard found" } else { Note "EiBotBoard not detected (unplugged?)" }

# ---------------------------------------------------------- UV meter -------
# Auto mode only. Reported, never required: Manual mode needs none of this.
Write-Host "`nUV meter (Auto mode only -- optional)"
$oph = $null
try {
    $oph = Get-PnpDevice -PresentOnly -ErrorAction Stop |
           Where-Object { $_.InstanceId -like 'USB\VID_0BD3*' } | Select-Object -First 1
} catch {}
if (-not $oph) {
    Note "no Ophir meter on USB right now. Manual mode needs none. For Auto mode connect the StarBright by RS-232 (no driver) or USB."
} elseif ($oph.Status -eq 'OK') {
    Good "Ophir meter '$($oph.FriendlyName)' on USB with its driver  ($($oph.InstanceId))"
    $sl = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'StarLab' }
    if ($sl) { Note "StarLab is running -- close it before connecting the meter in the console; it holds the meter while open." }
} else {
    Note "Ophir meter '$($oph.FriendlyName)' is on USB but has NO driver (status: $($oph.Status))."
    Note "Either use its RS-232 port (no driver needed), or install docs\starbright\driver\ophdev.inf once as Administrator."
}
$extra = @()
try {
    $extra = [System.IO.Ports.SerialPort]::GetPortNames() | Where-Object { $_ }
} catch {}
if ($extra.Count -gt 0) { Note ("serial ports present: " + ($extra -join ', ') + "  (one is the EiBotBoard; a USB-serial adapter for the meter's RS-232 shows here too)") }

# --------------------------------------------------------------- project ---
Write-Host "`nProject files"
foreach ($f in @("tools\serial_min.py","tools\ebb.py","tools\move_ebb.py",
                 "tools\servo_ctl.py","tools\starbright.py","tools\ebb_sim.py",
                 "scan\scan_plan.py","web\server.py",
                 "web\index.html","limits.json","VERSION.md")) {
    if (Test-Path (Join-Path $here $f)) { Good $f } else { Bad "missing $f" }
}
Push-Location $here
$global:LASTEXITCODE = 1
Invoke-Py -c "import py_compile,glob,sys;bad=0
for f in glob.glob('tools/*.py')+glob.glob('scan/*.py')+glob.glob('web/*.py'):
    try: py_compile.compile(f, doraise=True)
    except Exception as e: print('   ',f,e); bad=1
sys.exit(bad)"
if ($LASTEXITCODE -eq 0) { Good "all python tools compile" } else { Bad "some tools fail to compile" }
Pop-Location

# --------------------------------------------------------------- summary ---
Write-Host "`n======================================================================"
Write-Host "  $ok ok, $note notes, $fail failures"
Write-Host "======================================================================"
if ($fail -gt 0) { Write-Host "Fix the failures above before running the jig."; exit 1 }

Write-Host @"

Next steps:
  1. EASIEST: double-click start-console.bat.
     It opens the web console in your browser -- connection indicators, origin
     recalibration, a coverage tracker, and Enter-to-advance data entry. It also
     prints a URL that works from any other computer or phone on the same
     network. See web\README.md.

     The console starts in MANUAL mode (type each reading). Switch to AUTO in
     the page header to read the StarBright meter over USB and run an auto
     scan of a whole section (BACK/UP/FRONT/DOWN, RIGHT or LEFT). Auto mode
     needs the meter -- by RS-232 (no driver at all) or by USB (Ophir's driver,
     bundled in docs\starbright\driver). Manual mode never touches either.

     Dry run with no hardware at all:  start-console.bat --sim

  2. Read STARTUP.md -- what to plug in. The board needs an EXTERNAL motor
     supply or nothing will turn, however healthy the USB link looks.

  3. Verify:   python tools\move_ebb.py --status
               python tools\servo_ctl.py --sweep

  4. Re-home:  set DO_MOVE=1
               python tools\home_x.py
     Step counters reset to 0 whenever the board is unplugged, so the origin
     must be re-established on a new machine.

If the board lands on an unexpected port, override it:
     set UVJIG_EBB_PORT=COM5

Motion is not interlocked. The steppers move only with DO_MOVE=1 (or Arm in the
console), and tools\estop.py stops an axis immediately.
"@
