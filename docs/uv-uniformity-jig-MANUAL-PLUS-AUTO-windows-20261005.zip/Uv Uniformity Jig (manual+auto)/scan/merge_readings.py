#!/usr/bin/env python3
"""Fold scan_readings.csv into the workbook.

The runners write every reading to the CSV the instant it is entered and never
touch the workbook -- so a crash, an interruption, or the file being open in
Excel can never cost you data. This merges the CSV in when you want the
spreadsheet up to date.

    python3 scan/merge_readings.py            # merge into uv_scan.xlsx
    python3 scan/merge_readings.py --dry-run  # show what would change

The workbook must be CLOSED in Excel/LibreOffice: this writes to it.
"""

import argparse
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORKBOOK = os.path.join(HERE, "uv_scan.xlsx")
CSVFILE = os.path.join(HERE, "scan_readings.csv")

sys.path.insert(0, HERE)
from scan_plan import READING_COL                    # noqa: E402  (column M)
TAKEN_COL = READING_COL + 2                          # column O, "Taken at"

try:
    from openpyxl import load_workbook
except ImportError:
    print("openpyxl missing. Fix: python -m pip install openpyxl")
    sys.exit(2)


def _coerce(v):
    """Numbers land as numbers so the sheet can chart them."""
    s = str(v).strip()
    for cast in (int, float):
        try:
            return cast(s)
        except ValueError:
            pass
    return s


def main():
    ap = argparse.ArgumentParser(description="Merge readings into the workbook.")
    ap.add_argument("--workbook", default=WORKBOOK)
    ap.add_argument("--csv", default=CSVFILE)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--overwrite", action="store_true",
                    help="replace values already present in the sheet")
    args = ap.parse_args()

    if not os.path.exists(args.csv):
        print("no readings CSV at %s -- nothing to merge" % args.csv)
        return 1
    if not os.path.exists(args.workbook):
        print("no workbook at %s -- run scan/make_workbook.py first" % args.workbook)
        return 2

    lock = os.path.join(os.path.dirname(args.workbook),
                        ".~lock.%s#" % os.path.basename(args.workbook))
    if os.path.exists(lock) and not args.dry_run:
        print("REFUSED: %s appears to be open (lock file present)." % args.workbook)
        print("         Close it first, or the merge would be overwritten when")
        print("         the application saves.")
        return 1

    # Last entry for a row wins, so a re-measure supersedes an earlier one.
    latest = {}
    with open(args.csv, newline="") as fh:
        for rec in csv.DictReader(fh):
            try:
                latest[int(rec["row"])] = rec
            except (TypeError, ValueError, KeyError):
                continue

    wb = load_workbook(args.workbook)
    ws = wb["Readings"]

    written = skipped = 0
    for row, rec in sorted(latest.items()):
        cell = ws.cell(row=row, column=READING_COL)
        if cell.value not in (None, "") and not args.overwrite:
            skipped += 1
            continue
        if args.dry_run:
            print("  row %-4d %-6s <- %s" % (row, rec.get("direction", ""),
                                             rec.get("reading", "")))
        else:
            cell.value = _coerce(rec.get("reading", ""))
            ws.cell(row=row, column=TAKEN_COL).value = rec.get("utc", "")
        written += 1

    if args.dry_run:
        print("\nDRY RUN: would write %d, skip %d already-filled" % (written, skipped))
        return 0

    wb.save(args.workbook)
    print("merged %d readings into %s" % (written, args.workbook))
    if skipped:
        print("  %d rows already had values (use --overwrite to replace)" % skipped)
    return 0


if __name__ == "__main__":
    sys.exit(main())
