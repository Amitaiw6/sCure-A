#!/usr/bin/env python3
"""Generate the UV uniformity scan workbook.

Rows are written in the order they will actually be measured, so the target row
advances by exactly 1 every time. An earlier layout interleaved the manual
directions between the servo ones, which made the row number jump 4 -> 8 -> 14
and was easy to lose track of.

    python3 scan/make_workbook.py [path.xlsx]

The grid, the serpentine path and the measurement order all come from
scan_plan.py -- imported, never duplicated.
"""

import os
import sys

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
except ImportError:
    print("openpyxl missing. Fix: python -m pip install openpyxl")
    sys.exit(2)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scan_plan import (X_MM, Y_MM, Z_COUNT, Z_SPAN_MM,              # noqa: E402
                       X_COUNT, Y_COUNT, Y_STEPS_PER_MM, Z_STEPS_PER_MM,
                       SERVO, MANUAL_ORDER, PHASES, READING_COL,
                       z_positions, plan)

HEADERS = [
    ("ID", 6), ("Phase", 14), ("X idx", 6), ("Y idx", 6), ("Z idx", 6),
    ("X mm", 9), ("Y mm", 9), ("Z mm", 9), ("Y steps", 10), ("Z steps", 10),
    ("Direction", 11), ("Method", 9), ("Servo deg", 10),
    ("Reading", 12), ("Units", 9), ("Taken at", 20), ("Notes", 26),
]


def build(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Readings"

    head_font = Font(bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="404040")
    fills = {"AUTO": PatternFill("solid", fgColor="E3F0FF")}
    shades = ["FFE9D6", "FFF6D6", "EBFFE0"]
    for i, d in enumerate(MANUAL_ORDER):
        fills["MANUAL-" + d] = PatternFill("solid", fgColor=shades[i % len(shades)])
    entry_fill = PatternFill("solid", fgColor="FFFFCC")

    for c, (name, width) in enumerate(HEADERS, start=1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(c)].width = width
    ws.freeze_panes = "A2"

    rows = plan()
    for i, r in enumerate(rows):
        row = i + 2
        vals = [r["id"], r["phase"], r["x"], r["y"], r["z"],
                round(r["xmm"], 2), round(r["ymm"], 2), round(r["zmm"], 2),
                r["ysteps"], r["zsteps"], r["dir"], r["method"],
                r["angle"] if r["angle"] is not None else "",
                None, None, None, None]
        fill = fills.get(r["phase"], fills["AUTO"])
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=row, column=c, value=v)
            if c <= 13:
                cell.fill = fill
        ws.cell(row=row, column=READING_COL).fill = entry_fill

    info = wb.create_sheet("README")
    for i, line in enumerate(readme_lines(len(rows)), start=1):
        info.cell(row=i, column=1, value=line)
    info.column_dimensions["A"].width = 100

    wb.save(path)
    return rows


def readme_lines(total):
    """Derived from scan_plan, not hand-written, so it cannot go stale."""
    zs = z_positions()
    spacing = (zs[1] - zs[0]) if len(zs) > 1 else 0.0
    auto_n = X_COUNT * Y_COUNT * Z_COUNT * len(SERVO)
    man_n = X_COUNT * Y_COUNT * Z_COUNT
    out = [
        "UV Uniformity Jig - scan workbook",
        "",
        "ROWS ARE IN MEASUREMENT ORDER. The row you are asked for always",
        "advances by exactly 1 - just work straight down the sheet.",
        "",
        "EASIEST WAY TO RUN IT: the web console.",
        "  python3 web/server.py     then open the URL it prints.",
        "  Type a reading, press Enter, and the jig moves itself to the next",
        "  point. Nothing here needs saving for the scan to advance.",
        "",
        "AXES",
        "  X: %s mm  - MOVED BY HAND, one full pass per layer" % " / ".join("%g" % v for v in X_MM),
        "  Y: %s mm  - driven" % " / ".join("%g" % v for v in Y_MM),
        "  Z: %d levels, 0 -> %g mm (%.2f mm apart) - driven" % (Z_COUNT, Z_SPAN_MM, spacing),
        "",
        "ORDER - phase-major, so each sensor orientation is set ONCE and then",
        "carried through all three X layers. %d hand repositions per scan,"
        % len(MANUAL_ORDER),
        "not %d." % (len(MANUAL_ORDER) * X_COUNT),
        "  AUTO          %3d rows  servo aims %s at every point"
        % (auto_n, "/".join(d for d, _ in SERVO)),
        "                          (the four faces alternate order point to",
        "                           point -- follow the Direction column)",
    ]
    for d in MANUAL_ORDER:
        out.append("  MANUAL-%-6s %3d rows  point the sensor %s once, then all three X layers"
                   % (d, man_n, d.lower()))
    out += [
        "",
        "THE LEFT PASS IS TAKEN WITH THE JIG TURNED 180 DEGREES.",
        "The driven axis then runs backwards relative to the chamber. The plan",
        "already compensates: a LEFT row carries the TRUE chamber Y, and the",
        "step target is the mirrored carriage position. Nothing to correct after.",
        "",
        "Total rows: %d" % total,
        "",
        "SIGN CONVENTIONS",
        "  Driven Y travel is NEGATIVE from the origin hard stop.",
        "  Z is positive upward from the bottom origin.",
        "  Scales differ ~6x: Y %d steps/mm, Z %d steps/mm. Never mix them."
        % (Y_STEPS_PER_MM, Z_STEPS_PER_MM),
    ]
    return out


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "uv_scan.xlsx")
    if os.path.exists(path):
        print("REFUSED: %s already exists." % path)
        print("         Move or delete it first -- regenerating would wipe any")
        print("         readings already entered.")
        return 1
    rows = build(path)
    print("wrote %s" % path)
    print("  %d rows, in measurement order" % len(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
