#!/usr/bin/env python3
"""The scan grid, and the exact order every point is measured in.

SINGLE SOURCE OF TRUTH. make_workbook.py builds the spreadsheet from it and
web/server.py drives the jig from it, so the two can never disagree about which
row is which. Deliberately stdlib-only.

------------------------------------------------------------------ the frame --

Corrected 2026-08-31. The axes were previously mislabelled: what the jig drives
is the chamber's Y, and the layers moved by hand are the chamber's X.

    X   3 layers at 0 / 85 / 170 mm      MOVED BY HAND, one full pass per layer
    Y   3 positions at 0 / 75 / 150 mm   driven, 800 steps/mm
    Z   10 levels, 0 -> 300 mm           driven, 128 steps/mm
        (128 = exactly 25.000 mm/rev, measured 2026-08-31: the full
         39000-step travel is 12 inches. 300 mm uses 38400 of those
         steps, leaving ~4.7 mm of travel unused at the top.)

    3 x 3 x 10 = 90 points, six faces at each -> 540 readings.

--------------------------------------------------------------- the ordering --

Phase-major, not layer-major. The sensor's orientation is the expensive thing to
change, so each orientation is set once and then carried through all three X
layers:

    AUTO           servo aims BACK / UP / FRONT / DOWN    360 readings
    MANUAL-RIGHT   point the sensor right, once            90
    MANUAL-LEFT    point it left, once                     90

That is two hand repositions for the whole scan instead of nine. DOWN joined
the servo phase on 2026-10-05, when the 180-degree servo was replaced with a
270-degree one: the rotation that goes BACK -> UP -> FRONT simply carries on
to DOWN at 270.

The four servo faces alternate order from one point to the next (BACK..DOWN,
then DOWN..BACK), so the horn serpentines like the axes do: between two
neighbouring points it does not move at all, and no single step is ever more
than 90 degrees. Follow the direction the console shows for each row.

------------------------------------------------- the reversed LEFT pass ------

LEFT is reached by rotating the whole jig 180 degrees from the RIGHT setup, so
the driven axis then runs BACKWARDS relative to the chamber. That is compensated
here rather than afterwards: a LEFT row carries the true chamber Y in `y`, and a
`ysteps` computed from the mirrored position the carriage must actually go to.

The 30 Aug scan was taken before this existed and had to be corrected by hand
(analysis/correct_scan.py). Baking it into the plan means it cannot be forgotten.
"""

X_MM = [0.0, 85.0, 170.0]        # hand-moved layers
Y_MM = [0.0, 75.0, 150.0]        # driven
Z_COUNT = 10
Z_SPAN_MM = 300.0
X_COUNT = len(X_MM)
Y_COUNT = len(Y_MM)

Y_STEPS_PER_MM = 800
Z_STEPS_PER_MM = 128
Y_SIGN = -1        # driven Y travel runs negative from the origin hard stop
Z_SIGN = +1
Y_SPAN_MM = max(Y_MM)

# Angle -> direction. The servo is driven by the EiBotBoard's S2 output, where
# 0 deg = 500 us and 270 deg = 2500 us (a 270-degree servo since 2026-10-05).
# One rotation sweeps BACK -> UP -> FRONT -> DOWN, 90 deg apart, so all four
# are aimed by the servo. Listed in rotation order; plan() alternates the
# order per point so the horn never jumps across the range.
SERVO = [("BACK", 0), ("UP", 90), ("FRONT", 180), ("DOWN", 270)]
SERVO_MAX_DEG = 270
# The two faces the servo cannot reach -- they are about the other axis -- in
# the order they are measured.
MANUAL_ORDER = ["RIGHT", "LEFT"]
# Rotating the jig for this pass reverses the driven axis.
REVERSED_PHASES = {"MANUAL-LEFT"}

DIRECTIONS = [d for d, _ in SERVO] + list(MANUAL_ORDER)
PHASES = ["AUTO"] + ["MANUAL-" + d for d in MANUAL_ORDER]

READING_COL = 14          # column N in the workbook
FIRST_DATA_ROW = 2

# Step rates are a property of the MACHINE, not the grid, so they live in
# limits.json and are read through tools/ebb.py. They used to be duplicated
# here, which is how the two drift apart.


def z_positions():
    return [i * Z_SPAN_MM / (Z_COUNT - 1) for i in range(Z_COUNT)]


def drive_y_mm(ymm, phase):
    """Where the carriage must actually go to place the sensor at chamber Y.

    Identical to ymm normally. During a reversed pass the jig is turned around,
    so the carriage runs to the mirrored position instead.
    """
    return (Y_SPAN_MM - ymm) if phase in REVERSED_PHASES else ymm


def steps(ymm, zmm, phase="AUTO"):
    return (Y_SIGN * int(round(drive_y_mm(ymm, phase) * Y_STEPS_PER_MM)),
            Z_SIGN * int(round(zmm * Z_STEPS_PER_MM)))


def sweep(y_forward, z_up_first):
    """Serpentine walk over the driven Y/Z plane of one X layer.

    Z reverses every Y column, so the sensor never drives the full length of Z
    just to get back to the start of the next column. y_forward / z_up_first let
    successive blocks pick up where the last one finished.
    """
    zs = z_positions()
    ys = list(enumerate(Y_MM, start=1))
    if not y_forward:
        ys = list(reversed(ys))
    out = []
    z_up = z_up_first
    for yi, ymm in ys:
        zl = list(enumerate(zs, start=1))
        if not z_up:
            zl = list(reversed(zl))
        for zi, zmm in zl:
            out.append((yi, ymm, zi, zmm))
        z_up = not z_up
    return out


def plan():
    """Every reading, in the exact order it will be taken.

    Phase-major: one sensor orientation carried across all three X layers before
    the next is set. Every block alternates its serpentine direction so it starts
    where the previous one finished.
    """
    out = []
    rid = 1
    block = 0
    point = 0          # AUTO points so far, so the face order can alternate
    for phase in PHASES:
        for xi, xmm in enumerate(X_MM, start=1):
            forward = (block % 2 == 0)
            for yi, ymm, zi, zmm in sweep(y_forward=forward, z_up_first=forward):
                ys, zs_ = steps(ymm, zmm, phase)
                if phase == "AUTO":
                    # Serpentine the servo too: the last face of one point is
                    # the first face of the next, so it need not move between
                    # points and never steps more than one face (90 deg).
                    faces = SERVO if point % 2 == 0 else SERVO[::-1]
                    point += 1
                    for direction, angle in faces:
                        out.append(dict(id=rid, phase=phase, x=xi, y=yi, z=zi,
                                        xmm=xmm, ymm=ymm, zmm=zmm,
                                        ysteps=ys, zsteps=zs_, dir=direction,
                                        method="SERVO", angle=angle,
                                        reversed=phase in REVERSED_PHASES))
                        rid += 1
                else:
                    out.append(dict(id=rid, phase=phase, x=xi, y=yi, z=zi,
                                    xmm=xmm, ymm=ymm, zmm=zmm,
                                    ysteps=ys, zsteps=zs_,
                                    dir=phase.split("-", 1)[1],
                                    method="MANUAL", angle=None,
                                    reversed=phase in REVERSED_PHASES))
                    rid += 1
            block += 1
    for i, r in enumerate(out):
        r["row"] = i + FIRST_DATA_ROW
    return out


if __name__ == "__main__":
    rows = plan()
    print("%d rows" % len(rows))
    for ph in PHASES:
        sel = [r for r in rows if r["phase"] == ph]
        print("  %-13s %3d rows, rows %d-%d" % (ph, len(sel), sel[0]["row"], sel[-1]["row"]))
        for xi in range(1, X_COUNT + 1):
            s = [r for r in sel if r["x"] == xi]
            print("      X layer %d (%g mm): %3d rows, rows %d-%d"
                  % (xi, X_MM[xi - 1], len(s), s[0]["row"], s[-1]["row"]))
    print()
    auto = [r for r in rows if r["phase"] == "AUTO"]
    jumps = [abs(b["angle"] - a["angle"]) for a, b in zip(auto, auto[1:])]
    print("servo travel check -- AUTO phase: %d steps, largest %d deg, "
          "%d of them zero (same face carried to the next point)"
          % (len(jumps), max(jumps), jumps.count(0)))
    print()
    print("reversed pass check -- MANUAL-LEFT drives to the mirrored Y:")
    for yi, ymm in enumerate(Y_MM, start=1):
        n = [r for r in rows if r["phase"] == "MANUAL-LEFT" and r["y"] == yi][0]
        a = [r for r in rows if r["phase"] == "MANUAL-RIGHT" and r["y"] == yi][0]
        print("   chamber Y%d (%3g mm):  RIGHT drives %7d steps   LEFT drives %7d steps"
              % (yi, ymm, a["ysteps"], n["ysteps"]))
