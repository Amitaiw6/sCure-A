#!/usr/bin/env python3
"""Terminal scan runner: move, wait for a typed reading, repeat.

    python3 scan/scan_live.py --x 1
    python3 scan/scan_live.py --x 1 --dry-run

Type the value and press Enter and it advances immediately -- nothing to save.
The web console (web/server.py) is the nicer way to do this; keep this for when
you want a terminal, or the browser is unavailable.

At the prompt:
    <number>   record it and move on
    <Enter>    skip this point, leave it blank
    b          go back one point
    r          re-read and report the axis position
    q          quit (rerun to resume where you left off)

Readings stream to scan/scan_readings.csv and are fsync'd before the prompt
returns, so an interruption cannot cost a measurement. The workbook is never
written here -- use scan/merge_readings.py.
"""

import argparse
import csv
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, HERE)

from serial_min import Serial, SerialError, resolve_port           # noqa: E402
import ebb                                                          # noqa: E402
import scan_plan                                                    # noqa: E402

CSV_PATH = os.path.join(HERE, "scan_readings.csv")
CSV_HEADER = ["utc", "row", "id", "phase", "x_idx", "y_idx", "z_idx",
              "x_mm", "y_mm", "z_mm", "y_steps", "z_steps",
              "direction", "servo_deg", "reading"]
SETTLE_S = 1.0
MANUAL_PARK_ANGLE = 90


def load_done():
    done = {}
    if not os.path.exists(CSV_PATH):
        return done
    with open(CSV_PATH, newline="") as fh:
        for rec in csv.DictReader(fh):
            try:
                done[int(rec["row"])] = rec.get("reading", "")
            except (TypeError, ValueError, KeyError):
                continue
    return done


def record(r, value):
    new = not os.path.exists(CSV_PATH)
    with open(CSV_PATH, "a", newline="") as fh:
        w = csv.writer(fh)
        if new:
            w.writerow(CSV_HEADER)
        w.writerow([time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    r["row"], r["id"], r["phase"], r["x"], r["y"], r["z"],
                    r["xmm"], r["ymm"], r["zmm"], r["ysteps"], r["zsteps"], r["dir"],
                    "" if r["angle"] is None else r["angle"], value])
        fh.flush()
        os.fsync(fh.fileno())


def goto(p, limits, ty, tz):
    pos = ebb.read_position(p)
    if pos is None:
        raise SerialError("could not read the step position")
    moved = []
    for axis, target, cur, rate in (("Y", ty, pos[0], ebb.Y_RATE_HZ),
                                    ("Z", tz, pos[1], ebb.Z_RATE_HZ)):
        delta = target - cur
        if delta == 0:
            continue
        dy, dz = (delta, 0) if axis == "Y" else (0, delta)
        bad = ebb.check_limits(limits, ebb.read_position(p), dy, dz)
        if bad:
            raise SerialError("soft limit: " + "; ".join(bad))
        moved.append("%s %+d" % (axis, delta))
        for cy, cz, cd in ebb.split_move(dy, dz, rate):
            ebb.send_move(p, cy, cz, cd)
            # Silence during motion -- see tools/ebb.py.
            time.sleep(ebb.move_duration_s(cd))
    if moved:
        time.sleep(SETTLE_S)
    return ebb.read_position(p), moved


def banner(phase, direction):
    print()
    print("#" * 72)
    if phase == "AUTO":
        print("# PHASE: AUTO -- the servo aims the sensor %s at each point."
              % " / ".join(d for d, _ in scan_plan.SERVO))
        print("# Nothing to do by hand.")
    else:
        print("# PHASE: %s" % phase)
        print("#")
        print("#   >>> POINT THE SENSOR %s, BY HAND, NOW <<<" % direction)
        print("#")
        print("# Once. The jig then sweeps every X/Z point in this orientation.")
        print("# The servo parks at %d deg (UP) and will not move." % MANUAL_PARK_ANGLE)
    print("#" * 72)
    sys.stdout.flush()


def main():
    ap = argparse.ArgumentParser(description="Run one X layer of the UV scan.")
    ap.add_argument("--x", type=int, required=True,
                    choices=range(1, scan_plan.X_COUNT + 1),
                    help="which hand-moved X layer to run")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--port", default=None)
    args = ap.parse_args()

    rows = [r for r in scan_plan.plan() if r["x"] == args.x]
    done = load_done()
    todo = [r for r in rows if r["row"] not in done]

    print("=" * 72)
    print("UV SCAN -- X layer %d  (%g mm)" % (args.x, scan_plan.X_MM[args.x - 1]))
    print("=" * 72)
    print("progress : %d of %d done" % (len(rows) - len(todo), len(rows)))
    for ph in scan_plan.PHASES:
        n = [r for r in rows if r["phase"] == ph]
        left = [r for r in n if r["row"] not in done]
        print("   %-13s %2d/%2d done" % (ph, len(n) - len(left), len(n)))
    if not todo:
        print("\nX layer %d is complete." % args.x)
        return 0

    if args.dry_run:
        print("\nDRY RUN -- nothing will move\n")
        for r in todo[:12]:
            print("   row %-4d X=%-5.0f Y=%-5.0f Z=%-7.2f %-6s %s"
                  % (r["row"], r["xmm"], r["ymm"], r["zmm"], r["dir"],
                     ("servo %s deg" % r["angle"]) if r["method"] == "SERVO"
                     else "by hand"))
        if len(todo) > 12:
            print("   ... and %d more" % (len(todo) - 12))
        return 0

    limits = ebb.load_limits()
    try:
        p = Serial(resolve_port(args.port))
    except SerialError as e:
        print("FAIL: %s" % e)
        return 2
    if p.sync() is None:
        print("FAIL: could not synchronise with the EBB; not moving.")
        p.close()
        return 2
    counts = ebb.read_vplus(p)
    if not ebb.supply_present(counts):
        print("FAIL: motor supply reads %s counts. The board will count steps"
              % counts)
        print("      and nothing will turn. Switch the DC supply on.")
        p.close()
        return 2
    print("\nconnected: EBB synced, motor supply present")

    i = 0
    phase = None
    n_done = 0
    servo_at = None      # last angle commanded; None = unknown, allow full travel
    try:
        while i < len(todo):
            r = todo[i]
            if r["phase"] != phase:
                phase = r["phase"]
                banner(phase, r["dir"])
                if r["method"] == "MANUAL":
                    ebb.servo_set_angle(p, MANUAL_PARK_ANGLE,
                                        settle=ebb.servo_travel_s(servo_at, MANUAL_PARK_ANGLE))
                    servo_at = MANUAL_PARK_ANGLE

            pos, moved = goto(p, limits, r["ysteps"], r["zsteps"])
            if r["method"] == "SERVO" and r["angle"] != servo_at:
                # The wait scales with the swing: 90 deg is quick, the full 270
                # from an unknown start is not.
                ebb.servo_set_angle(p, r["angle"],
                                    settle=ebb.servo_travel_s(servo_at, r["angle"]))
                servo_at = r["angle"]

            print("-" * 72)
            print("[%d/%d] %-13s X=%.0f  Y=%.0f  Z=%.1f mm  %-6s%s"
                  % (i + 1, len(todo), r["phase"], r["xmm"], r["ymm"], r["zmm"], r["dir"],
                     "  (servo %d deg)" % r["angle"] if r["method"] == "SERVO" else ""))
            if moved:
                print("  moved %s -> %s" % (", ".join(moved), pos))

            try:
                raw = input("reading> ").strip()
            except EOFError:
                raw = "q"
            if raw == "q":
                break
            if raw == "b":
                i = max(0, i - 1)
                continue
            if raw == "r":
                print("  position %s" % (ebb.read_position(p),))
                continue
            if raw == "":
                print("  skipped")
                i += 1
                continue
            record(r, raw)
            n_done += 1
            print("  recorded '%s' (row %d)" % (raw, r["row"]))
            i += 1

        print()
        print("=" * 72)
        print("%d readings this session." % n_done)
        left = [r for r in rows if r["row"] not in load_done()]
        if left:
            print("%d still to do in layer %d -- rerun to resume." % (len(left), args.x))
        elif args.x < scan_plan.X_COUNT:
            print("Layer %d complete. Move the jig to X = %g mm and run --x %d."
                  % (args.x, scan_plan.X_MM[args.x], args.x + 1))
        else:
            print("All %d X layers done." % scan_plan.X_COUNT)
    except KeyboardInterrupt:
        print("\ninterrupted after %d readings -- rerun to resume" % n_done)
    except SerialError as e:
        print("\nFAIL: %s" % e)
        return 2
    finally:
        p.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
