"""
Talk to an Ophir StarBright laser power/energy meter over USB.

Uses Ophir's OphirLMMeasurement COM object, which is installed and registered
by the StarLab application (https://www.ophiropt.com/en/g/starlab-for-usb).
StarLab also installs the USB kernel driver the meter needs (VID 0BD3 / PID 0346).

Usage:
    python starbright.py            # identify meter + sensor, print 5 s of readings
    python starbright.py --seconds 30
    python starbright.py --info     # identify only, no streaming
    python starbright.py --list     # just list Ophir USB devices

Requires:  pip install --user pywin32
"""
import argparse
import sys
import time

try:
    import win32com.client
    import pythoncom
except ImportError:
    sys.exit("pywin32 is missing: python -m pip install --user pywin32")

PROGID = "OphirLMMeasurement.CoLMMeasurement"


def connect():
    try:
        return win32com.client.Dispatch(PROGID)
    except pythoncom.com_error as e:
        sys.exit(
            f"Could not create {PROGID} ({e}).\n"
            "The Ophir COM object is not registered. Install StarLab "
            "(run its setup as Administrator); it registers the COM object and "
            "installs the StarBright USB driver."
        )


def list_devices(lm):
    serials = list(lm.ScanUSB())
    if not serials:
        print("No Ophir USB devices found.")
        print("Check Device Manager: 'StarBright' must not show a yellow ! (driver Code 28).")
    for s in serials:
        print(f"Found Ophir USB device, serial {s}")
    return serials


def describe(lm, h, ch=0):
    name, rom, sn = lm.GetDeviceInfo(h)          # (deviceName, romVersion, serialNumber)
    print(f"Device : {name}  S/N {sn}  firmware {rom}")
    s_sn, s_type, s_name = lm.GetSensorInfo(h, ch)  # (serialNumber, sensorType, sensorName)
    print(f"Sensor : {s_name or '(none)'}  S/N {s_sn}  type {s_type}")
    if not s_name:
        print("No sensor head attached to the meter - nothing to measure.")
        return False
    idx, ranges = lm.GetRanges(h, ch)              # (index, options)
    print(f"Ranges : {list(ranges)}  (active: {ranges[idx]})")
    idx, wls = lm.GetWavelengths(h, ch)
    print(f"Wavel. : {list(wls)}  (active: {wls[idx]})")
    idx, modes = lm.GetMeasurementMode(h, ch)
    print(f"Modes  : {list(modes)}  (active: {modes[idx]})")
    return True


def stream(lm, h, seconds, ch=0):
    lm.StartStream(h, ch)
    print(f"Streaming for {seconds:.0f} s ... (Ctrl+C to stop)")
    t_end = time.time() + seconds
    try:
        while time.time() < t_end:
            values, timestamps, statuses = lm.GetData(h, ch)
            for v, ts, st in zip(values, timestamps, statuses):
                print(f"{ts:12.3f} ms  {v: .6g}  status={st}")
            time.sleep(0.2)
    except KeyboardInterrupt:
        pass
    finally:
        lm.StopStream(h, ch)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--seconds", type=float, default=5)
    ap.add_argument("--info", action="store_true", help="identify only")
    ap.add_argument("--list", action="store_true", help="scan for devices only")
    ap.add_argument("--serial", help="pick a specific meter serial number")
    a = ap.parse_args()

    lm = connect()
    print("COM object version:", lm.GetVersion())
    serials = list_devices(lm)
    if a.list or not serials:
        return
    sn = a.serial or serials[0]
    h = lm.OpenUSBDevice(sn)
    try:
        has_sensor = describe(lm, h)
        if has_sensor and not a.info:
            stream(lm, h, a.seconds)
    finally:
        lm.Close(h)
        lm.StopAllStreams()
        lm.CloseAll()


if __name__ == "__main__":
    main()
