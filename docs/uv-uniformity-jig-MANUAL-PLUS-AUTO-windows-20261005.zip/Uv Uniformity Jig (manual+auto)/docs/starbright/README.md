# StarBright meter — driver and protocol notes

Used by the console in **Auto mode** (`web/server.py` → `tools/starbright.py`).
Manual mode never touches any of this.

`tools/starbright.py` reaches the meter two ways, same protocol, same readings:

| | RS‑232 (`SerialMeter`) | USB (`OphirMeter`) |
|---|---|---|
| Cable | the meter's RS‑232 socket → any COM port / USB‑serial adapter | the meter's USB socket |
| Driver | **none from Ophir** — the adapter's own in-box driver | Ophir's WinUSB `ophdev.inf` (bundled in `driver/`, or via StarLab) |
| Admin | no | once, to install the driver |
| Platform | Windows and Linux | Windows |
| Speed | ~20 ms per command at 9600 baud, plenty for 5 Hz polling | ~2 ms |

## RS‑232 — no driver, no admin

1. Connect the meter's RS‑232 port to a COM port or a USB‑serial adapter
   (FTDI / CP210x / CH340 / Prolific all use Windows' stock drivers).
2. In the console: Auto mode → *Connection* = **RS‑232**, port blank, *Connect
   meter*. Auto-detect probes every serial port **except the EiBotBoard's**
   with `$VE` at 9600 / 19200 / 38400 / 115200 / 57600 / 14400 / 4800 until the
   meter answers `*`. Or name the port (`COM5`, `/dev/ttyUSB0`).
3. Framing per *Ophir User Commands*: `$XX` + LF CR out, reply + LF CR back.

```
python tools/starbright.py --ports                 # what serial ports exist (board marked)
python tools/starbright.py --serial                # auto-detect, identify, one reading
python tools/starbright.py --serial COM5 --baud 9600 --stream 10
```

If nothing answers at any rate: meter switched on? Right cable (the StarBright
RS‑232 lead from Ophir)? Then check the meter's own serial settings in its
setup menu.

## USB — Ophir's WinUSB driver (needs Administrator, once)

The StarBright enumerates as `USB\VID_0BD3&PID_0346` (vendor-specific class
FF). Windows cannot talk to it without a driver bound; Ophir's is a plain
**WinUSB** binding. Two ways to get it:

* **Bundled:** `docs/starbright/driver/ophdev.inf` + `ophdev.cat` (Ophir-signed,
  taken from StarLab 3.92). Right-click `ophdev.inf` → **Install** (or
  `pnputil /add-driver ophdev.inf /install` from an admin prompt), re-plug the
  meter. No download.
* **StarLab:** <https://www.ophiropt.com/en/g/starlab-for-usb> (direct:
  <https://api.p1.mks.com/mam/celum/celum_assets/resources/StarLab.zip>, 3.92,
  Authenticode-signed). Run as Administrator; installs the same driver.

Device Manager should then show *StarBright* under *OphirMeasurementDevice*
with no yellow `!` (before: *Code 28: drivers not installed*). Nothing else is
needed: the driver code talks to `winusb.dll` through `ctypes`, no pip packages.

## Talking to the meter

```
python tools/starbright.py                  # USB: identity + config + one reading
python tools/starbright.py --stream 10      # live readings for 10 s
python tools/starbright.py --cmd VE --cmd AR --cmd "WN -1"   # raw commands
python tools/starbright.py --sim            # the simulated meter used by --sim
```

```python
from starbright import open_meter   # tools/starbright.py
with open_meter("auto") as m:       # "usb" | "serial" | "serial:COM5" | "sim"
    m.set_wavelength(395)      # nm, within the AW range
    m.set_range(-1)            # AUTO
    print(m.power(), m.query("SI"))   # e.g. 0.0002 'w'  -> W/cm^2
```

## The USB protocol (found by tracing Ophir's own DLL, 2026-09-01)

Ophir's ASCII commands from *Ophir User Commands.pdf* (installed with StarLab
under `Automation Examples`) are sent as WinUSB **vendor control transfers** —
not on the bulk endpoints, which never answer:

    OUT  bmRequestType 0x40, bRequest 2, data = "$CMD\r\n"
    IN   bmRequestType 0xC0, bRequest 4, wLength 4096  -> "*reply\n" | "?error\n"

Useful commands: `VE` version · `II` instrument · `HI` head · `HT` head type ·
`SI` units (`w` = W/cm²) · `SP` send power · `AR` ranges · `GU` range in use ·
`WN n` set range (−1 = AUTO) · `AW` wavelengths · `WL nm` set wavelength ·
`WI i` wavelength by index · `MM` measurement mode · `FP` force power.

The device interface GUID Ophir's driver registers is
`{3E0EE3A4-5F0E-40E9-94A1-5F0711CE2517}`; `tools/starbright.py` enumerates it
with SetupAPI, so any Ophir WinUSB meter (Juno, Nova II, Vega, StarLite,
StarBright, Centauri…) that speaks the same commands should work.

## This meter (verified 2026-09-01)

StarBright S/N 821302, firmware SB1.30, sensor **PD300RM-8W** S/N 862870
(radiometric photodiode, 350–850 nm, reads irradiance in W/cm²), ranges
AUTO / 30 W/cm² … 30 µW/cm², wavelength favourites 375 / 395 / 385 / 450 / 405 nm,
calibrated 21-09-2016, calibration **due 21-03-2018** — treat absolute values
as relative until it is recalibrated.

## Why Ophir's COM object is not used

`OphirLMMeasurement` (the COM object StarLab registers) opens this meter,
queries it, then **drops it from `ScanUSB()`** after firmware SB1.30 rejects a
`$VH` query — most likely no support for the PD300RM head on a StarBright. The
COM route is kept only as reference in `starbright_com_reference.py`
(needs `pip install pywin32`); its manual is
`OphirLMMeasurement_COM_Manual_v15.pdf`.

## Troubleshooting

| Symptom | Meaning | Fix |
|---|---|---|
| *StarBright* with yellow `!` / Code 28 in Device Manager | no driver | install StarLab as Administrator, re-plug |
| Console: *no Ophir USB meter present* | not enumerated | check the cable and that the meter is **on** |
| Descriptors read but every command times out | instrument off or hung | power-cycle the meter at its switch with USB connected |
| `CreateFile failed` / sharing error | StarLab (or another console) holds the meter | close it |
| RS‑232: *no Ophir meter answered on COMx (tried 9600/…)* | wrong port, cable, meter off, or its serial setting | try *Ports*, check the lead, power-cycle the meter |
| RS‑232: *no serial port to try* | only the EiBotBoard's port exists | plug in the USB‑serial adapter (its own driver is in-box) |
| USB: anything unclear | — | `python tools\starbright.py --doctor` prints the meter's driver service, interface IDs, whether StarLab is running, and an open test. Send its output. |
| Readings never settle | source flickering, sensor swinging, range hunting | lengthen dwell / tolerance in *Settling rules*, or fix the range with `WN` |

The USB route works with whichever StarLab version is installed: the meter's
device-interface IDs are read from its own registry entry rather than assumed,
and each one is tried until the meter opens. The one requirement is that the
driver StarLab installed is **WinUSB** — `--doctor` says so if it is not.
