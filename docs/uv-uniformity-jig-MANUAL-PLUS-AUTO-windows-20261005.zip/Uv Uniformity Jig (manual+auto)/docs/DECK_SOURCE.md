# UV Uniformity Jig
## A two-axis stage with a rotating sensor head

How the machine is built, how it moves, and how it knows where it is.

Two stepper-driven threaded rods stacked in series, one RC servo, three degrees
of freedom, one control board.

---

## A positioner, not an instrument

**Three degrees of freedom.** Two linear axes place a payload anywhere in a
vertical plane. One rotary axis then points it. Everything else about the jig
serves those three movements.

**The payload is incidental.** Today it carries a UV sensor. The stage does not
know or care what is bolted to the end of it — swap the head and it is a general
two-axis scanning positioner.

**Repeatability is the whole point.** The value of a jig like this is going back
to the same place twice. That is why so much of the design is about establishing
and keeping a zero.

**Built from ordinary parts.** Stepper motors turning threaded rods, each driving
a slider. No linear encoders, no limit switches, no feedback on the axes — which
means position is inferred by counting steps issued, never measured.

---

## The kinematic chain

Each stage is carried by the one before it.

1. **Axis 1** — a stepper motor turns a threaded rod, which drives a slider.
   Bolted to the frame. This is the base stage.
2. *carries*
3. **Axis 2** — a second stepper motor, its own threaded rod, its own slider.
   The whole second stage rides on the first slider.
4. *carries*
5. **Rotary** — an RC servo.
6. *carries*
7. **Payload** — the UV sensor.

**Serial, not gantry.** The axes are stacked rather than independent. Axis 2 does
not sit on the frame — its motor, rod, slider, servo and sensor are all cargo
that axis 1 has to move.

**What that costs.** Axis 1 sees far more inertia than axis 2, so it wants the
gentler acceleration. Anything added to the head is felt by both axes. And the
cables feeding motor 2 and the servo have to flex every time axis 1 moves, which
is where this kind of build usually fails first.

---

## How a turning rod becomes travel

**A threaded rod is a rotary-to-linear converter.** One turn advances the slider
by exactly one lead. Nothing else in the chain changes that ratio.

**Resolution falls straight out of it.** 3200 steps per motor revolution at 1/16
microstepping. Divide the lead by 3200 and that is the smallest commanded move.

**Speed and resolution trade against each other.** A fine lead gives small steps
and slow travel; a coarse lead gives quick travel and coarse steps.

**Lead screws mostly do not back-drive.** A fine-pitch rod holds position with the
motor unpowered, which is why a vertical axis on a lead screw does not drop.

**Axis 2's figures are unresolved.** 130 steps/mm implies 24.6 mm per revolution,
which is far too high a lead for an ordinary threaded rod — even a coarse
12.7 mm/rev rod would give only 155 mm of travel in the 39,000 steps recorded,
not 300 mm. Either the travel was mis-measured or the rod is not what we assume.
Measure it with calipers.

---

## Working envelope

| | Axis 1 | Axis 2 | Servo |
|---|---|---|---|
| Travel | 150 mm | ~300 mm (verify) | 270° |
| Origin | hard stop | bottom of travel | centre = 90° |
| Steps per mm | 800 | 130 (?) | n/a |
| Working rate | 12000 steps/s | 3000 steps/s | — |
| Full traverse | ~10 s | ~13 s | under 1 s |

A full traverse is slow because a stepper has no closed loop: push it too fast
and it silently loses steps instead of complaining. The working rates sit below
where that starts.

**The axes are not interchangeable.** Their scales differ by roughly six times,
so each carries its own.

**No hardware interlock.** Nothing stops the machine driving into its own ends
except software limits, and those bound the step counter rather than the machine.

---

## How the jig finds zero

**There are no limit switches.** Nothing electrically marks the end of travel. The
only physical reference is where the slider runs out of rod.

**So the stop itself is the datum.** Axis 1 is driven deliberately into its
mechanical stop: a fast approach to within half a turn, then a slow seat with a
quarter turn of overshoot. The two seconds of skidding you hear is the reference
being taken, not a fault.

**A stop cannot drift; a counter can.** That is the whole argument for doing it
this way. Re-homing costs a minute and re-anchors the frame to something physical.

**Zeroing is all-or-nothing.** The controller has no per-axis clear, so zeroing
resets both counters together. Axis 2 must already be at its own reference first.

---

## The rotating head

**An RC servo, not a stepper.** It takes a pulse whose width encodes an absolute
angle and drives itself there. It needs no homing — it knows its own position
internally.

**500 to 2500 microseconds spans 0 to 270 degrees.** A 270-degree servo since
October 2026; wider than the usual 1000 to 2000 range, which it needs for its
full travel. One rotation aims the sensor back, up, front and down, so four of
the six faces are reached without a hand.

**Nothing can read it back.** There is no feedback path out of an RC servo. The
controller reports the last angle it commanded — a record of intent, not a
measurement.

**It draws current when it is fighting.** Held against a mechanical limit it
buzzes and pulls stall current continuously.

---

## One board runs all three motors

A single USB control board drives axis 1, drives axis 2, and generates the RC
servo pulse train in hardware. No second microcontroller is involved.

**Two supplies, one cable.** USB carries the commands and the board's logic power.
The motors run from a separate DC supply — and the board works perfectly with
that supply switched off, while nothing turns.

---

## Commanding a move

**You give a distance and a duration, not a speed.** The board is told to move N
steps in T milliseconds and derives the rate. Both axes share one duration in a
combined move, so the shorter one simply travels slower.

**Long moves get split.** Past about 100,000 steps in a single command the rate
calculation degrades and the axis crawls. Anything longer is broken into chunks
that sum exactly, so no step is lost to rounding.

**Then the host stays silent.** The board generates step pulses from a timer
interrupt. USB traffic arriving mid-move competes with it: polling during a move
produced audible stutter and lost steps. Send the move, wait it out, verify after.

**Rates are chosen, not maximised.** Both sit below where this machine starts
skipping, which it does silently.

---

## The software, in layers

**Serial layer** — opens the port and frames commands, speaking the operating
system's native serial interface directly, so there is nothing to install.

**Board layer** — everything the controller can do (moves, limits, homing, servo
angles) in one module, so every tool behaves identically.

**Tools and console** — command-line utilities for jogging, homing and stopping,
plus a browser console for running a job.

**One definition of the machine.** Travel limits, scales and the servo range live
in a single calibration file, and nothing hard-codes a number about this jig
anywhere else.

**Motion is gated.** Nothing on the axes moves until motion is explicitly armed.

---

## Driving it from a browser

The host runs a small server; the page opens on any laptop, tablet or phone on
the same network. Only the machine with the jig plugged in needs any software.

Indicators cover the failures that actually happen: board connected, motor supply
present, live position, servo angle.

Jog, home and re-zero from the same screen, including blind homing and an override
for the soft limits. Escape is an emergency stop from anywhere on the page.

---

## What it is being used for

**Mapping UV irradiance inside a chamber.** The head carries a UV sensor. The
stage walks it through a grid of positions and the servo points it along each
axis in turn, because irradiance depends on which way the sensor faces.

The output is a uniformity figure: how much brighter the best spot is than the
worst, which is what sets the process window for anything the chamber treats.

Nothing about the stage is specific to UV. Any sensor small enough to mount on
the servo makes it a different instrument.

---

## How this kind of machine fails

**Lost steps, silently.** Too much acceleration, a snagged cable or a mechanical
bind, and the motor skips. Nothing is reported. The counter and the machine part
company.

**The counter reading zero proves nothing.** It only means the same number of
steps came back as went out. If some were never taken, zero is in the wrong place.

**Flexing cables on the moving stage.** Motor 2 and the servo are both fed by
cables that bend on every axis-1 move — the usual first failure on a stacked build.

**Power that looks fine and is not.** Everything enumerates, responds and counts
steps with the motor supply switched off.

The common thread: an open-loop machine cannot tell you it has gone wrong.

---

## Where it stands

**Working.** Both axes drive and home repeatably. The servo aims from the board's
own output. The console runs a full job end to end.

**Worth measuring.** The axis-2 scale is inconsistent with a threaded rod. Confirm
the lead and the travel with calipers before trusting any absolute distance.

**Worth adding.** Limit switches would remove the deliberate stall from homing. A
wider-sweep servo would remove a manual pass. A drag chain would protect the
cables that flex on every move.

**The standing caveat.** Open loop: position is counted, never measured.
