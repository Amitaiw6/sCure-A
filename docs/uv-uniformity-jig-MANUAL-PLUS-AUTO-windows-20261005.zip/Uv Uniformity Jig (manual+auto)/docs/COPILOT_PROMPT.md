# Prompt for Copilot in PowerPoint

Two routes. **Route B gives a much better deck** for content this specific,
because Copilot follows a source document far more faithfully than a prompt.

---

## Route A — paste straight into Copilot

Open PowerPoint → **Copilot** → paste this. Note Copilot's prompt box truncates
long input; if it does, cut the slide list at 8 and ask for the rest in a
follow-up ("now add slides 9–14: …").

> Create a 14-slide presentation explaining a piece of lab hardware called the UV
> Uniformity Jig. Audience: engineers who have never seen it. Tone: precise and
> plain — no marketing language, no exclamation marks. Clean light theme, one
> accent colour, generous whitespace, no stock photos of unrelated machinery.
>
> The machine is a two-axis positioner with a rotating head, built from ordinary
> parts, and open-loop: no encoders, no limit switches, no feedback of any kind on
> the axes. Its kinematic chain is stacked in series: a stepper motor turns a
> threaded rod that drives a slider; mounted on that slider is a second stepper
> motor with its own threaded rod and slider; on the second slider is an RC servo;
> on the servo is a UV sensor. So axis 1 carries the entire rest of the machine.
>
> Slides:
> 1. Title — "A two-axis stage with a rotating sensor head"
> 2. What it is — three degrees of freedom (two linear, one rotary); the payload is
>    incidental, swap the head and it is a different instrument; repeatability is
>    the whole point
> 3. The kinematic chain — show the stacked cascade as a top-to-bottom diagram with
>    the word "carries" between each stage
> 4. The drive — a threaded rod converts rotation into travel; 3200 steps per
>    revolution at 1/16 microstepping; resolution = lead ÷ 3200; a fine lead gives
>    small steps but slow travel
> 5. Working envelope — Y: 150 mm at 800 steps/mm; Z: 300 mm at 128 steps/mm;
>    servo 270°; working rates 12000 and 3000 steps/s
> 6. Finding zero — no limit switches, so the axis is driven deliberately into its
>    mechanical stop and that contact becomes the datum; a stop cannot drift, a
>    counter can
> 7. The rotating head — RC servo, 500–2500 µs spans 0–270°, absolute positioning
>    but no feedback path, so the angle is commanded and never measured
> 8. Electronics — one USB control board drives both steppers and generates the
>    servo pulse train in hardware; the motors run from a separate DC supply
> 9. Commanding a move — you give steps and a duration, not a speed; long moves are
>    split into chunks; the host stays silent during motion or USB traffic competes
>    with the step generator and causes stutter and lost steps
> 10. Software in layers — serial layer, board abstraction, then tools and a
>     browser console
> 11. Operating it — browser console, motion explicitly armed, emergency stop
> 12. What it is used for — mapping UV irradiance inside a chamber; keep this to one
>     slide, it is an application and not the subject
> 13. How this kind of machine fails — lost steps are never reported; a counter
>     reading zero proves nothing; cables flexing on the moving stage; motor supply
>     switched off looks exactly like a software fault
> 14. Status — it works; the axis-2 scale needs verifying with calipers; limit
>     switches and a wider-sweep servo would both help
>
> Each slide: one heading and three or four short points. On slides 6 and 13 add a
> highlighted callout saying the machine is open-loop — position is counted, never
> measured.

---

## Route B — generate from a source file (recommended)

1. Open **DECK_SOURCE.md** (next to this file) and save it as `.docx`, or paste it
   into a blank Word document and save.
2. Put the file in OneDrive or SharePoint — Copilot cannot read a local-only file.
3. In PowerPoint: **Copilot → Create presentation from file →** pick that document.
4. Follow up with: *"Make slide 3 a top-to-bottom diagram of the stacked chain,
   with 'carries' between each stage."*

Copilot keeps the headings and the ordering from a document far more reliably
than from a prompt, and nothing gets truncated.

---

## Worth checking in whatever it produces

Copilot will smooth over the details that matter most here. Check:

- **The chain is serial, not a gantry.** Axis 2 sits on axis 1's slider. If the
  diagram shows two independent axes on a frame, it is wrong.
- **Axis 2's numbers carry a caveat.** 130 steps/mm implies 24.6 mm/rev, which is
  too high a lead for an ordinary threaded rod. Do not let it be stated as fact.
- **No invented specifications.** If a slide gains a load rating, an accuracy
  figure or a duty cycle, it made them up — none have been measured.
- **Open-loop stays prominent.** It is the single most important property of the
  machine and the easiest thing for a summariser to drop.
