# Calibration

> **Axis names corrected 2026-08-31.** The driven horizontal screw is the
> chamber's **Y**; the chamber's **X** is the layer axis moved by hand at
> 0 / 85 / 170 mm. Earlier revisions called the driven screw "X".


Everything measured about this physical jig lives in `limits.json`. This file
explains where those numbers came from and how to re-derive them.

## The frame

Both axes read **0 at their own origin**:

| Axis | Origin | Usable travel | Scale |
|---|---|---|---|
| Y (driven) | the **hard stop**, reached by driving `+Y` | `0 → −121600` steps = 150 mm | 800 steps/mm |
| Z (driven) | the **bottom** | `0 → +39000` steps = 300 mm | 130 steps/mm |
| X (by hand) | — | 0 / 85 / 170 mm | no motor |

1/16 microstepping, **3200 steps per revolution** on both axes.

`CS` zeroes **both** counters — the board has no per-axis clear. Only zero with
X and Z each on their own reference.

## How the limits were established

Jogged one rotation at a time with an operator watching, marking each end. X
came out at 38.0 rotations of usable travel and a measured 150 mm; Z was
originally 400 mm and was **physically shortened by 100 mm** on 2026-08-18, to
300 mm. `steps_per_mm` for Z did not change, because the drive was untouched —
only the length of travel.

## The scales are estimates, and one is suspicious

**Driven Y: 800 steps/mm.** That is 3200 steps/rev ÷ 4.00 mm/rev, a standard 4 mm lead
screw. The *measured* figure was 810.7 steps/mm (121600 steps over 150 mm),
1.3 % high. The excess is consistent with the known slip: more steps issued than
travelled. 800 is the round, physically plausible number, so it is what is used.

**Driven Z: 130 steps/mm — unresolved.** That implies 24.6 mm/rev. Both axes are
stepper-driven threaded rods (operator-confirmed 2026-08-27), and 24.6 mm/rev is
far too high a lead for an ordinary rod:

| If the Z rod were | steps/mm | 39000 steps would travel |
|---|---|---|
| 2 mm/rev | 1600 | 24 mm |
| 4 mm/rev (same as X) | 800 | 49 mm |
| 8 mm/rev (T8) | 400 | 98 mm |
| 12.7 mm/rev (coarse) | 252 | 155 mm |

None of them reach the 300 mm recorded. So either the travel was mis-measured —
it was operator-declared during the limit search, not gauged — or the drive is
not a plain single-start rod. An earlier version of this file guessed a belt
drive from the same arithmetic; that guess is contradicted by the mechanical
description and has been withdrawn.

**Measure the lead directly**: command exactly 10 revolutions (32000 steps) and
measure how far the slider actually moves.

**Verify both with calipers over a known distance before relying on absolute
millimetres.** Command exactly 10 mm, measure what you get, and divide.

## The counter is not the machine

The soft limits bound the **step counter**. The counter records steps *issued*,
not steps *taken*, so on an axis that can slip it drifts from physical reality.

That is why a counter returning to zero proves nothing on its own, and why
homing exists: the hard stop is a physical datum that cannot drift.

## Homing

```sh
DO_MOVE=1 python3 tools/home_x.py           # counter-based
DO_MOVE=1 python3 tools/home_x.py --blind   # ignore the counter, full travel
```

Sensorless: a fast approach to within half a turn of the stop, then a slow seat
with a deliberate quarter-turn of overshoot. That overshoot is the ~2 s skid you
hear, and that contact is the reference.

Homing deliberately drives **past** `x.max`, so its moves bypass the soft-limit
check. Checking a move against the very counter it exists to re-anchor would
make homing impossible.

**Use `--blind` after any manual re-zero.** Counter-based homing trusts the
counter for the *distance* to the stop; if the counter was zeroed mid-travel it
reports "already there" and barely moves, and the following `CS` would then
zero at the wrong place.

## Servo

| | |
|---|---|
| Output | EiBotBoard **RB1**, `RP4` in the `S2` command |
| Range | **500–2500 µs** = 0–270° (270° servo since 2026-10-05) |
| Command | `S2,<µs × 12>,4,<rate>,0` |

The range is wider than the usual 1000–2000 µs: this servo needs the full span
to give all 270°. The 180° MG90S it replaced used the same span for 180°, so
`angle_to_us()` in `tools/ebb.py` now divides it by `max_deg` from
`limits.json` instead of a fixed 180.

**Orientation: 0° = BACK, 90° = UP, 180° = FRONT, 270° = DOWN.** The first
three were confirmed by the operator on the old servo. The new servo must be
fitted with its horn so that 0° still aims BACK; DOWN then falls at 270° along
the same rotation. **Confirm all four on the bench before scanning** with
`tools/servo_ctl.py --faces`. `scan/scan_plan.py` encodes this.

**Timing.** The wait before a reading scales with how far the horn travels:
`settle_s` (0.35 s) plus `s_per_deg` (0.003 s/°, so 0.8 s for the full 270°),
both in `limits.json`. `slew_rate` (default 0) makes the board ramp the pulse
instead of stepping it, if the move is harsh or the supply sags; the code
lengthens the wait to match.

**Re-check it on the bench after any remount.** A swapped direction label is
invisible in the data: every reading lands in a real-looking cell, and the error
survives into the final map looking exactly like real data.

An RC servo has no feedback path. Nothing can read its actual position — the
angle the console shows is the last one *commanded*.

## Re-deriving everything from scratch

1. Put Z on its bottom stop by hand.
2. `DO_MOVE=1 python3 tools/home_x.py --blind` — X now reads 0 at its stop, and
   `CS` has zeroed Z at its bottom too.
3. Jog X away one rotation at a time until it reaches the far end; the counter
   there is `x.min`. Measure the physical distance and divide for `steps_per_mm`.
4. Repeat for Z upward.
5. Write both into `limits.json`. Nothing else reads those numbers from
   anywhere else.
