#!/usr/bin/env python3
"""A fake EiBotBoard on a virtual serial port, for testing without hardware.

    python3 web/simulate_jig.py
    # then, using the path it prints:
    UVJIG_EBB_PORT=/dev/pts/N python3 web/server.py

On Windows there is no pty; use the in-process simulator instead, which needs
no second process:  python web\\server.py --sim   (or UVJIG_EBB_PORT=sim).
The board model itself lives in tools/ebb_sim.py and is shared by both.

Useful for two things: exercising the web console end to end on a machine with
no jig attached, and reproducing protocol bugs without energising a motor. It
speaks enough of the EBB protocol for the console to be fully driveable -- V,
QS, QC, QM, SM, CS, ES, EM and the S2 RC-servo command.

Moves take real time, exactly as on the bench, so the timings the console shows
are honest rather than instant.

NOT a model of the machine: no slip, no stalling, no travel limits. It will
happily "move" somewhere the real jig cannot reach.
"""

import fcntl
import os
import pty
import sys
import threading
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
from ebb_sim import FakeEBB                                         # noqa: E402


def serve(name, device, eol):
    """Own the master side of a pty and answer whatever arrives on it."""
    master, slave = pty.openpty()
    path = os.ttyname(slave)
    print("  %-6s %s" % (name, path))
    sys.stdout.flush()

    def loop():
        buf = b""
        while True:
            try:
                data = os.read(master, 4096)
            except OSError:
                return
            if not data:
                return
            buf += data
            while True:
                i = min([j for j in (buf.find(b"\r"), buf.find(b"\n")) if j >= 0]
                        or [-1])
                if i < 0:
                    break
                line, buf = buf[:i], buf[i + 1:]
                reply = device.handle(line.decode("ascii", "replace"))
                if reply is not None:
                    os.write(master, (reply + eol).encode())

    def unlock():
        """Keep the slave openable even after a client dies holding it.

        serial_min sets TIOCEXCL so ModemManager cannot steal a real port. On a
        pty that backfires: this process keeps the slave fd open for the
        lifetime of the simulator, so the kernel never drops the exclusive flag
        when a crashed client's fd closes, and every later run gets EBUSY. A
        simulator has no ModemManager to defend against, so clear it.
        """
        while True:
            try:
                fcntl.ioctl(slave, 0x540D)          # TIOCNXCL
            except OSError:
                return
            time.sleep(1.0)

    threading.Thread(target=loop, daemon=True).start()
    threading.Thread(target=unlock, daemon=True).start()
    return path, slave


def main():
    print("=" * 62)
    print("UV jig SIMULATOR -- virtual EiBotBoard, no hardware")
    print("=" * 62)
    path, _keep = serve("EBB", FakeEBB(), "\r\n")
    print()
    print("Start the console against it with:")
    print()
    print("  UVJIG_EBB_PORT=%s python3 web/server.py" % path)
    print()
    print("Ctrl-C to stop.")
    sys.stdout.flush()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
