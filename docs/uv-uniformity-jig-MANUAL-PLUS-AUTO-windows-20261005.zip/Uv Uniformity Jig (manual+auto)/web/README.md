# Web console

A browser front end for the jig: connection indicators, origin recalibration, a
coverage tracker, and data entry that advances the jig to the next point the
moment you press Enter — plus, in this **manual + automatic** build, an **Auto**
mode that reads the StarBright meter over USB and scans a whole section by
itself (see *Auto mode* below).

```
python3 web/server.py          # or:  ./start-console.sh
```

It prints two URLs. The first works on the host itself; the second works from
**any other computer, tablet or phone on the same network**.

```
  this computer : http://localhost:8765/
  other devices : http://192.168.2.5:8765/
```

---

## Which computer needs what

| | Runs the server | Just views the page |
|---|---|---|
| Jig plugged in | **yes** | no |
| Python 3.8+ | **yes** | no |
| USB driver | **yes** | no |
| `pyserial` | Windows only | no |
| `openpyxl` | only for *Save to Excel* | no |

The browser talks HTTP and nothing else. The page has no external dependencies —
no CDN, no fonts, no network calls beyond this server.

---

## Using it

1. **Connect.** The pills go green: board, motor supply, servo. The
   motor-supply one is the one people miss — the board enumerates, accepts
   commands and counts steps perfectly happily with the external DC supply
   switched off, and the motors simply never turn. It reads the V+ rail so you
   find out in a second instead of ten minutes.
2. **Arm motion.** Nothing on the axes moves until you do — the same gate as
   `DO_MOVE=1` on the command line, and it clears itself if the board drops off.
   The servo is *not* gated: it has nothing to crash into.
3. **Type the reading, press Enter.** It is written to
   `scan/scan_readings.csv` and fsync'd before the response returns, then the
   jig drives itself to the next point and aims the servo. No saving, no Ctrl+S.
4. When a **MANUAL** phase starts, the page says so loudly — set the sensor by
   hand *once*, and the jig sweeps all 30 X/Z points of that phase. The prompt
   goes quiet after the first reading of the phase.
5. When a Y layer finishes, it tells you to move the jig by hand and pick the
   next layer.

Press **Escape** anywhere for an emergency stop.

### Which way is positive

The controls read in the **operator's frame**, not the board's:

| | means |
|---|---|
| X **+** | further **away** from the origin stop (0 → 150 mm) |
| X **−** | back **toward** the origin stop |
| Z **+** | up (0 → 300 mm) |
| X position **negative** | the carriage is **past** the origin stop |

Underneath, the board's counter runs the other way on X: away from the origin is
negative, `0 → −121600`. That machine convention is what `limits.json`, the
workbook and `scan_readings.csv` record, so the relabelling cannot affect a
measurement. The page maps between the two using `geometry.x_sign` from the
server rather than assuming a direction. The *Diagnostics* page and the activity
log report raw counter values.

### Coverage tracker

One tile per X/Z point of the current layer, highest Z at the top so it reads
like the physical box. Six squares per tile, one per face (F U B L D R): green
means measured, amber is where the jig is now. Click any square to drive there
and (re)measure it. Hover shows the row number and the recorded value.

### Origin and calibration

* **Home X into the hard stop** — drives `+X` until it stalls, then zeroes
  there. It skids for about two seconds; that contact *is* the datum.
* **Home blind (full travel)** — ignores the counter and drives the whole axis,
  so it arrives from anywhere. Use it whenever the counter has been zeroed
  somewhere other than the stop: ordinary Home X trusts the counter for the
  distance, so if the counter says "already at the stop" it barely moves.
* **Set origin here** — sends `CS`, which zeroes X *and* Z. The board has no
  per-axis clear, so only use it with both axes on their own origins. Homing is
  refused unless Z reads 0, for the same reason.
* **Ignore soft limits** — applies to jogs and homing. The limits bound the
  counter, and during recalibration the counter is the thing you are
  re-establishing, so it must not also be what authorises the move.

Everything here needs two clicks, and says so when it is armed.

### Servo

Driven by the board's own S2 output on RB1. Preset buttons come from the scan
plan, so they always match the directions the scan will record. An RC servo
reports no position, so the angle shown is the last one **commanded**.

**Output off** stops the pulse train and lets the horn go limp — do that if it
hums after arriving, since a servo held against a limit draws stall current.

### Auto mode — StarBright over USB, and the auto scan

The header has a **Manual / Auto** toggle. The console starts in Manual and
remembers the last choice (`web/console_settings.json`).

**Manual** is the original workflow above. Nothing to do with the meter is
touched — not imported, not probed — so on a computer without the meter or its
driver this build behaves exactly like the manual-only one.

**Auto** shows the *Auto scan* card:

* **Meter.** Choose the *Connection* — **RS‑232** (the meter's serial lead into
  any COM port or USB‑serial adapter; no Ophir driver, no admin, works on
  Linux too), **USB** (needs Ophir's WinUSB driver, bundled in
  `docs/starbright/driver/`), or *Auto* (USB if the driver is there, else
  RS‑232). Leave the port blank to auto-detect: every serial port except the
  board's is probed with a harmless `$VE` at the common baud rates; *Ports*
  lists them. *Connect meter* then shows instrument, sensor, firmware, units,
  the wavelength (pick a favourite from the λ list) and which route is in use.
  The live value turns green when it is *settled*. If the meter is not found
  the card says so; nothing else changes.
* **Capture.** With the meter connected you can still step point by point:
  the usual Enter box works, and *Capture* records the meter's settled value
  instead of you typing it.
* **Auto scan.** Pick a section — **BACK / UP / FRONT / DOWN** (servo-aimed),
  **RIGHT** or **LEFT** (aimed by hand once) — and press *Start*.
  Each section is run separately and covers all three X layers, skipping points
  already measured unless *re‑measure* is ticked. The scan then drives itself:
  move → aim → mechanical settle → wait for a settled reading → log → next.
  It **pauses and tells you** exactly when a person is needed:
  * *Move the jig by hand to X = 85 mm, then Continue* — at every layer change.
  * *Point the sensor RIGHT, then Continue* — once, at the start of a hand-aimed
    section. For LEFT it also reminds you to turn the jig round; the carriage
    targets are already mirrored.
  * *The reading did not settle* — *Try again*, *Skip point* or *Stop*.
  *Pause* finishes the current point and holds; *Continue* resumes; *Stop* or
  **Escape** end it. While a scan runs, manual entry, jogging and the other
  motion buttons are refused until you pause or stop it.
* **Settling rules** (under the card): *N* samples within *tol* %, a minimum
  dwell after arrival, and a give-up time. Arrival discards everything sampled
  before it, so a value from the previous point can never be recorded at the
  new one. The recorded value is the mean of the agreeing samples, to the
  meter's own four significant figures. Dark readings use an absolute floor.

Everything logged by the auto scan goes into the same `scan/scan_readings.csv`,
same columns, so the coverage tracker, Excel export and analysis do not care
which mode took a reading.

### Reading the meter automatically (StarLab autolog)

If the meter's own software is logging to a file on the same machine — StarLab
on Windows does this — the console can take each value instead of you typing it.
*Machine → Meter log*: tick it on, give the log's path, and optionally tick
**Capture automatically**.

The whole difficulty is **staleness**, and it is handled explicitly. Tailing a
log naively records whatever was last written, which at the moment the jig
arrives is still the *previous* point's reading — a real-looking number filed
against the wrong coordinate, invisible afterwards. So arriving at a point
stamps the file's current length, and **only lines written after that are
eligible**. Nothing from before the jig got there can ever be captured.

A value is taken only once several consecutive samples agree (3 within 2% by
default), so a reading caught mid-settle is not recorded. Until then the panel
says "still moving". **Re‑arm** discards what has been collected at the current
point and waits for fresh samples.

The format is not assumed. The last number on each line is used by default, the
field is selectable, and the **raw line is displayed beside the parsed value** so
a wrong column shows up immediately rather than being recorded silently. Typing
a value by hand always still works and overrides the meter.

### Data

Readings live in `scan/scan_readings.csv`, appended and flushed one at a time.
The spreadsheet is written only when you press **Save to Excel**, so you can
leave `uv_scan.xlsx` open while you work. If the sheet on disk was built for a
different grid it is archived and rebuilt rather than merged into — a stale
sheet has the right row *numbers* but the wrong point behind each one.

**Clear all readings** starts over; the old log and workbook move into
`scan/archive/` with a timestamp first. **Diagnostics** opens a plain-text
summary — build, connection, counters, limits and the activity log — to copy and
send on when something is wrong.

---

## Testing without hardware

```
python web/server.py --sim          # any platform: fake board AND fake meter, in-process
```

`--sim` runs the whole console — Auto mode and the auto scan included — against
a simulated EiBotBoard (`tools/ebb_sim.py`) and a simulated meter whose reading
varies with position and rings for a second after every move, so the settle
logic has something real to wait for. Moves take real time so the timings are
honest. It models no slip, no stalling and no travel limits.

On Linux the older external simulator still works too:

```
python3 web/simulate_jig.py        # prints a virtual port path
UVJIG_EBB_PORT=/dev/pts/9 python3 web/server.py
```

---

## Options

| | |
|---|---|
| `--port 8765` | listening port |
| `--host 0.0.0.0` | bind address; `127.0.0.1` stays on this machine |
| `--token SECRET` | require `?k=SECRET` on every request |
| `--no-connect` | start without opening the serial port |
| `--mode manual` / `--mode auto` | start in this mode (otherwise the last one used) |
| `--sim` | no hardware: simulated board and meter |

With no token, anyone who can reach the port can drive the jig. On a shared
network use `--token`, or bind to `127.0.0.1`.

## Why it is built this way

**One thread owns the serial port.** HTTP requests only enqueue jobs and read a
cached snapshot. That is not tidiness: the board generates step pulses from a
timer interrupt on a PIC, and USB traffic arriving mid-move competes with it.
Polling at 20 Hz during a move produced audible stutter and lost steps, while a
script that sends the move and then stays quiet runs smoothly. So the worker
goes silent for the duration of every move and the browser polls a snapshot
instead of the hardware.

**The grid is defined once**, in [`scan/scan_plan.py`](../scan/scan_plan.py).
The workbook generator and this server both import it, so they cannot disagree
about which row is which. Readings logged against an older grid are detected and
ignored rather than believed — they stay in the CSV, they just are not counted.

**The build number is in the header.** If you replace files and the header does
not change, you are still talking to the old server — usually because a previous
console is still running and holding the port. The launchers refuse to start in
that case rather than leaving you on a stale one.
