#!/usr/bin/env python3
"""UV Uniformity Jig -- web control console.

Run this on the computer the jig is plugged into:

    python3 web/server.py

then open the URL it prints. The page works from ANY computer on the same
network -- phone, laptop, whatever -- because the browser only speaks HTTP. Only
this host needs the USB device, the driver and Python.

    python3 web/server.py --port 8765 --host 0.0.0.0
    python3 web/server.py --token secret     # require ?k=secret

--------------------------------------------------------------------- design --

**One board, one port, one thread.** All three motors hang off a single
EiBotBoard: X on axis 1, Z on axis 2, and the sensor servo on RB1 via the S2
RC-servo output. Every HTTP request does nothing but drop a job on a queue and
read a state snapshot; the worker thread is the only code that ever touches the
serial port. That is not tidiness -- the EBB generates step pulses from a timer
interrupt on a PIC, and USB traffic arriving mid-move competes with it. Polling
this jig at 20 Hz during a move produced audible stutter and lost steps, while a
script that sends the move and then shuts up runs smoothly. So the worker goes
silent for the duration of every move and the browser polls a cached snapshot
rather than the hardware.

**The CSV is the record, not the spreadsheet.** Every reading is appended to
scan/scan_readings.csv and fsync'd before the HTTP response returns, so a crash,
a closed laptop or a browser refresh can never cost a measurement. The workbook
is written only when you ask for it, which also means it can stay open in Excel.

**Motion is gated.** DO_MOVE=1 on the command line becomes an Arm toggle here.
Nothing moves until it is on, it clears itself on disconnect, and the E-stop
works whether or not it is set. The servo is not gated: it is a small positioner
with nothing to crash into.

**Two modes: Manual and Auto.** This is the MANUAL + AUTOMATIC build of the
console. In Manual mode it behaves exactly like the manual-only build: you type
each reading. In Auto mode the Ophir StarBright meter is read over USB
(tools/starbright.py) and an *auto scan* drives a whole phase by itself: move,
aim, wait for a settled reading, log it, next point -- pausing only for the
things a person must do (move the X layer by hand, re-aim the sensor for the
RIGHT / LEFT passes -- DOWN is reached by the 270-degree servo since
2026-10-05). Nothing to do with the meter is touched in Manual
mode, so a computer without the meter or its driver never sees an error from it.
"""

import argparse
import csv
import json
import os
import queue
import re
import socket
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "scan"))

from serial_min import (Serial, SerialError, lines, resolve_port,   # noqa: E402
                        describe_ports)
import ebb                                                          # noqa: E402
import scan_plan                                                    # noqa: E402

BUILD = "2026-10-05.1 manual+auto, 270-deg servo"

# --sim: fake board AND fake meter, in-process, any platform. Must be decided
# before the controller is created below, because it resolves the port then.
if "--sim" in sys.argv:
    os.environ.setdefault("UVJIG_EBB_PORT", "sim")
    os.environ.setdefault("UVJIG_METER", "sim")

SETTINGS_PATH = os.path.join(HERE, "console_settings.json")   # mode + meter tuning
MODES = ("manual", "auto")

CSV_PATH = os.path.join(ROOT, "scan", "scan_readings.csv")
WORKBOOK = os.path.join(ROOT, "scan", "uv_scan.xlsx")
ARCHIVE = os.path.join(ROOT, "scan", "archive")
INDEX_HTML = os.path.join(HERE, "index.html")

# Schema corrected 2026-08-31: X is the hand-moved layer axis, Y and Z are
# driven. The old files called the driven horizontal axis "x".
CSV_HEADER = ["utc", "row", "id", "phase", "x_idx", "y_idx", "z_idx",
              "x_mm", "y_mm", "z_mm", "y_steps", "z_steps",
              "direction", "servo_deg", "reading"]

# Mechanical settle after the axes stop, before a reading is trusted. Adjustable
# at runtime (/api/settle) because it is a real trade-off: too short and the
# reading is taken while the frame is still ringing, too long and it is dead time
# multiplied by 540. Lowered from 1.0 s once the servo wait was overlapped with it.
SETTLE_S = 0.6
SETTLE_MIN, SETTLE_MAX = 0.0, 3.0
IDLE_POLL_S = 2.0         # how often to refresh position/rail when not moving
MANUAL_PARK_ANGLE = 90    # neutral servo pose (UP) during the manual phases


class AutoLog(object):
    """Read measurements out of a meter's own log file instead of typing them.

    Ophir's StarLab (Windows) can log continuously to a text/CSV file. Point
    this at that file and the console takes the reading itself.

    The whole difficulty is STALENESS. Naively tailing the file records whatever
    was last written, which at the moment the jig arrives is still the PREVIOUS
    point's reading -- an error that lands a real-looking number on the wrong
    coordinate and is invisible afterwards. So arrival stamps the file's current
    length, and only lines appended AFTER that are eligible. Nothing is ever
    captured from before the jig got there.

    The format is not assumed: the last number on a line is taken by default,
    the field is configurable, and the raw line is reported alongside the parsed
    value so a mis-parse is visible immediately rather than silently recorded.
    """

    NUM = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")

    def __init__(self):
        self.path = ""
        self.enabled = False
        self.field = -1            # index into the numbers on a line; -1 = last
        self.auto = False          # capture without a keypress once stable
        self.stable_n = 3          # samples that must agree
        self.tol = 0.02            # fractional agreement required
        self.baseline = None       # file length when the jig arrived
        self.samples = []          # [(monotonic, value, raw)] since arrival
        self.error = ""
        self.lock = threading.Lock()

    def configure(self, **kw):
        with self.lock:
            for k in ("path", "enabled", "auto"):
                if k in kw and kw[k] is not None:
                    setattr(self, k, kw[k])
            if kw.get("field") is not None:
                self.field = int(kw["field"])
            if kw.get("stable_n"):
                self.stable_n = max(1, min(20, int(kw["stable_n"])))
            if kw.get("tol") is not None:
                self.tol = max(0.0, min(0.5, float(kw["tol"])))
            self.baseline = None
            self.samples = []
            self.error = ""

    def mark_arrival(self):
        """Called the moment the jig settles at a point: everything already in
        the file belongs to a previous position."""
        with self.lock:
            self.samples = []
            try:
                self.baseline = os.path.getsize(self.path) if self.path else None
                self.error = ""
            except OSError as e:
                self.baseline = None
                self.error = str(e)

    def _parse(self, line):
        nums = self.NUM.findall(line)
        if not nums:
            return None
        try:
            return float(nums[self.field])
        except (IndexError, ValueError):
            return None

    def poll(self):
        """Read whatever has been appended since arrival. File I/O only."""
        if not (self.enabled and self.path):
            return
        with self.lock:
            try:
                size = os.path.getsize(self.path)
            except OSError as e:
                self.error = str(e)
                return
            if self.baseline is None:
                self.baseline = size
                return
            if size < self.baseline:        # log rotated or restarted
                self.baseline = 0
            if size == self.baseline:
                return
            try:
                with open(self.path, "rb") as fh:
                    fh.seek(self.baseline)
                    chunk = fh.read(size - self.baseline)
                self.baseline = size
                self.error = ""
            except OSError as e:
                self.error = str(e)
                return
            # StarLab has been seen writing UTF-16 as well as plain text.
            for enc in ("utf-8", "utf-16", "cp1252"):
                try:
                    text = chunk.decode(enc)
                    break
                except (UnicodeDecodeError, LookupError):
                    text = chunk.decode("utf-8", "replace")
            now = time.monotonic()
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                v = self._parse(line)
                if v is not None:
                    self.samples.append((now, v, line[:120]))
            del self.samples[:-40]

    def state(self):
        with self.lock:
            recent = self.samples[-self.stable_n:]
            stable = False
            if len(recent) >= self.stable_n:
                vals = [v for _, v, _ in recent]
                span = max(vals) - min(vals)
                ref = max(1e-9, abs(sum(vals) / len(vals)))
                stable = (span / ref) <= self.tol
            last = self.samples[-1] if self.samples else None
            return {
                "enabled": self.enabled, "path": self.path, "auto": self.auto,
                "field": self.field, "stable_n": self.stable_n, "tol": self.tol,
                "armed": self.baseline is not None,
                "n": len(self.samples),
                "value": None if last is None else round(last[1], 4),
                "raw": None if last is None else last[2],
                "stable": stable,
                "error": self.error,
            }


class MeterError(Exception):
    """The meter is not there, or stopped answering."""


class MeterTimeout(Exception):
    """A reading did not settle in time."""


class Meter(object):
    """The Ophir StarBright over USB, polled continuously in its own thread.

    Nothing here runs in Manual mode: the driver module is imported lazily in
    connect(), so on a computer without the meter -- or without Windows and its
    WinUSB driver -- Manual mode never touches it and never sees an error.

    Settling is judged the same way AutoLog does it, and for the same reason:
    a reading taken while the frame is still ringing, or while the meter's own
    averaging is catching up after the servo swung, is a reading of the
    transient, not the field. So arrival at a point discards everything sampled
    before it, a minimum dwell is enforced, and then the last `stable_n` samples
    must agree within `tol` (relative) or `abs_floor` (absolute, for dark
    readings where a percentage of nothing is nothing).
    """

    POLL_S = 0.2                    # ~5 Hz; the meter itself updates at a few Hz

    def __init__(self):
        self.lock = threading.Lock()        # protects the fields below
        self.io = threading.Lock()          # serialises USB access to the device
        self.dev = None
        self.thread = None
        self.stop = threading.Event()
        self.kind = ""                      # what was actually opened: usb | serial | sim
        # How to reach the meter. "auto" = USB if Ophir's driver is there,
        # otherwise RS-232; "usb"; "serial" (+ optional port); "sim".
        self.source = "auto"
        self.port = ""                      # RS-232 port, blank = auto-detect
        self.exclude_ports = ()             # the EiBotBoard's port, never probed
        self.info = {}
        self.units = ""
        self.unit_name = ""
        self.wavelength = None
        self.wavelengths = []               # favourites the meter offers
        self.error = ""
        self.samples = []                   # [(monotonic, value)] since arrival
        self.arrived = None
        self.last = None                    # (monotonic, value), newest sample
        self.fail_streak = 0
        # tuning -- adjustable from the console
        self.stable_n = 5
        self.tol = 0.02
        self.abs_floor = 1e-6
        self.min_dwell_s = 1.0
        self.timeout_s = 20.0

    # -- config --------------------------------------------------------------
    def configure(self, **kw):
        with self.lock:
            if kw.get("stable_n") is not None:
                self.stable_n = max(2, min(40, int(kw["stable_n"])))
            if kw.get("tol") is not None:
                self.tol = max(0.0, min(0.5, float(kw["tol"])))
            if kw.get("abs_floor") is not None:
                self.abs_floor = max(0.0, float(kw["abs_floor"]))
            if kw.get("min_dwell_s") is not None:
                self.min_dwell_s = max(0.0, min(10.0, float(kw["min_dwell_s"])))
            if kw.get("timeout_s") is not None:
                self.timeout_s = max(2.0, min(300.0, float(kw["timeout_s"])))
            if kw.get("source") is not None:
                s = str(kw["source"]).lower().strip()
                if s in ("auto", "usb", "serial", "sim"):
                    self.source = s
            if kw.get("port") is not None:
                self.port = str(kw["port"]).strip()

    def settings(self):
        with self.lock:
            return {"stable_n": self.stable_n, "tol": self.tol,
                    "abs_floor": self.abs_floor, "min_dwell_s": self.min_dwell_s,
                    "timeout_s": self.timeout_s,
                    "source": self.source, "port": self.port}

    # -- lifecycle -----------------------------------------------------------
    def connected(self):
        return self.dev is not None

    def connect(self, kind=None):
        """Open the meter and start polling. Returns True on success; on
        failure the reason is in self.error and nothing is raised."""
        with self.lock:
            if self.dev is not None:
                return True
            env = (os.environ.get("UVJIG_METER") or "").strip()
            # --sim / UVJIG_METER=sim wins; otherwise the console's own setting.
            want = env if env.lower().startswith("sim") else (kind or self.source)
            if want == "serial" and self.port:
                want = "serial:" + self.port
            port = self.port or None
            exclude = tuple(self.exclude_ports)
        try:
            import starbright                       # lazy: WinUSB via ctypes
            dev = starbright.open_meter(want, port=port, exclude_ports=exclude)
            info = dev.identify()
            units = dev.query("SI")
            wl = dev.wavelength_nm()
            favs = []
            aw = info.get("wavelengths", "").split()
            if aw and aw[0] == "CONTINUOUS":
                favs = [int(x) for x in aw[4:] if x.isdigit()]
        except Exception as e:                      # noqa: BLE001
            with self.lock:
                self.error = str(e) or e.__class__.__name__
            return False
        with self.lock:
            self.dev = dev
            self.kind = getattr(dev, "transport", "") or "usb"
            self.info = info
            self.units = units
            self.unit_name = {"w": "W/cm²", "W": "W", "j": "J/cm²", "J": "J",
                              "d": "dBm", "X": "(passive)"}.get(units, units)
            self.wavelength = wl
            self.wavelengths = favs
            self.error = ""
            self.samples = []
            self.last = None
            self.fail_streak = 0
            self.stop.clear()
            self.thread = threading.Thread(target=self._poll, daemon=True)
            self.thread.start()
        return True

    def disconnect(self):
        self.stop.set()
        t = self.thread
        if t and t is not threading.current_thread():
            t.join(2.0)
        with self.lock:
            dev, self.dev, self.thread = self.dev, None, None
            self.samples = []
            self.last = None
        if dev is not None:
            with self.io:
                try:
                    dev.close()
                except Exception:                           # noqa: BLE001
                    pass

    def _poll(self):
        while not self.stop.is_set():
            dev = self.dev
            if dev is None:
                return
            try:
                with self.io:
                    v = dev.power()
                now = time.monotonic()
                with self.lock:
                    self.samples.append((now, v))
                    del self.samples[:-400]
                    self.last = (now, v)
                    self.fail_streak = 0
                    self.error = ""
            except Exception as e:                          # noqa: BLE001
                with self.lock:
                    self.fail_streak += 1
                    self.error = "meter: %s" % e
                    lost = self.fail_streak >= 5
                if lost:
                    self.disconnect()
                    with self.lock:
                        self.error = "lost the meter: %s" % e
                    return
            self.stop.wait(self.POLL_S)

    def set_wavelength(self, nm):
        dev = self.dev
        if dev is None:
            raise MeterError("the meter is not connected")
        with self.io:
            dev.set_wavelength(int(nm))
            wl = dev.wavelength_nm()
        with self.lock:
            self.wavelength = wl
        self.mark_arrival()
        return wl

    # -- settling ------------------------------------------------------------
    def mark_arrival(self):
        """The jig has just arrived at a point: forget everything sampled before."""
        with self.lock:
            self.samples = []
            self.arrived = time.monotonic()

    def _judge(self):
        """(stable, value, n, span_fraction, dwell_ok) under self.lock."""
        recent = self.samples[-self.stable_n:]
        n = len(self.samples)
        dwell_ok = (self.arrived is None
                    or time.monotonic() - self.arrived >= self.min_dwell_s)
        if len(recent) < self.stable_n:
            return False, None, n, None, dwell_ok
        vals = [v for _, v in recent]
        mean = sum(vals) / len(vals)
        span = max(vals) - min(vals)
        ref = max(abs(mean), 1e-30)
        allowed = max(self.tol * abs(mean), self.abs_floor)
        stable = span <= allowed and dwell_ok
        return stable, mean, n, span / ref, dwell_ok

    def wait_settled(self, abort, timeout=None, cancelled=None):
        """Block until the reading settles. Returns (value_str, n, span_pct).

        Raises Aborted if the E-stop fires or `cancelled()` turns true,
        MeterTimeout if it never settles, MeterError if the meter goes away.
        """
        deadline = time.monotonic() + (timeout or self.timeout_s)
        while True:
            if abort.is_set() or (cancelled and cancelled()):
                raise Aborted()
            if self.dev is None:
                raise MeterError(self.error or "the meter is not connected")
            with self.lock:
                stable, mean, n, span, _ = self._judge()
            if stable:
                return "%.4g" % mean, n, round(100.0 * span, 2)
            if time.monotonic() > deadline:
                raise MeterTimeout(
                    "%d samples, last %d span %.1f%% (limit %.1f%%)"
                    % (n, self.stable_n, 100.0 * (span or 0), 100.0 * self.tol))
            time.sleep(0.05)

    def state(self):
        with self.lock:
            stable, mean, n, span, dwell_ok = self._judge()
            last = self.last
            fresh = last is not None and time.monotonic() - last[0] < 2.0
            dev = self.dev
            return {
                "connected": dev is not None,
                "kind": self.kind,                       # transport in use
                "source": self.source, "port": self.port,
                "path": (getattr(dev, "path", "") or "") if dev is not None else "",
                "baud": getattr(dev, "baud", None) if dev is not None else None,
                "error": self.error,
                "name": self.info.get("instrument", ""),
                "sensor": self.info.get("head", ""),
                "firmware": self.info.get("firmware", ""),
                "units": self.units, "unit_name": self.unit_name,
                "wavelength": self.wavelength, "wavelengths": self.wavelengths,
                "value": None if last is None else last[1],
                "fresh": fresh,
                "n": n, "stable": stable, "dwell_ok": dwell_ok,
                "stable_value": None if mean is None else "%.4g" % mean,
                "span_pct": None if span is None else round(100.0 * span, 2),
                "stable_n": self.stable_n, "tol": self.tol,
                "abs_floor": self.abs_floor, "min_dwell_s": self.min_dwell_s,
                "timeout_s": self.timeout_s,
            }


class Aborted(Exception):
    """Raised inside the worker when the E-stop fires mid-move."""


def now_utc():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def lan_ip():
    """Best guess at the address other machines should use. No traffic sent."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def as_number(v):
    s = str(v).strip()
    for cast in (int, float):
        try:
            return cast(s)
        except ValueError:
            pass
    return s


# -------------------------------------------------------------- controller ---
class Controller(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self, daemon=True)
        self.jobs = queue.Queue()
        self.lock = threading.RLock()

        self.rows = scan_plan.plan()
        self.by_row = {r["row"]: r for r in self.rows}
        self.limits = ebb.load_limits()

        self.port = None
        self.board = {"connected": False, "port": resolve_port(),
                      "firmware": "", "vplus": None, "supply_ok": False,
                      "error": ""}
        # The servo shares the board, so it has no connection of its own. What
        # is worth reporting is the last angle COMMANDED -- an RC servo has no
        # feedback path, so this is a record of intent, not a measurement.
        self.servo = {"angle": None, "us": None, "driven": False,
                      "pin": "RB1 (RP%d)" % ebb.SERVO_PIN}

        self.pos = (0, 0)
        self.armed = False
        self.busy = False
        self.busy_what = ""
        self.busy_eta = 0.0
        self.abort = threading.Event()
        self.last_poll = 0.0
        self.stale_csv = 0

        self.layer = 1
        self.cursor = 0
        self.readings = {}
        self.log_ring = []
        self.last_error = None
        self.autolog = AutoLog()
        self.settle_s = SETTLE_S
        self.mode = "manual"
        self.meter = Meter()
        self.auto = self._auto_idle()
        self.load_settings()
        self.load_readings()
        self.cursor = self.first_unread(self.layer)

    # -- settings (mode + meter tuning survive a restart) ---------------------
    def load_settings(self):
        try:
            with open(SETTINGS_PATH) as fh:
                d = json.load(fh)
        except (OSError, ValueError):
            return
        if d.get("mode") in MODES:
            self.mode = d["mode"]
        self.meter.configure(**(d.get("meter") or {}))
        try:
            v = float(d.get("settle_s"))
            self.settle_s = max(SETTLE_MIN, min(SETTLE_MAX, v))
        except (TypeError, ValueError):
            pass

    def save_settings(self):
        try:
            with open(SETTINGS_PATH, "w") as fh:
                json.dump({"mode": self.mode, "meter": self.meter.settings(),
                           "settle_s": self.settle_s}, fh, indent=2)
        except OSError as e:
            self.log("could not save settings: %s" % e, "warn")

    def set_mode(self, mode):
        if mode not in MODES:
            raise ValueError("mode must be one of %s" % ", ".join(MODES))
        if mode == self.mode:
            return
        if mode == "manual":
            self.auto_stop("switched to Manual mode")
            self.meter.disconnect()
        self.mode = mode
        self.save_settings()
        self.log("mode: %s" % ("AUTO -- meter and auto scan available" if mode == "auto"
                               else "MANUAL -- readings are typed in"), "warn")

    # -- log ---------------------------------------------------------------
    def log(self, msg, level="info"):
        with self.lock:
            self.log_ring.append({"t": time.strftime("%H:%M:%S"),
                                  "level": level, "msg": msg})
            del self.log_ring[:-200]
            if level == "error":
                # Worker failures must not land only in the activity list: a
                # refused move there looks exactly like a dead button.
                self.last_error = {"msg": msg, "t": time.time()}
        line = "[%s] %s" % (level.upper(), msg)
        try:
            print(line)
        except UnicodeEncodeError:
            # A console code page without ° or ² must not take the server down.
            print(line.encode("ascii", "replace").decode("ascii"))
        sys.stdout.flush()

    # -- readings ----------------------------------------------------------
    def load_readings(self):
        """Read the CSV back in, discarding entries that do not match the plan.

        Row numbers alone are not enough to trust a historical reading: the grid
        has been reshaped before, and a CSV written against an older layout
        would silently attach an old value to a different physical point. Each
        entry is checked against the plan row it claims; a mismatch is counted
        and dropped rather than believed.
        """
        self.readings = {}
        self.stale_csv = 0
        if not os.path.exists(CSV_PATH):
            return
        try:
            with open(CSV_PATH, newline="") as fh:
                for rec in csv.DictReader(fh):
                    try:
                        row = int(rec["row"])
                    except (TypeError, ValueError, KeyError):
                        continue
                    plan_row = self.by_row.get(row)
                    if plan_row is None or not self._matches(plan_row, rec):
                        self.stale_csv += 1
                        continue
                    self.readings[row] = {"value": rec.get("reading", ""),
                                          "utc": rec.get("utc", "")}
        except OSError as e:
            self.log("could not read %s: %s" % (CSV_PATH, e), "error")

    @staticmethod
    def _matches(plan_row, rec):
        try:
            if str(rec.get("direction", "")).strip() != plan_row["dir"]:
                return False
            if int(float(rec.get("y_idx", rec.get("y", -1)))) != plan_row["y"]:
                return False
            if int(float(rec.get("x_idx", -1))) != plan_row["x"]:
                return False
            if abs(float(rec.get("z_mm", -1)) - plan_row["zmm"]) > 0.05:
                return False
        except (TypeError, ValueError):
            return False
        return True

    def record(self, row, value):
        """Append a reading and fsync it. Called from the HTTP thread: file I/O
        only, no serial, so the UI stays responsive."""
        r = self.by_row[row]
        new = not os.path.exists(CSV_PATH)
        with self.lock:
            with open(CSV_PATH, "a", newline="") as fh:
                w = csv.writer(fh)
                if new:
                    w.writerow(CSV_HEADER)
                w.writerow([now_utc(), r["row"], r["id"], r["phase"], r["x"],
                            r["y"], r["z"], r["xmm"], r["ymm"], r["zmm"],
                            r["ysteps"], r["zsteps"], r["dir"],
                            "" if r["angle"] is None else r["angle"], value])
                fh.flush()
                os.fsync(fh.fileno())
            self.readings[row] = {"value": value, "utc": now_utc()}
        self.log("row %d  %s  %s = %s" % (row, r["phase"], r["dir"], value))

    # -- cursor ------------------------------------------------------------
    def layer_rows(self, x):
        """Rows of one X layer -- X is the axis moved by hand between passes."""
        return [i for i, r in enumerate(self.rows) if r["x"] == x]

    def first_unread(self, x):
        for i in self.layer_rows(x):
            if self.rows[i]["row"] not in self.readings:
                return i
        idx = self.layer_rows(x)
        return idx[-1] if idx else 0

    def advance(self):
        """Next unmeasured point in this layer, searching forward then wrapping."""
        idx = self.layer_rows(self.layer)
        if not idx:
            return False
        pos = idx.index(self.cursor) if self.cursor in idx else -1
        for i in idx[pos + 1:] + idx[:pos + 1]:
            if self.rows[i]["row"] not in self.readings:
                self.cursor = i
                return True
        return False        # layer complete

    def step_cursor(self, delta):
        idx = self.layer_rows(self.layer)
        if not idx:
            return
        pos = idx.index(self.cursor) if self.cursor in idx else 0
        self.cursor = idx[max(0, min(len(idx) - 1, pos + delta))]

    # -- serial: ONLY the worker thread may call these ---------------------
    def _qs(self):
        p = ebb.read_position(self.port)
        if p:
            self.pos = p
        return p

    def _refresh(self):
        """Position and motor-rail check. Never called during a move."""
        if not self.port:
            return
        try:
            self._qs()
            counts = ebb.read_vplus(self.port)
            with self.lock:
                self.board["vplus"] = counts
                self.board["supply_ok"] = ebb.supply_present(counts)
        except SerialError as e:
            self._drop("lost the board: %s" % e)
        self.last_poll = time.monotonic()

    def _drop(self, why):
        self.log(why, "error")
        try:
            self.port.close()
        except Exception:                                   # noqa: BLE001
            pass
        with self.lock:
            self.port = None
            self.board.update(connected=False, error=why, vplus=None,
                              supply_ok=False)
            self.armed = False

    def _sleep_move(self, seconds):
        """Wait out a move in silence, but stay interruptible.

        No serial traffic here on purpose. Slicing the sleep only touches an
        in-process Event, which costs the step generator nothing.
        """
        end = time.monotonic() + seconds
        with self.lock:
            self.busy_eta = end
        while time.monotonic() < end:
            if self.abort.is_set():
                raise Aborted()
            time.sleep(0.05)
        with self.lock:
            self.busy_eta = 0.0

    def _move_axis(self, axis, delta, rate, force=False):
        """force=True skips the soft-limit check.

        Required for homing, which drives deliberately PAST the limit into the
        mechanical stop. The check exists to catch sign errors during normal
        work; during a recalibration the counter it checks against is exactly
        the thing not to be trusted.
        """
        if delta == 0:
            return
        dy, dz = (delta, 0) if axis == "Y" else (0, delta)
        bad = [] if force else ebb.check_limits(self.limits, self.pos, dy, dz)
        if bad:
            raise SerialError("soft limit: " + "; ".join(bad))
        for cy, cz, cd in ebb.split_move(dy, dz, rate):
            if self.abort.is_set():
                raise Aborted()
            ebb.send_move(self.port, cy, cz, cd)
            self._sleep_move(ebb.move_duration_s(cd))

    def _goto_steps(self, ty, tz, settle=True):
        pos = self._qs()
        if pos is None:
            raise SerialError("could not read the step position")
        moved = []
        for axis, target, cur, rate in (("Y", ty, pos[0], ebb.Y_RATE_HZ),
                                        ("Z", tz, pos[1], ebb.Z_RATE_HZ)):
            delta = target - cur
            if delta:
                moved.append("%s %+d" % (axis, delta))
                self._move_axis(axis, delta, rate)
        if moved and settle:
            time.sleep(self.settle_s)
        if moved:
            self._qs()
        return moved

    def _servo_to(self, angle, settle=None):
        """Command the horn. settle=None waits for the travel from the last
        commanded angle (the whole range if that is unknown); 0 returns at
        once, for a caller that overlaps the wait with something else."""
        if settle is None:
            settle = ebb.servo_travel_s(self._servo_known_angle(), angle)
        us = ebb.servo_set_angle(self.port, angle, settle=settle)
        with self.lock:
            self.servo.update(angle=int(angle), us=us, driven=True)
        return us

    def _servo_known_angle(self):
        """The last angle commanded, or None if the horn could be anywhere
        (never commanded, or the output has been switched off since)."""
        return self.servo.get("angle") if self.servo.get("driven") else None

    # -- jobs --------------------------------------------------------------
    def submit(self, kind, **kw):
        kw["kind"] = kind
        self.jobs.put(kw)

    def run(self):
        while True:
            try:
                job = self.jobs.get(timeout=0.5)
            except queue.Empty:
                if (self.port and not self.busy
                        and time.monotonic() - self.last_poll > IDLE_POLL_S):
                    self._refresh()
                continue
            with self.lock:
                self.busy = True
                self.busy_what = job.get("label", job["kind"])
            try:
                self._dispatch(job)
            except Aborted:
                self.log("motion aborted (E-stop or Stop)", "warn")
                self._resync()
            except SerialError as e:
                self.log(str(e), "error")
            except Exception as e:                          # noqa: BLE001
                self.log("%s: %s" % (job["kind"], e), "error")
                traceback.print_exc()
            finally:
                self.abort.clear()
                with self.lock:
                    self.busy = False
                    self.busy_what = ""
                    self.busy_eta = 0.0
                self.jobs.task_done()

    def _resync(self):
        """After an abort the reply stream may be mid-message. Realign before
        believing any query -- a stale reply read as a position is worse than no
        position at all."""
        if not self.port:
            return
        try:
            if self.port.sync() is None:
                self._drop("could not resynchronise with the board")
            else:
                self._refresh()
        except SerialError as e:
            self._drop("resync failed: %s" % e)

    def _dispatch(self, job):
        kind = job["kind"]
        if kind == "connect":
            self._do_connect()
        elif kind == "disconnect":
            self._do_disconnect()
        elif kind == "refresh":
            self._refresh()
        elif kind == "goto_cursor":
            self._do_goto_cursor()
        elif kind == "jog":
            self._do_jog(job)
        elif kind == "home_x":
            self._do_home_x(job.get("blind_rev"), job.get("force"))
        elif kind == "zero":
            self._do_zero()
        elif kind == "servo":
            self._servo_to(job["angle"])
            self.log("servo -> %d deg" % job["angle"])
        elif kind == "servo_off":
            ebb.servo_off(self.port)
            with self.lock:
                self.servo["driven"] = False
            self.log("servo output off -- horn is limp")
        elif kind == "park":
            moved = self._goto_steps(0, 0)
            self.log("parked at origin: %s" % (", ".join(moved) or "already there"))
        elif kind == "auto_point":
            self._do_auto_point()
        else:
            self.log("unknown job %r" % kind, "error")

    # -- auto scan -----------------------------------------------------------
    # One phase at a time: AUTO (the servo aims BACK/UP/FRONT/DOWN itself), or
    # one of the hand-aimed faces RIGHT / LEFT. Every point is its own
    # worker job, so between points the worker is free and a pause is simply
    # "the next job has not been queued". The plan order is followed exactly;
    # points already measured are skipped unless `redo` was asked for.
    @staticmethod
    def _auto_idle():
        return {"active": False, "phase": None, "state": "idle", "reason": "",
                "prompt": "", "pending": [], "total": 0, "done": 0, "skipped": 0,
                "unsettled": 0, "current": None, "started": None, "finished": None,
                "last": None, "layer_ok": None, "await_layer": None,
                "orient_ok": False, "point_times": [], "redo": False,
                "pause_requested": False, "message": ""}

    def auto_start(self, phase, redo=False):
        """Called from the HTTP thread. Validates and queues the first point."""
        if phase not in scan_plan.PHASES:
            raise ValueError("phase must be one of %s" % ", ".join(scan_plan.PHASES))
        with self.lock:
            if self.auto["active"]:
                raise ValueError("an auto scan is already running -- Stop it first")
            pending = [i for i, r in enumerate(self.rows)
                       if r["phase"] == phase and (redo or r["row"] not in self.readings)]
            a = self._auto_idle()
            a.update(active=True, phase=phase, state="starting", pending=pending,
                     total=len(pending), started=time.time(), redo=bool(redo))
            self.auto = a
        if not pending:
            with self.lock:
                self.auto.update(active=False, state="done", finished=time.time(),
                                 message="nothing left to measure in %s" % phase)
            self.log("auto scan %s: every point is already measured" % phase, "warn")
            return
        self.log("AUTO SCAN %s: %d point%s to measure%s"
                 % (phase, len(pending), "" if len(pending) == 1 else "s",
                    " (re-measuring)" if redo else ""), "warn")
        self._auto_next()

    def _auto_next(self):
        """Decide the next step: queue a point, pause for the operator, or finish.
        Safe from either thread; it only mutates state and enqueues."""
        with self.lock:
            a = self.auto
            if not a["active"]:
                return
            if a["pause_requested"]:
                a["pause_requested"] = False
                a.update(state="paused", reason="user",
                         prompt="Paused. Press Continue to carry on from row %d."
                                % (self.rows[a["pending"][0]]["row"] if a["pending"] else 0))
                self.log("auto scan paused", "warn")
                return
            if not a["pending"]:
                a.update(active=False, state="done", finished=time.time(),
                         current=None, message="%s complete: %d measured, %d skipped"
                         % (a["phase"], a["done"], a["skipped"]))
                self.log("AUTO SCAN %s finished: %d measured, %d skipped, %.0f s"
                         % (a["phase"], a["done"], a["skipped"],
                            time.time() - (a["started"] or time.time())), "warn")
                return
            i = a["pending"][0]
            r = self.rows[i]
            self.layer = r["x"]
            self.cursor = i
            if a["layer_ok"] != r["x"]:
                a.update(state="paused", reason="layer", await_layer=r["x"],
                         prompt="Move the jig by hand to X = %g mm (layer %d of %d), "
                                "then press Continue." % (r["xmm"], r["x"], scan_plan.X_COUNT))
                self.log("auto scan: waiting for X layer %d (%g mm) to be set by hand"
                         % (r["x"], r["xmm"]), "warn")
                return
            if r["method"] == "MANUAL" and not a["orient_ok"]:
                msg = ("Point the sensor %s by hand, then press Continue. It stays "
                       "that way for all %d points of this phase." % (r["dir"], a["total"]))
                if r.get("reversed"):
                    msg = ("This is the reversed pass: turn the whole jig round 180° "
                           "from the RIGHT setup, point the sensor LEFT, then press "
                           "Continue. The carriage positions are mirrored for you.")
                a.update(state="paused", reason="orient", prompt=msg)
                self.log("auto scan: waiting for the sensor to be aimed %s" % r["dir"], "warn")
                return
            a.update(state="moving", current=i, reason="", prompt="")
            a["_t0"] = time.monotonic()
        self.submit("auto_point", label="auto scan: row %d %s" % (r["row"], r["dir"]))

    def _do_auto_point(self):
        """Worker: move to the current point, wait for a settled reading, log it."""
        with self.lock:
            a = self.auto
            if not a["active"] or a["current"] is None:
                return
            i = a["current"]
        r = self.rows[i]
        self.cursor = i
        try:
            self._do_goto_cursor()
            with self.lock:
                if not a["active"]:         # Stop arrived during the move
                    raise Aborted()
                a["state"] = "settling"
            value, n, span = self.meter.wait_settled(
                self.abort, cancelled=lambda: not a["active"])
        except MeterTimeout as e:
            with self.lock:
                a["unsettled"] += 1
                a.update(state="paused", reason="unsettled",
                         prompt="The reading at row %d (%s) did not settle within "
                                "%.0f s: %s. Continue tries again, Skip moves on."
                                % (r["row"], r["dir"], self.meter.timeout_s, e))
            self.log("auto scan: row %d did not settle (%s)" % (r["row"], e), "warn")
            return
        except MeterError as e:
            with self.lock:
                a.update(state="paused", reason="meter",
                         prompt="Lost the meter: %s. Reconnect it in the Auto scan "
                                "panel and press Continue, or Stop." % e)
            self.log("auto scan: %s" % e, "error")
            return
        except Aborted:
            with self.lock:
                if a["active"]:             # a Stop button already labelled itself
                    a.update(active=False, state="stopped", reason="estop",
                             finished=time.time(), message="stopped by E-stop")
                elif a["state"] not in ("stopped", "done"):
                    a["state"] = "stopped"
            if self.abort.is_set():
                raise                       # a real E-stop: let run() resync
            self.log("auto scan: stopped cleanly between points")
            return
        except SerialError as e:
            # The board refused or vanished. Leave the scan resumable rather
            # than stranded: Continue retries this point once it is fixed.
            with self.lock:
                a.update(state="paused", reason="board",
                         prompt="The board refused row %d: %s. Fix it, then press "
                                "Continue to retry, Skip to move on, or Stop." % (r["row"], e))
            self.log("auto scan: %s" % e, "error")
            return
        self.record(r["row"], value)
        with self.lock:
            if a["pending"] and a["pending"][0] == i:
                a["pending"].pop(0)
            a["done"] += 1
            a["last"] = {"row": r["row"], "dir": r["dir"], "xmm": r["xmm"],
                         "ymm": r["ymm"], "zmm": round(r["zmm"], 2),
                         "value": value, "n": n, "span_pct": span}
            t0 = a.pop("_t0", None)
            if t0:
                a["point_times"].append(time.monotonic() - t0)
                del a["point_times"][:-30]
            a["state"] = "advancing"
        self._auto_next()

    def auto_pause(self):
        with self.lock:
            a = self.auto
            if not a["active"]:
                return "no auto scan is running"
            if a["state"] == "paused":
                return "already paused"
            a["pause_requested"] = True
        return "pausing after this point"

    def auto_continue(self):
        with self.lock:
            a = self.auto
            if not a["active"]:
                return "no auto scan is running"
            if a["state"] != "paused":
                return "not paused"
            if a["reason"] == "layer":
                a["layer_ok"] = a["await_layer"]
                self.log("auto scan: X layer %d confirmed" % a["await_layer"])
            elif a["reason"] == "orient":
                a["orient_ok"] = True
                self.log("auto scan: sensor orientation confirmed")
            elif a["reason"] == "meter" and not self.meter.connected():
                return "the meter is still not connected"
            a.update(state="resuming", reason="", prompt="")
        self._auto_next()
        return "continuing"

    def auto_skip(self):
        with self.lock:
            a = self.auto
            if not a["active"]:
                return "no auto scan is running"
            if a["state"] != "paused":
                return "pause first, then skip"
            if a["pending"]:
                r = self.rows[a["pending"].pop(0)]
                a["skipped"] += 1
                self.log("auto scan: skipped row %d %s" % (r["row"], r["dir"]), "warn")
            a.update(state="resuming", reason="", prompt="")
        self._auto_next()
        return "skipped"

    def auto_stop(self, why="stopped by the operator"):
        with self.lock:
            a = self.auto
            if not a["active"]:
                return "no auto scan is running"
            moving = a["state"] == "moving"
            a.update(active=False, state="stopped", finished=time.time(),
                     reason="", prompt="", message=why)
        if moving:
            # The worker is asleep inside this point's move; only the abort
            # event gets it out (a settle wait watches `active` by itself).
            # It is cleared again when the job ends.
            self.abort.set()
        self.log("AUTO SCAN %s: %s (%d measured, %d skipped)"
                 % (a["phase"], why, a["done"], a["skipped"]), "warn")
        return "stopped"

    def auto_state(self):
        with self.lock:
            a = self.auto
            times = a["point_times"]
            per = (sum(times) / len(times)) if times else None
            remaining = len(a["pending"])
            cur = self.rows[a["current"]] if a["current"] is not None else None
            return {
                "active": a["active"], "phase": a["phase"], "state": a["state"],
                "reason": a["reason"], "prompt": a["prompt"], "message": a["message"],
                "total": a["total"], "done": a["done"], "skipped": a["skipped"],
                "remaining": remaining, "unsettled": a["unsettled"],
                "started": a["started"], "finished": a["finished"],
                "per_point_s": None if per is None else round(per, 1),
                "eta_s": None if per is None else round(per * remaining),
                "current": None if cur is None else {
                    "row": cur["row"], "dir": cur["dir"], "x": cur["x"],
                    "xmm": cur["xmm"], "ymm": cur["ymm"], "zmm": round(cur["zmm"], 2)},
                "last": a["last"],
                "await_layer": a["await_layer"],
            }

    # -- job bodies --------------------------------------------------------
    def _do_connect(self):
        if self.port:
            return
        try:
            p = Serial(self.board["port"])
        except SerialError as e:
            with self.lock:
                self.board.update(connected=False, error=str(e))
            self.log("board: %s" % e, "error")
            return
        banner = p.sync()
        if banner is None:
            p.close()
            with self.lock:
                self.board.update(
                    connected=False,
                    error="no EBB banner -- wrong device on this port?")
            self.log("board did not answer V with a banner", "error")
            return
        self.port = p
        fw = (lines(banner) or [""])[0]
        with self.lock:
            self.board.update(connected=True, firmware=fw, error="")
        self.log("connected: %s" % fw)
        self._refresh()

    def _do_disconnect(self):
        if self.port:
            try:
                self.port.close()
            except Exception:                               # noqa: BLE001
                pass
        self.port = None
        with self.lock:
            self.board.update(connected=False, vplus=None, supply_ok=False)
            self.armed = False
        self.log("disconnected")

    def _do_goto_cursor(self):
        r = self.rows[self.cursor]
        # The settle is deferred: the servo command goes out the moment the axes
        # stop -- the board's step generator is idle by then, so it cannot cause
        # stutter -- and then ONE wait covers both the frame settling and the horn
        # travelling. Doing them in sequence wasted most of a second per point.
        moved = self._goto_steps(r["ysteps"], r["zsteps"], settle=False)
        want = None
        known = self._servo_known_angle()
        if r["method"] == "SERVO":
            # The plan alternates the face order point to point, so about one
            # row in four finds the horn already on the right face. Skip the
            # command then: it would only cost a serial round trip.
            if known != r["angle"]:
                want = r["angle"]
        elif known != MANUAL_PARK_ANGLE:
            # Park the horn neutral so it is out of the way while the sensor is
            # repositioned by hand.
            want = MANUAL_PARK_ANGLE
        servo_wait = 0.0
        if want is not None:
            # Sized to the swing: 90 deg between neighbouring faces is quick,
            # the full 270 from an unknown start is not.
            servo_wait = ebb.servo_travel_s(known, want)
            self._servo_to(want, settle=0)
        wait = max(self.settle_s if moved else 0.0, servo_wait)
        if wait:
            time.sleep(wait)
        if moved:
            self._qs()
        # Everything already in the meter's log belongs to the previous point.
        self.autolog.mark_arrival()
        self.meter.mark_arrival()
        self.log("at row %d  X=%.0f Y=%.0f Z=%.0f  %s%s"
                 % (r["row"], r["xmm"], r["ymm"], r["zmm"], r["dir"],
                    "" if moved else "  (no move needed)"))

    def _do_jog(self, job):
        axis = job["axis"].upper()
        rate = float(job.get("rate") or (ebb.Y_RATE_HZ if axis == "Y"
                                         else ebb.Z_RATE_HZ))
        self._qs()
        self._move_axis(axis, int(job["steps"]), rate, force=bool(job.get("force")))
        time.sleep(0.3)
        self._qs()
        self.log("jog %s %+d steps -> %s" % (axis, int(job["steps"]), (self.pos,)))

    def _do_home_x(self, blind_rev=None, force=False):
        """Drive +X into the hard stop, then zero both counters there."""
        pos = self._qs()
        # Authoritative Z check, made here rather than when the request was
        # queued: self.pos can be stale while other jobs are pending, and a
        # guard that reads a stale zero is no guard at all.
        if pos is not None and pos[1] != 0 and not force:
            raise SerialError(
                "Z is at %d, not 0. Homing ends in CS, which zeroes both "
                "counters, so Z's origin would be destroyed too. Put Z on its "
                "bottom stop first, or tick “Ignore soft limits”." % pos[1])

        plan, revs = ebb.home_plan(self.limits, pos, blind_rev=blind_rev)
        if revs is not None:
            self.log("homing X BLIND: %.1f rev, counter ignored. It will skid "
                     "from whenever it arrives." % revs, "warn")
        else:
            to_stop = ((self.limits or {}).get("y") or {}).get("max", 0) - pos[0]
            self.log("homing X: counter %d, %d steps to the stop" % (pos[0], to_stop))
            if to_stop < (self.limits or {}).get("steps_per_rev", 3200):
                self.log("counter says X is already at the stop, so this move is "
                         "tiny. If the carriage is not physically against the "
                         "stop, use Home blind instead.", "warn")
        total = sum(abs(st) / r for st, r, _ in plan)
        self.log("homing X: ~%.0f s, ending with a deliberate skid" % total)
        for steps, rate, label in plan:
            self._move_axis("X", steps, rate, force=True)

        time.sleep(0.5)
        ebb.zero_counters(self.port)
        time.sleep(0.2)
        self._qs()
        self.log("X homed against the stop; both counters zeroed -- position %s"
                 % (self.pos,))

    def _do_zero(self):
        ebb.zero_counters(self.port)
        time.sleep(0.2)
        self._qs()
        self.log("counters zeroed here -- this point is now the origin", "warn")

    # -- E-stop: the one thing an HTTP thread may send ---------------------
    def emergency_stop(self):
        """Send ES immediately, from whichever thread asked.

        Deliberately not queued: the worker is asleep inside a move when this
        matters, so a queued stop would arrive after the move it was meant to
        cut short. The worker resyncs afterwards, so a garbled reply costs
        nothing.
        """
        self.abort.set()
        if self.auto["active"]:
            self.auto_stop("stopped by E-stop")
        p = self.port
        if not p:
            return "not connected"
        try:
            ebb.emergency_stop(p)
        except SerialError as e:
            return str(e)
        self.log("E-STOP sent", "warn")
        return "sent"

    # -- snapshot ----------------------------------------------------------
    def snapshot(self):
        self.autolog.poll()          # cheap file tail; deliberately not under
        with self.lock:              # self.lock, and never touches the port
            r = self.rows[self.cursor] if self.rows else None
            layer_idx = self.layer_rows(self.layer)
            layer_done = sum(1 for i in layer_idx
                             if self.rows[i]["row"] in self.readings)
            phases = []
            for ph in scan_plan.PHASES:
                ids = [i for i in layer_idx if self.rows[i]["phase"] == ph]
                done = sum(1 for i in ids if self.rows[i]["row"] in self.readings)
                phases.append({"phase": ph, "done": done, "total": len(ids)})

            layers = []
            for x in range(1, scan_plan.X_COUNT + 1):
                ids = self.layer_rows(x)
                layers.append({"x": x, "mm": scan_plan.X_MM[x - 1],
                               "total": len(ids),
                               "done": sum(1 for i in ids
                                           if self.rows[i]["row"] in self.readings)})

            eta = max(0.0, self.busy_eta - time.monotonic()) if self.busy_eta else 0.0
            yspm = scan_plan.Y_STEPS_PER_MM
            zspm = scan_plan.Z_STEPS_PER_MM
            return {
                "ok": True,
                "build": BUILD,
                "ts": time.time(),
                "armed": self.armed,
                # Queued counts as busy. Between the POST that enqueues a move
                # and the worker picking it up, self.busy is still False, and a
                # client that believed it would accept a reading for a point the
                # jig has not reached.
                "busy": self.busy or not self.jobs.empty(),
                "busy_what": self.busy_what,
                "busy_eta": round(eta, 1),
                "queued": self.jobs.qsize(),
                "board": dict(self.board),
                "servo": dict(self.servo),
                "pos": {"y_steps": self.pos[0], "z_steps": self.pos[1],
                        # Operator frame: 0 at the origin stop, increasing as
                        # you travel away from it. Negative means "past the
                        # stop", which is worth seeing rather than hiding.
                        "y_mm": round(self.pos[0] * scan_plan.Y_SIGN / float(yspm), 2),
                        "z_mm": round(self.pos[1] / float(zspm), 2)},
                "layer": self.layer,
                "layer_complete": bool(layer_idx) and layer_done == len(layer_idx),
                "layer_mm": scan_plan.X_MM[self.layer - 1],
                "cursor": self._cursor_payload(r),
                "counts": {"total": len(self.rows), "done": len(self.readings),
                           "layer_total": len(layer_idx), "layer_done": layer_done,
                           "phases": phases, "layers": layers},
                "grid": self._grid_payload(),
                "recent": self._recent_payload(),
                "log": self.log_ring[-40:],
                "last_error": self.last_error,
                "autolog": self.autolog.state(),
                "settle_s": self.settle_s,
                "stale_csv": self.stale_csv,
                "mode": self.mode,
                # In Manual mode the meter is never touched, so report only
                # that it is switched off rather than probing for it.
                "meter": (self.meter.state() if self.mode == "auto"
                          else {"connected": False, "off": True}),
                "auto": self.auto_state(),
                "phases_all": [
                    {"phase": ph,
                     "done": sum(1 for r in self.rows if r["phase"] == ph
                                 and r["row"] in self.readings),
                     "total": sum(1 for r in self.rows if r["phase"] == ph),
                     "dir": (" / ".join(d for d, _ in scan_plan.SERVO) if ph == "AUTO"
                             else ph.split("-", 1)[1]),
                     "method": ("SERVO" if ph == "AUTO" else "MANUAL"),
                     "reversed": ph in scan_plan.REVERSED_PHASES}
                    for ph in scan_plan.PHASES],
                "geometry": {
                    "x_mm": scan_plan.X_MM,          # hand-moved layers
                    "y_mm": scan_plan.Y_MM,          # driven
                    "z_mm": [round(v, 2) for v in scan_plan.z_positions()],
                    "x_count": scan_plan.X_COUNT,
                    "directions": scan_plan.DIRECTIONS,
                    "servo": [{"dir": d, "angle": a} for d, a in scan_plan.SERVO],
                    "servo_max_deg": ebb.SERVO_MAX_DEG,
                    "servo_park_deg": MANUAL_PARK_ANGLE,
                    "manual": list(scan_plan.MANUAL_ORDER),
                    "y_steps_per_mm": yspm, "z_steps_per_mm": zspm,
                    # Machine sign for one unit of operator-positive travel.
                    # The UI maps with this rather than assuming a direction.
                    "y_sign": scan_plan.Y_SIGN, "z_sign": scan_plan.Z_SIGN,
                },
            }

    def _cursor_payload(self, r):
        if r is None:
            return None
        idx = self.layer_rows(self.layer)
        return {
            "index": self.cursor,
            "n": (idx.index(self.cursor) + 1) if self.cursor in idx else 0,
            "of": len(idx),
            "row": r["row"], "id": r["id"], "phase": r["phase"],
            "x": r["x"], "y": r["y"], "z": r["z"],
            "xmm": r["xmm"], "ymm": r["ymm"], "zmm": round(r["zmm"], 2),
            "ysteps": r["ysteps"], "zsteps": r["zsteps"],
            "dir": r["dir"], "method": r["method"], "angle": r["angle"],
            "reversed": bool(r.get("reversed")),
            "value": (self.readings.get(r["row"]) or {}).get("value"),
            # True while nothing in this phase has been measured yet, i.e. the
            # sensor still needs repositioning. That is done ONCE per phase, so
            # the loud prompt must stop after the first reading lands.
            "phase_first": not any(
                self.rows[i]["row"] in self.readings
                for i in self.layer_rows(self.layer)
                if self.rows[i]["phase"] == r["phase"]),
        }

    def _grid_payload(self):
        """Per Y/Z point of the current X layer: which of the six faces are done."""
        cells = {}
        for i in self.layer_rows(self.layer):
            r = self.rows[i]
            key = "%d,%d" % (r["y"], r["z"])
            cell = cells.setdefault(key, {"y": r["y"], "z": r["z"], "ymm": r["ymm"],
                                          "zmm": round(r["zmm"], 2), "dirs": {}})
            got = self.readings.get(r["row"])
            cell["dirs"][r["dir"]] = {"row": r["row"], "index": i,
                                      "value": got["value"] if got else None,
                                      "current": (i == self.cursor)}
        return list(cells.values())

    def _recent_payload(self):
        out = []
        for row in sorted(self.readings, reverse=True)[:14]:
            r = self.by_row.get(row)
            if not r:
                continue
            got = self.readings[row]
            out.append({"row": row, "phase": r["phase"], "x": r["x"],
                        "ymm": r["ymm"], "zmm": round(r["zmm"], 2),
                        "dir": r["dir"], "value": got["value"], "utc": got["utc"],
                        "index": row - scan_plan.FIRST_DATA_ROW})
        return out


CTL = Controller()
TOKEN = None


# ------------------------------------------------------------------ routes ---
class Handler(BaseHTTPRequestHandler):
    server_version = "UVJig/2.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        pass                        # the controller's own log is the useful one

    # -- plumbing ----------------------------------------------------------
    def _cors(self):
        # Permissive on purpose: a copy of index.html opened straight off a USB
        # stick on another machine is a file:// origin and should still work.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj))

    def _fail(self, msg, code=400):
        self._json({"ok": False, "error": msg}, code)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except ValueError:
            return {}

    def _authed(self):
        if TOKEN is None:
            return True
        from urllib.parse import urlparse, parse_qs
        q = parse_qs(urlparse(self.path).query)
        return (q.get("k") or [None])[0] == TOKEN

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    # -- GET ---------------------------------------------------------------
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if not self._authed():
            return self._fail("bad or missing token", 403)

        if path in ("/", "/index.html"):
            try:
                with open(INDEX_HTML, "rb") as fh:
                    return self._send(200, fh.read(), "text/html; charset=utf-8")
            except OSError as e:
                return self._send(500, "cannot read index.html: %s" % e, "text/plain")
        if path == "/api/state":
            return self._json(CTL.snapshot())
        if path == "/api/ports":
            return self._json({"ok": True, "ports": describe_ports()})
        if path == "/api/meter/ports":
            # Serial ports the RS-232 meter could be on: everything except the
            # EiBotBoard's. Auto mode only, like the rest of /api/meter/.
            if CTL.mode != "auto":
                return self._fail("switch the console to Auto mode first")
            try:
                import starbright
                ports = [{"device": d, "description": desc,
                          "usb": ("%04x:%04x" % (vid, pid)) if vid else ""}
                         for d, desc, vid, pid in starbright.list_serial_ports()]
                return self._json({"ok": True, "ports": ports, "ebb": CTL.board["port"]})
            except Exception as e:                          # noqa: BLE001
                return self._json({"ok": True, "ports": [], "error": str(e)})
        if path == "/api/diag":
            return self._send(200, diagnostics(), "text/plain; charset=utf-8")
        if path == "/api/readings.csv":
            try:
                with open(CSV_PATH, "rb") as fh:
                    data = fh.read()
            except OSError:
                data = (",".join(CSV_HEADER) + "\n").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/csv")
            self.send_header("Content-Disposition",
                             'attachment; filename="scan_readings.csv"')
            self.send_header("Content-Length", str(len(data)))
            self._cors()
            self.end_headers()
            return self.wfile.write(data)
        return self._fail("no such path: %s" % path, 404)

    # -- POST --------------------------------------------------------------
    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if not self._authed():
            return self._fail("bad or missing token", 403)
        body = self._body()

        # E-stop first, and never gated on anything.
        if path == "/api/estop":
            return self._json({"ok": True, "result": CTL.emergency_stop()})

        if path == "/api/connect":
            CTL.submit("connect", label="connecting")
            return self._json({"ok": True})
        if path == "/api/disconnect":
            CTL.submit("disconnect", label="disconnecting")
            return self._json({"ok": True})
        if path == "/api/refresh":
            CTL.submit("refresh", label="reading position")
            return self._json({"ok": True})
        if path == "/api/arm":
            want = bool(body.get("armed"))
            if want and not CTL.board["connected"]:
                return self._fail("cannot arm: the board is not connected")
            CTL.armed = want
            CTL.log("motion %s" % ("ARMED" if want else "disarmed"), "warn")
            return self._json({"ok": True, "armed": CTL.armed})

        if path == "/api/layer":
            x = int(body.get("x") or body.get("y") or 1)
            if x not in range(1, scan_plan.X_COUNT + 1):
                return self._fail("x must be 1..%d" % scan_plan.X_COUNT)
            CTL.layer = x
            CTL.cursor = CTL.first_unread(x)
            CTL.log("switched to X layer %d (%g mm)" % (x, scan_plan.X_MM[x - 1]))
            return self._json({"ok": True})

        if path == "/api/autolog":
            CTL.autolog.configure(
                path=body.get("path"), enabled=body.get("enabled"),
                auto=body.get("auto"), field=body.get("field"),
                stable_n=body.get("stable_n"), tol=body.get("tol"))
            CTL.log("meter log: %s" % ("watching " + CTL.autolog.path
                                       if CTL.autolog.enabled else "off"))
            return self._json({"ok": True, "autolog": CTL.autolog.state()})

        if path == "/api/autolog/rearm":
            # Discard everything captured at this point and wait for fresh
            # samples -- for when the meter was still settling.
            CTL.autolog.mark_arrival()
            return self._json({"ok": True})

        if path == "/api/settle":
            try:
                v = float(body.get("seconds"))
            except (TypeError, ValueError):
                return self._fail("seconds required")
            CTL.settle_s = max(SETTLE_MIN, min(SETTLE_MAX, v))
            CTL.save_settings()
            CTL.log("settle time set to %.2f s" % CTL.settle_s, "warn")
            return self._json({"ok": True, "settle_s": CTL.settle_s})

        # ---- mode ----------------------------------------------------------
        if path == "/api/mode":
            try:
                CTL.set_mode(str(body.get("mode") or "").lower())
            except ValueError as e:
                return self._fail(str(e))
            if CTL.mode == "auto" and not CTL.meter.connected():
                # Best effort, and quiet: a missing meter is reported in the
                # panel, not thrown at the operator as an error.
                CTL.meter.connect()
            return self._json({"ok": True, "mode": CTL.mode})

        # ---- meter: Auto mode only -----------------------------------------
        if path.startswith("/api/meter/") or path.startswith("/api/auto/"):
            if CTL.mode != "auto":
                return self._fail("switch the console to Auto mode first")

        if path == "/api/meter/connect":
            CTL.meter.exclude_ports = (CTL.board["port"],)      # never probe the EBB
            ok = CTL.meter.connect()
            if ok:
                m = CTL.meter.state()
                CTL.log("meter: %s | %s | %s nm | %s  via %s%s"
                        % (m["name"], m["sensor"].strip(), m["wavelength"], m["unit_name"],
                           {"usb": "USB (Ophir driver)", "serial": "RS-232", "sim": "simulator"}
                           .get(m["kind"], m["kind"]),
                           (" on %s @ %s baud" % (m["path"], m["baud"])) if m["kind"] == "serial" else ""))
            else:
                CTL.log("meter: %s" % CTL.meter.error, "warn")
            return self._json({"ok": ok, "error": None if ok else CTL.meter.error,
                               "meter": CTL.meter.state()})
        if path == "/api/meter/disconnect":
            if CTL.auto["active"]:
                return self._fail("an auto scan is running -- Stop it first")
            CTL.meter.disconnect()
            CTL.log("meter disconnected")
            return self._json({"ok": True})
        if path == "/api/meter/config":
            if (body.get("source") is not None or body.get("port") is not None) \
                    and CTL.auto["active"]:
                return self._fail("an auto scan is running -- Stop it before changing "
                                  "the meter connection")
            CTL.meter.configure(
                stable_n=body.get("stable_n"), tol=body.get("tol"),
                abs_floor=body.get("abs_floor"), min_dwell_s=body.get("min_dwell_s"),
                timeout_s=body.get("timeout_s"),
                source=body.get("source"), port=body.get("port"))
            CTL.save_settings()
            return self._json({"ok": True, "meter": CTL.meter.state()})
        if path == "/api/meter/rearm":
            CTL.meter.mark_arrival()
            return self._json({"ok": True})
        if path == "/api/meter/wavelength":
            if CTL.auto["active"]:
                return self._fail("an auto scan is running -- Stop it first")
            try:
                wl = CTL.meter.set_wavelength(int(body.get("nm")))
            except (TypeError, ValueError):
                return self._fail("nm required")
            except Exception as e:                          # noqa: BLE001
                return self._fail("could not set the wavelength: %s" % e)
            CTL.log("meter wavelength -> %s nm" % wl, "warn")
            return self._json({"ok": True, "wavelength": wl})

        # ---- auto scan -----------------------------------------------------
        if path == "/api/auto/start":
            if not CTL.board["connected"]:
                return self._fail("the board is not connected")
            if not CTL.armed:
                return self._fail("motion is not armed -- turn on Arm first")
            if not CTL.meter.connected():
                return self._fail("the meter is not connected -- connect it in the "
                                  "Auto scan panel (%s)" % (CTL.meter.error or "not found"))
            try:
                CTL.auto_start(str(body.get("phase") or ""), bool(body.get("redo")))
            except ValueError as e:
                return self._fail(str(e))
            return self._json({"ok": True, "auto": CTL.auto_state()})
        if path == "/api/auto/pause":
            return self._json({"ok": True, "result": CTL.auto_pause()})
        if path == "/api/auto/continue":
            r = CTL.auto_continue()
            if r in ("the meter is still not connected",):
                return self._fail(r)
            return self._json({"ok": True, "result": r})
        if path == "/api/auto/skip":
            return self._json({"ok": True, "result": CTL.auto_skip()})
        if path == "/api/auto/stop":
            return self._json({"ok": True, "result": CTL.auto_stop()})

        if path == "/api/reload":
            CTL.load_readings()
            CTL.cursor = CTL.first_unread(CTL.layer)
            return self._json({"ok": True, "done": len(CTL.readings)})

        # ---- everything below moves an axis ------------------------------
        need_motion = path in ("/api/reading", "/api/jog", "/api/home",
                               "/api/zero", "/api/goto", "/api/nav",
                               "/api/park", "/api/skip")
        if need_motion and not CTL.armed:
            return self._fail("motion is not armed -- turn on Arm first")
        if need_motion and not CTL.board["connected"]:
            return self._fail("the board is not connected")
        if need_motion and CTL.auto["active"]:
            return self._fail("an auto scan is running -- Pause or Stop it first")

        if path == "/api/reading":
            value = body.get("value")
            if value is None or str(value).strip() == "":
                return self._fail("empty reading")
            row = int(body.get("row") or CTL.rows[CTL.cursor]["row"])
            CTL.record(row, str(value).strip())
            if CTL.advance():
                CTL.submit("goto_cursor", label="moving to the next point")
            else:
                CTL.log("Y layer %d is complete" % CTL.layer, "warn")
            return self._json({"ok": True, "recorded": row})

        if path == "/api/skip":
            CTL.advance()
            CTL.submit("goto_cursor", label="moving")
            return self._json({"ok": True})

        if path == "/api/nav":
            CTL.step_cursor(int(body.get("delta") or 0))
            CTL.submit("goto_cursor", label="moving")
            return self._json({"ok": True})

        if path == "/api/goto":
            idx = body.get("index")
            if idx is None:
                return self._fail("index required")
            idx = int(idx)
            if not 0 <= idx < len(CTL.rows):
                return self._fail("index out of range")
            CTL.layer = CTL.rows[idx]["y"]
            CTL.cursor = idx
            CTL.submit("goto_cursor", label="moving")
            return self._json({"ok": True})

        if path == "/api/jog":
            axis = str(body.get("axis") or "").upper()
            if axis == "X":
                return self._fail("X is the hand-moved layer axis -- it has no "
                                  "motor. The driven axes are Y and Z.")
            if axis not in ("Y", "Z"):
                return self._fail("axis must be Y or Z")
            steps = body.get("steps")
            if steps is None and body.get("rev") is not None:
                # 1/16 microstepping: 3200 steps per revolution on both axes.
                # Rotations are exact; mm depend on a steps/mm figure that is
                # still only estimated.
                per_rev = (CTL.limits or {}).get("steps_per_rev", 3200)
                steps = int(round(float(body["rev"]) * per_rev))
            if steps is None:
                mm = float(body.get("mm") or 0)
                spm = (scan_plan.Y_STEPS_PER_MM if axis == "Y"
                       else scan_plan.Z_STEPS_PER_MM)
                steps = int(round(mm * spm))
            steps = int(steps)
            if steps == 0:
                return self._fail("zero-length jog")
            force = bool(body.get("force"))
            if not force:
                # Check here as well as in the worker: the worker's rejection
                # only reaches the activity log, which reads as "nothing
                # happened". Returning it from the POST puts the reason on screen.
                dy, dz = (steps, 0) if axis == "Y" else (0, steps)
                bad = ebb.check_limits(CTL.limits, CTL.pos, dy, dz)
                if bad:
                    return self._fail(
                        "; ".join(bad) + ". If you are recalibrating, tick "
                        "“Ignore soft limits” — the counter is what "
                        "you are re-establishing, so it cannot also be the thing "
                        "that authorises the move.")
            CTL.submit("jog", axis=axis, steps=steps, rate=body.get("rate"),
                       force=force,
                       label="jogging %s %+d%s" % (axis, steps,
                                                   " (unrestricted)" if force else ""))
            return self._json({"ok": True, "steps": steps})

        if path == "/api/home":
            if CTL.pos[1] != 0 and not body.get("force"):
                return self._fail(
                    "Z is at %d, not 0. Homing ends in CS, which zeroes BOTH "
                    "counters -- put Z on its bottom origin first, or its frame "
                    "is destroyed too. Tick “Ignore soft limits” to home "
                    "anyway and re-establish Z separately." % CTL.pos[1])
            blind = body.get("blind_rev")
            # 0 means "blind, you pick the distance". Test against None: 0 is
            # falsy and would silently select the counter-based path, which is
            # the one blind mode exists to avoid.
            blind = None if blind is None else float(blind)
            CTL.submit("home_x", blind_rev=blind, force=bool(body.get("force")),
                       label="homing X into the hard stop")
            return self._json({"ok": True})

        if path == "/api/zero":
            if str(body.get("confirm")) != "yes":
                return self._fail("confirmation required")
            CTL.submit("zero", label="zeroing counters")
            return self._json({"ok": True})

        if path == "/api/park":
            CTL.submit("park", label="parking at origin")
            return self._json({"ok": True})

        # ---- servo: nothing to crash into, so no arm gate ----------------
        if path == "/api/servo":
            if not CTL.board["connected"]:
                return self._fail("the board is not connected")
            angle = int(body.get("angle"))
            if not 0 <= angle <= ebb.SERVO_MAX_DEG:
                return self._fail("angle must be 0..%g" % ebb.SERVO_MAX_DEG)
            CTL.submit("servo", angle=angle, label="servo to %d deg" % angle)
            return self._json({"ok": True})
        if path == "/api/servo/off":
            if not CTL.board["connected"]:
                return self._fail("the board is not connected")
            CTL.submit("servo_off", label="switching the servo output off")
            return self._json({"ok": True})

        # ---- data --------------------------------------------------------
        if path == "/api/reset":
            if str(body.get("confirm")) != "yes":
                return self._fail("confirmation required")
            return self._json(reset_readings())
        if path == "/api/merge":
            return self._json(merge_to_workbook())
        if path == "/api/regen":
            return self._json(regen_workbook())

        return self._fail("no such path: %s" % path, 404)


# ------------------------------------------------------------------- data ---
def reset_readings():
    """Archive the readings log and start a clean one.

    Archives rather than deletes: a scan is hours of work and a mis-click must
    not be able to destroy it.
    """
    os.makedirs(ARCHIVE, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    moved = []
    if os.path.exists(CSV_PATH) and os.path.getsize(CSV_PATH) > 0:
        dest = os.path.join(ARCHIVE, "%s-scan_readings.csv" % stamp)
        os.rename(CSV_PATH, dest)
        moved.append(os.path.basename(dest))
    with open(CSV_PATH, "w", newline="") as fh:
        csv.writer(fh).writerow(CSV_HEADER)
        fh.flush()
        os.fsync(fh.fileno())
    made = regen_workbook()
    if made.get("ok"):
        moved.append(os.path.basename(made["path"]) + " (rebuilt)")
    CTL.load_readings()
    CTL.cursor = CTL.first_unread(CTL.layer)
    CTL.log("readings cleared; previous log archived as %s"
            % (moved[0] if moved else "(nothing to archive)"), "warn")
    return {"ok": True, "archived": moved, "readings": len(CTL.readings)}


def diagnostics():
    """One copy-pasteable block describing what the jig is actually doing."""
    s = CTL.snapshot()
    out = []
    A = out.append
    A("UV JIG DIAGNOSTICS")
    A("build          : %s" % s["build"])
    A("python         : %s" % sys.version.split()[0])
    A("platform       : %s" % sys.platform)
    A("armed          : %s" % s["armed"])
    A("busy           : %s  %s" % (s["busy"], s["busy_what"]))
    A("queued jobs    : %s" % s["queued"])
    A("mode           : %s" % s["mode"])
    m = s["meter"]
    if m.get("off"):
        A("meter          : off (Manual mode)")
    else:
        A("meter          : %s%s  [connection: %s%s%s]"
          % ("connected" if m["connected"] else "not connected",
             ("  " + m["error"]) if m.get("error") else "",
             m.get("source"), (" port " + m["port"]) if m.get("port") else "",
             (" -> %s %s" % (m.get("kind"), m.get("path"))) if m["connected"] else ""))
        A("meter ident    : %s | %s | fw %s | %s nm | %s"
          % (m.get("name"), m.get("sensor"), m.get("firmware"),
             m.get("wavelength"), m.get("unit_name")))
        A("meter settle   : %s samples within %.1f%% (floor %g), dwell %.1f s, timeout %.0f s"
          % (m.get("stable_n"), 100 * (m.get("tol") or 0), m.get("abs_floor"),
             m.get("min_dwell_s") or 0, m.get("timeout_s") or 0))
    au = s["auto"]
    A("auto scan      : %s %s %s  %d/%d done, %d skipped, %d unsettled"
      % (au["phase"] or "-", au["state"], au["reason"], au["done"], au["total"],
         au["skipped"], au["unsettled"]))
    A("")
    A("board connected: %s" % s["board"]["connected"])
    A("board port     : %s" % s["board"]["port"])
    A("board firmware : %s" % s["board"]["firmware"])
    A("board error    : %s" % (s["board"]["error"] or "-"))
    A("motor rail V+  : %s counts  (supply_ok=%s)"
      % (s["board"]["vplus"], s["board"]["supply_ok"]))
    A("servo output   : %s   last commanded %s deg (%s us), driven=%s"
      % (s["servo"]["pin"], s["servo"]["angle"], s["servo"]["us"],
         s["servo"]["driven"]))
    A("")
    A("Y counter      : %s steps  (%s mm from origin)"
      % (s["pos"]["y_steps"], s["pos"]["y_mm"]))
    A("Z counter      : %s steps  (%s mm)" % (s["pos"]["z_steps"], s["pos"]["z_mm"]))
    lim = CTL.limits or {}
    A("Y soft limits  : %s .. %s" % ((lim.get("y") or {}).get("min"),
                                     (lim.get("y") or {}).get("max")))
    A("Z soft limits  : %s .. %s" % ((lim.get("z") or {}).get("min"),
                                     (lim.get("z") or {}).get("max")))
    A("steps_per_rev  : %s" % lim.get("steps_per_rev"))
    A("")
    A("last error     : %s" % (s["last_error"] or {}).get("msg", "-"))
    A("readings       : %d of %d" % (s["counts"]["done"], s["counts"]["total"]))
    A("stale CSV rows : %d" % s["stale_csv"])
    A("")
    A("ACTIVITY LOG (most recent last)")
    for l in s["log"]:
        A("  %s  %-5s %s" % (l["t"], l["level"], l["msg"]))
    A("")
    A("SERIAL PORTS SEEN")
    for pline in describe_ports() or ["  (none)"]:
        A("  %s" % pline)
    return "\n".join(out) + "\n"


def workbook_is_stale():
    """True if the sheet on disk was built for a different grid than the plan.

    A stale sheet has the right row NUMBERS but the wrong point behind each one,
    so merging into it files every reading against the wrong coordinate.
    """
    if not os.path.exists(WORKBOOK):
        return True
    try:
        from openpyxl import load_workbook
        ws = load_workbook(WORKBOOK, read_only=True, data_only=True)["Readings"]
        n = 0
        for r in ws.iter_rows(min_row=2):
            if r[0].value is None:
                continue
            n += 1
            p = CTL.by_row.get(r[0].row)
            if p is None or r[9].value != p["dir"]:
                return True
            if abs(float(r[6].value) - p["zmm"]) > 0.05:
                return True
        return n != len(CTL.rows)
    except Exception:                                       # noqa: BLE001
        return True


def regen_workbook():
    """Rebuild the sheet from the plan, archiving whatever was there."""
    try:
        import make_workbook
    except ImportError as e:
        return {"ok": False, "error": str(e)}
    os.makedirs(ARCHIVE, exist_ok=True)
    if os.path.exists(WORKBOOK):
        dest = os.path.join(ARCHIVE, "%s-uv_scan.xlsx"
                            % time.strftime("%Y%m%d-%H%M%S"))
        os.rename(WORKBOOK, dest)
        CTL.log("archived the previous workbook to %s" % os.path.basename(dest))
    make_workbook.build(WORKBOOK)
    CTL.log("rebuilt the workbook: %d rows" % len(CTL.rows))
    return {"ok": True, "path": WORKBOOK, "rows": len(CTL.rows)}


def merge_to_workbook():
    """Fold the CSV into the workbook, rebuilding it first if it is stale."""
    try:
        from openpyxl import load_workbook
    except ImportError:
        return {"ok": False, "error": "openpyxl is not installed on the host"}

    lock = os.path.join(os.path.dirname(WORKBOOK),
                        ".~lock.%s#" % os.path.basename(WORKBOOK))
    if os.path.exists(lock):
        return {"ok": False, "error": "the workbook looks open in Excel or "
                                      "LibreOffice -- close it and try again"}
    if workbook_is_stale():
        made = regen_workbook()
        if not made.get("ok"):
            return made

    wb = load_workbook(WORKBOOK)
    ws = wb["Readings"]
    n = 0
    for row, got in sorted(CTL.readings.items()):
        ws.cell(row=row, column=scan_plan.READING_COL).value = as_number(got["value"])
        ws.cell(row=row, column=scan_plan.READING_COL + 2).value = got["utc"]
        n += 1
    wb.save(WORKBOOK)
    CTL.log("saved %d readings to %s" % (n, os.path.basename(WORKBOOK)))
    return {"ok": True, "written": n, "path": WORKBOOK}


# -------------------------------------------------------------------- main ---
def main():
    global TOKEN
    ap = argparse.ArgumentParser(description="UV jig web control console.")
    ap.add_argument("--host", default="0.0.0.0",
                    help="bind address (default all interfaces)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--token", default=None,
                    help="require ?k=TOKEN on every request")
    ap.add_argument("--no-connect", action="store_true",
                    help="do not open the serial port at startup")
    ap.add_argument("--sim", action="store_true",
                    help="no hardware: simulated board and simulated meter")
    ap.add_argument("--mode", choices=MODES, default=None,
                    help="start in this mode (otherwise the last one used)")
    args = ap.parse_args()
    TOKEN = args.token
    if args.mode:
        CTL.mode = args.mode
        CTL.save_settings()

    # Bind BEFORE touching hardware. If the port is already taken -- usually a
    # console left running in another window -- exit here rather than after
    # having opened the serial port and marked it exclusive, which would leave
    # the real console unable to reopen it.
    try:
        srv = ThreadingHTTPServer((args.host, args.port), Handler)
    except OSError as e:
        print("cannot listen on %s:%d -- %s" % (args.host, args.port, e))
        print("Another console is probably already running. Close it, or pass")
        print("a different --port.")
        return 2

    CTL.start()
    if not args.no_connect:
        CTL.submit("connect", label="connecting")
    if CTL.mode == "auto":
        # Quiet best effort. Manual mode never gets here, so a machine with
        # no meter and no driver never sees this path at all.
        CTL.meter.exclude_ports = (CTL.board["port"],)
        CTL.meter.connect()

    suffix = ("?k=" + args.token) if args.token else ""
    print("=" * 68)
    print("UV Uniformity Jig -- web console   build %s" % BUILD)
    print("=" * 68)
    print("  mode          : %s%s" % (CTL.mode.upper(),
                                      "   (simulated board + meter)" if args.sim else ""))
    if CTL.mode == "auto":
        m = CTL.meter.state()
        print("  meter         : %s" % (("%s | %s | %s nm" % (m["name"], m["sensor"].strip(), m["wavelength"]))
                                        if m["connected"] else ("not found -- " + (m["error"] or "?"))))
    print("  this computer : http://localhost:%d/%s" % (args.port, suffix))
    print("  other devices : http://%s:%d/%s" % (lan_ip(), args.port, suffix))
    print()
    print("  one EiBotBoard: chamber Y on axis 1, Z on axis 2, servo on %s"
          % CTL.servo["pin"])
    print("  servo         : 0-%g deg over %d-%d us; %s aimed by the servo, %s by hand"
          % (ebb.SERVO_MAX_DEG, ebb.SERVO_US_AT_0DEG, ebb.SERVO_US_AT_MAX,
             "/".join(d for d, _ in scan_plan.SERVO), "/".join(scan_plan.MANUAL_ORDER)))
    print("  %d readings planned, %d already recorded"
          % (len(CTL.rows), len(CTL.readings)))
    if CTL.stale_csv:
        print("  %d CSV entries ignored: they do not match the current grid"
              % CTL.stale_csv)
    if not args.token:
        print()
        print("  No token set: anyone on this network can drive the jig.")
        print("  Use --token SOMETHING, or --host 127.0.0.1 to stay local.")
    print()
    print("  Ctrl-C to stop.")
    print("=" * 68)
    sys.stdout.flush()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping...")
        CTL.emergency_stop()
        CTL.submit("disconnect")
        time.sleep(0.6)
    return 0


if __name__ == "__main__":
    sys.exit(main())
